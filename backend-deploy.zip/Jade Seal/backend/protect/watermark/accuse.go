package watermark

import (
	"errors"
	"math"
	"sort"
)

// Accusation is one buyer's Tardos score against an observed codeword.
//
// The score is the sum over all code positions of the symmetric Tardos
// per-position contribution. A buyer with Score > cb.Z() is "accused" by
// the standard Tardos threshold; a buyer with Score < -cb.Z() is
// "exonerated" (the symmetric scheme's positive/negative split gives
// this for free — see Confidence for the 0..1 projection).
//
// Rank is the 1-based index after sorting by descending Score (1 = most
// suspicious). Confidence is a 0..1 projection of Score so callers can
// render "87% sure" without exposing the raw score; see Confidence.
type Accusation struct {
	Buyer      int
	Score      float64
	Confidence float64
}

// Accuse computes the Tardos accusation score for every buyer in cb
// against the observed codeword y (the output of Extract on a possibly
// noised buffer), and returns them sorted by descending Score.
//
// # The score function (symmetric Tardos, Škorić et al. 2008, Sec. 4.1)
//
// For each code position i (with bias p_i) and observed bit y_i, the
// per-position contribution for buyer j is
//
//	S_{j,i} =
//	  + sqrt((1-p_i)/p_i)   if X_{j,i} = y_i = 1
//	  - sqrt(p_i/(1-p_i))   if X_{j,i} = 0, y_i = 1
//	  - sqrt((1-p_i)/p_i)   if X_{j,i} = 1, y_i = 0
//	  + sqrt(p_i/(1-p_i))   if X_{j,i} = y_i = 0
//
// i.e. a *match* between the buyer's bit and the observed bit always
// contributes a *positive* score whose magnitude is larger when that bit
// was unlikely under the bias (sqrt((1-p)/p) for the rarer 1s and
// sqrt(p/(1-p)) for the rarer 0s); a mismatch always contributes a
// *negative* score of the same magnitude.
//
// The total score is S_j = sum_i S_{j,i}. The threshold is Z = m * Z0
// with Z0 = pi^2 / 2 (defaultZ0 in codebook.go). A buyer with S_j > Z
// is accused.
//
// Citation: Škorić, Katzenbeisser, Celik, "Symmetric Tardos fingerprinting
// codes for arbitrary alphabet sizes", Designs, Codes and Cryptography,
// 2008, Eq. (11) and the discussion around Eq. (16). The asymmetric
// original Tardos score (Tardos 2008, JACM, Eq. 6) assigns zero to any
// position where y_i = 0; the symmetric variant above is a strict
// improvement that halves the false-positive rate at the same code length
// for the binary alphabet.
//
// y must be exactly ceil(cb.M()/8) bytes; any other length is an error
// so callers cannot silently get garbage scores from a misaligned
// codeword. The bit ordering inside y matches Extract's output
// (MSB-first: bit at position i lives in byte i/8, bit 7-(i%8)).
func Accuse(cb *Codebook, y []byte) ([]Accusation, error) {
	if cb == nil {
		return nil, errors.New("watermark: nil codebook")
	}
	m := cb.m
	expectedBytes := (m + 7) / 8
	if len(y) != expectedBytes {
		return nil, errors.New("watermark: y has wrong length for codebook")
	}
	if cb.z0 <= 0 || len(cb.p) != m {
		return nil, errors.New("watermark: codebook is malformed")
	}

	// Pre-compute the four g-values per column. We store them as
	// (g1Pos, g0Pos, g1Neg, g0Neg) where:
	//   g1Pos = sqrt((1-p)/p)    positive contribution when X=y=1
	//   g0Pos = sqrt(p/(1-p))    positive contribution when X=y=0
	// and the negatives are just -g1Pos / -g0Pos.
	g1 := make([]float64, m)
	g0 := make([]float64, m)
	for i := 0; i < m; i++ {
		p := cb.p[i]
		// p is in [minDelta, 1-minDelta] by construction, so both
		// arguments to sqrt are strictly positive.
		g1[i] = math.Sqrt((1.0 - p) / p)
		g0[i] = math.Sqrt(p / (1.0 - p))
	}

	// Walk each buyer's score in turn. We cache one buyer's row by
	// indexing into the flat matrix with bit math; this avoids the
	// per-buyer repack that codeword() would do (an O(n*m/8) save).
	scores := make([]Accusation, cb.n)
	for j := 0; j < cb.n; j++ {
		var s float64
		rowBase := j * cb.m
		for i := 0; i < m; i++ {
			x := (cb.matrix[(rowBase+i)/8] >> uint(7-(rowBase+i)%8)) & 1
			yBit := (y[i/8] >> uint(7-i%8)) & 1
			// Branchless: pick g1 or g0 by the match outcome, then
			// flip sign if mismatch. Slightly faster than a 4-way
			// switch in the hot loop.
			var g float64
			if x == yBit {
				// match: positive
				if x == 1 {
					g = g1[i]
				} else {
					g = g0[i]
				}
			} else {
				// mismatch: negative
				if x == 1 {
					g = -g1[i]
				} else {
					g = -g0[i]
				}
			}
			s += g
		}
		scores[j] = Accusation{
			Buyer: j,
			Score: s,
		}
	}

	// Sort descending by Score.
	sort.SliceStable(scores, func(a, b int) bool {
		return scores[a].Score > scores[b].Score
	})

	// Project each score to a 0..1 confidence via the sigmoid variant in
	// Confidence, anchored so that Score == Z maps to 0.5 and a few
	// multiples of Z maps to near-1. Doing it here (once) means callers
	// who only read .Score still get the raw number; callers who want
	// the UI-friendly value read .Confidence.
	z := cb.z
	for i := range scores {
		scores[i].Confidence = Confidence(scores[i].Score, z)
	}
	return scores, nil
}

// Confidence turns a raw Tardos score into a 0..1 confidence value. The
// mapping is a logistic centered on the threshold Z, with a scale chosen
// so that one threshold above Z (Score = 2*Z) maps to ~0.88 and three
// thresholds above Z maps to ~0.998 — i.e. "above the threshold by one
// Z-unit" is a strong but not absolute signal, and "above by three
// Z-units" is effectively conclusive under the symmetric Tardos
// guarantee. A score equal to Z maps to 0.5 by construction; a score far
// below Z maps to ~0.
//
// The function is purely presentational: the only mathematically
// meaningful question is "Score > Z?" (call it accused or not). This
// helper exists so a UI can show "78% likely" without the operator
// having to know Z0.
//
// Mathematically: Confidence(s, z) = 1 / (1 + exp(-(s - z) / z)).
func Confidence(score, z float64) float64 {
	if z <= 0 {
		return 0
	}
	x := (score - z) / z
	// Clamp to avoid 0/Inf in exp; values outside +/- 20 saturate.
	if x > 20 {
		return 1
	}
	if x < -20 {
		return 0
	}
	return 1.0 / (1.0 + math.Exp(-x))
}
