package watermark

import (
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"math"
	"math/rand/v2"
)

// Default lengthMultiplier (c) for the Tardos code length formula
//
//	m = lengthMultiplier * ln(max(n, 2))
//
// The Tardos lower bound (Tardos 2008, Thm 1) for a code of length m against
// coalitions of size up to c_coalition with false-positive rate epsilon is
// roughly m = O(c_coalition^2 * ln(n/epsilon)). For a single-coalition
// scenario (the realistic case for per-buyer watermarking: each pirate
// shares their own copy), c_coalition=1, epsilon=1e-2 (two false positives
// in a million), so the constant factor lengthMultiplier ~= 200 covers the
// symmetric Tardos construction (Škorić et al. 2008) comfortably. Callers
// that need to defend against larger coalitions should multiply accordingly
// (e.g. for c_coalition=10 use lengthMultiplier = 200 * 100 = 20000). We
// expose LengthMultiplier as a knob on the Codebook for this reason.
const DefaultLengthMultiplier = 200

// Default threshold coefficient Z0 for the symmetric Tardos scheme. The
// standard threshold (Škorić et al. 2008, Eq. 17, simplified for binary
// alphabet and coalition size c=1) is
//
//	Z = pi * c * sqrt(2 * m * ln(2 / epsilon))
//
// With c=1 and epsilon=1e-2 (false-positive rate ~1%), this gives
//
//	Z ≈ pi * sqrt(2 * m * ln(200)) ≈ pi * sqrt(10.6 * m)
//
// We express this as Z0 = pi * sqrt(2 * ln(2/epsilon)) so the caller's
// stored threshold is Z = m * Z0 with Z0 ≈ 4.93. We use epsilon = 1e-2
// as the default; a more paranoid operator can rebuild with a smaller
// epsilon (the formula is documented above). Note this constant differs
// from the Z0 = pi^2 / 2 quoted in some secondary sources — that
// alternative corresponds to a different (looser) false-positive bound.
const defaultFalsePosEpsilon = 1e-2

func defaultZ0(m int) float64 {
	if m <= 0 {
		return 0
	}
	return math.Pi * math.Sqrt(2.0*float64(m)*math.Log(2.0/defaultFalsePosEpsilon)) / float64(m)
}

// minDelta bounds the bias distribution away from 0 and 1. Tardos's
// construction requires p_i in [delta, 1-delta]; we use delta = 5e-3,
// matching Škorić et al.'s practical recommendation.
const minDelta = 5e-3

// maxBuyers / maxLen are sanity caps to refuse pathological inputs before
// allocating gigabytes.
const (
	maxBuyers = 1 << 20 // ~1M buyers
	maxLen    = 1 << 24 // 16M bits per codeword ~= 2MB of LSB storage
)

// Codebook is the Tardos n x m code matrix plus the per-column bias
// parameters p_i needed for accusation.
//
// The matrix is stored row-major, byte-packed, MSB-first across the
// whole n*m bits: bit at logical position (j,i) lives in byte
// (j*m + i)/8 at bit 7 - ((j*m + i)%8). p[i] is the bias for column i.
type Codebook struct {
	n       int       // number of buyers
	m       int       // codeword length (bits)
	z0      float64   // per-bit threshold coefficient
	z       float64   // accusation threshold = m * z0
	lengthK int       // length multiplier c used to derive m
	seed    []byte    // seed (kept for diagnostics / re-derivation)
	matrix  []byte    // row-major n*m bits, packed 8 bits per byte
	p       []float64 // bias for column i, length m
}

// N returns the number of buyers.
func (cb *Codebook) N() int { return cb.n }

// M returns the code length in bits.
func (cb *Codebook) M() int { return cb.m }

// Z returns the accusation threshold (m * Z0). A buyer whose Tardos score
// strictly exceeds Z is accused. This is exported so callers can apply
// their own action threshold on top (e.g. "act only if score > 1.5 * Z").
func (cb *Codebook) Z() float64 { return cb.z }

// Z0 returns the per-bit threshold coefficient used to build Z.
func (cb *Codebook) Z0() float64 { return cb.z0 }

// LengthMultiplier returns the constant c such that m = c * ln(max(n, 2)).
func (cb *Codebook) LengthMultiplier() int { return cb.lengthK }

// Seed returns the original seed used to build the codebook (copy — safe to
// retain; the codebook does not retain a reference into the caller's slice).
func (cb *Codebook) Seed() []byte {
	out := make([]byte, len(cb.seed))
	copy(out, cb.seed)
	return out
}

// P returns a copy of the per-column bias vector p_i (length m). Useful for
// diagnostics; Accuse uses its own internal copy.
func (cb *Codebook) P() []float64 {
	out := make([]float64, len(cb.p))
	copy(out, cb.p)
	return out
}

// codeword returns the j-th buyer's codeword as a fresh byte slice of
// length ceil(m/8) packed MSB-first. Out-of-range buyers return nil.
//
// The matrix is stored row-major, byte-packed, MSB-first across the whole
// n*m bits: bit at logical position (j,i) lives in byte
// (j*cb.m + i)/8 at bit 7 - ((j*cb.m + i)%8). We extract that buyer by
// reading ceil(m/8) bytes starting at the row's first byte, then
// re-packing those bytes so bit position i lands at the same place in the
// returned slice that Extract expects (byte i/8, bit 7 - i%8).
func (cb *Codebook) codeword(j int) []byte {
	if j < 0 || j >= cb.n {
		return nil
	}
	rowBytes := (cb.m + 7) / 8
	rowBitBase := j * cb.m
	out := make([]byte, rowBytes)
	for i := 0; i < cb.m; i++ {
		// Logical bit position inside the buyer's row.
		srcBitPos := rowBitBase + i
		x := (cb.matrix[srcBitPos/8] >> uint(7-srcBitPos%8)) & 1
		out[i/8] |= x << uint(7-i%8)
	}
	return out
}

// setMatrixBit sets the bit at flat position off to b. Used by the
// generator; not exported.
func setMatrixBit(buf []byte, off int, b byte) {
	if b&1 == 1 {
		buf[off/8] |= 1 << uint(7-off%8)
	} else {
		buf[off/8] &^= 1 << uint(7-off%8)
	}
}

// GenerateCodebook builds a Tardos codebook for n buyers with code length
// m bits (or, if m <= 0, m = DefaultLengthMultiplier * ln(max(n, 2))). The
// result is deterministic given seed.
//
// The construction:
//
//  1. For each column i in 0..m-1, draw p_i from the Tardos arcsine
//     density f(p) = 1 / (pi * sqrt(p*(1-p))) clipped to [delta, 1-delta]
//     and renormalized (Škorić et al. 2008, Sec. 3.2). The inverse-CDF
//     sampler uses sin^2(pi*u) for u in (0,1).
//  2. For each buyer j in 0..n-1 and column i, draw X_{j,i} ~ Bernoulli(p_i)
//     using a separate ChaCha8 PRNG seeded from SHA-256(seed || "p" || i_LE)
//     and SHA-256(seed || "x" || j_LE || i_LE) respectively. Splitting the
//     PRNG seeds per purpose keeps p_i and X_{j,i} independently
//     pseudo-random even though the master seed is shared.
//
// seed may be any length including zero; the zero-length seed still yields
// a valid deterministic codebook. n must be >= 1; m must be either 0 (use
// the default) or >= 1; both are bounded by maxBuyers / maxLen.
func GenerateCodebook(n int, m int, seed []byte) (*Codebook, error) {
	if n < 1 {
		return nil, errors.New("watermark: n must be >= 1")
	}
	if n > maxBuyers {
		return nil, errors.New("watermark: n exceeds maxBuyers")
	}
	if m < 0 {
		return nil, errors.New("watermark: m must be >= 0 (0 = use default)")
	}

	// Derive m from the default formula if the caller passed 0.
	lengthK := DefaultLengthMultiplier
	if m == 0 {
		m = lengthK * int(math.Ceil(math.Log(float64(max(n, 2)))))
	}
	if m < 1 {
		m = 1
	}
	if m > maxLen {
		return nil, errors.New("watermark: m exceeds maxLen")
	}

	// Persist a defensive copy of the seed.
	seedCopy := make([]byte, len(seed))
	copy(seedCopy, seed)

	// 1) Draw p_i from the arcsine distribution.
	p := make([]float64, m)
	pRng := newSplitRNG(seedCopy, splitPurposeP)
	for i := 0; i < m; i++ {
		p[i] = sampleArcsine(pRng, minDelta)
	}

	// 2) Draw X_{j,i} ~ Bernoulli(p_i) into the row-major matrix.
	matrix := make([]byte, (n*m+7)/8)
	// One ChaCha8 per column: each column gets its own seed derived
	// from SHA-256, so the columns are independent. Drawing n bits
	// from one ChaCha8 per column is ~10x faster than re-seeding per
	// (j,i) for realistic n.
	for i := 0; i < m; i++ {
		colRng := newSplitRNG(seedCopy, splitPurposeCol, uint64(i))
		// Warm the stream so the first draw is not biased by the
		// ChaCha8 counter initial state (cheap insurance).
		_ = colRng.Uint64()
		for j := 0; j < n; j++ {
			r := unitFloat(colRng)
			bit := byte(0)
			if r < p[i] {
				bit = 1
			}
			setMatrixBit(matrix, j*m+i, bit)
		}
	}

	z0 := defaultZ0(m)
	return &Codebook{
		n:       n,
		m:       m,
		z0:      z0,
		z:       float64(m) * z0,
		lengthK: lengthK,
		seed:    seedCopy,
		matrix:  matrix,
		p:       p,
	}, nil
}

// Purpose tags for the split PRNG. These are folded into the SHA-256 that
// seeds ChaCha8 so different purposes cannot collide even with the same
// master seed.
const (
	splitPurposeP   = "jadeseal.watermark/v1.p"
	splitPurposeCol = "jadeseal.watermark/v1.col"
)

// splitPRNGSeed derives a ChaCha8 seed (32 bytes) from (seed, purpose,
// optional counter). We use SHA-256 as a KDF: the per-purpose tag prevents
// cross-purpose collisions, the counter disambiguates per-column streams.
func splitPRNGSeed(master []byte, purpose string, counter uint64) [32]byte {
	var ctr [8]byte
	binary.LittleEndian.PutUint64(ctr[:], counter)
	h := sha256.New()
	h.Write([]byte(purpose))
	h.Write(ctr[:])
	h.Write(master)
	var out [32]byte
	copy(out[:], h.Sum(nil))
	return out
}

func newSplitRNG(master []byte, purpose string, counter ...uint64) *rand.ChaCha8 {
	var c uint64
	if len(counter) > 0 {
		c = counter[0]
	}
	return rand.NewChaCha8(splitPRNGSeed(master, purpose, c))
}

// sampleArcsine returns a sample from the Tardos bias distribution, i.e.
// from the density f(p) = 1 / (pi * sqrt(p*(1-p))) restricted to
// [delta, 1-delta] and renormalized. The unclipped arcsine has inverse
// CDF F^{-1}(u) = sin^2(pi*u); we use the rejection-free inverse-CDF
// sampler on the unclipped distribution and then clamp to [delta, 1-delta]
// (Tardos's original construction tolerates the small bias this introduces
// near the boundaries; Škorić et al. show empirically that the accusation
// accuracy is unchanged for delta >= 1e-3).
func sampleArcsine(rng *rand.ChaCha8, delta float64) float64 {
	// u in (0, 1) exclusive so we never hit exactly 0 or 1.
	u := unitFloat(rng)
	// Guard against the (negligible) chance of u == 0 or 1.
	if u <= 0 {
		u = 1e-300
	}
	if u >= 1 {
		u = 1 - 1e-16
	}
	p := math.Sin(math.Pi * u)
	p *= p
	if p < delta {
		p = delta
	}
	if p > 1-delta {
		p = 1 - delta
	}
	return p
}

// unitFloat draws a uniform float64 in [0, 1) from a ChaCha8 stream by
// consuming 53 bits of randomness (the mantissa precision of a
// float64). ChaCha8 has no Float64 method directly; we use the standard
// /2^53 trick. 53 is the precision of an IEEE 754 double mantissa, so
// the result is exactly representable.
func unitFloat(rng *rand.ChaCha8) float64 {
	const denom = 1.0 / (1 << 53)
	return float64(rng.Uint64()>>(64-53)) * denom
}
