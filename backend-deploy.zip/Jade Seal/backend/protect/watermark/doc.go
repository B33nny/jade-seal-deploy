// Package watermark is the per-buyer traitor-tracing component of the Jade
// Seal protection pipeline (§5.15 of the architecture doc). It implements the
// symmetric Tardos probabilistic fingerprinting code
// (Tardos 2008, "Optimal Probabilistic Fingerprint Codes", JACM;
// simplified by Škorić, Katzenbeisser & Celik 2008, "Symmetric Tardos
// fingerprinting codes for arbitrary alphabet sizes", Des. Codes Cryptogr.)
// over the binary alphabet.
//
// # What it does
//
// GenerateCodebook builds an n_buyers x m_bits code matrix; each buyer is
// assigned a unique binary codeword X_j in {0,1}^m drawn column-wise against
// per-column bias parameters p_i sampled from the Tardos arcsine
// distribution. Embed appends a chosen buyer's codeword to a destination
// buffer as a self-describing trailer; Extract recovers the observed codeword
// from a possibly-noisy buffer; Accuse computes the Tardos
// score for every buyer against the observed codeword and returns them
// sorted by descending score with a 0..1 confidence.
//
// # What it deliberately does NOT do
//
// The mark embedded by this package is a *mathematical proof object*, not
// proof on its own. Its admissibility — the chain "the bits of this exact
// build came from this exact license-key, the license-key was signed by our
// root, the root is in HSM" — is owned by the surrounding pipeline
// (sealed-build / HSM / signed-license / anti-tamper in §5.6–5.14).
// The honest limits are:
//
//   - Accuse returns a score and a confidence per buyer, never a binary
//     verdict. A caller must apply its own threshold for action (legal
//     notice, takedown, account suspension). The math can show "buyer 3 is
//     the most likely source given this pirate copy"; it cannot show that
//     buyer 3 actually leaked it.
//   - A determined adversary who rewrites the binary's non-functional bytes
//     (e.g. recompiles from source, strips LSBs) destroys the mark. The
//     code is robust against the standard "coalition of c pirates
//     averaging/MAJ/XOR-ing their copies" attacks; it is not robust against
//     code lifting.
//   - The symmetric Tardos score function assumes the pirates follow a
//     standard collusion strategy (majority vote / interleaving / rand-min).
//     A non-standard collusion can degrade the accusation accuracy.
//   - Code length m scales with n_buyers and the chosen false-positive
//     epsilon (see codebook.go). Larger n needs longer m; this is intrinsic
//     to the Tardos lower bound, not a tuning knob.
//
// # What is honest v1
//
//   - The codebook is deterministic given the seed (so two builds with the
//     same seed reproduce the same matrix; two builds with different seeds
//     are independent).
//   - Embed and Extract round-trip exactly on a clean buffer.
//   - Accuse correctly identifies the guilty buyer under standard coalition
//     attacks with a calibrated score threshold (see TestAccusationCorrect).
//
// # What is stubbed v1
//
//   - The mark is a self-describing trailer (magic + version + buyer +
//     length + codeword) appended to the end of the destination buffer, not
//     XOR-into-LSB of the payload. Production should instead target only
//     non-functional bytes inside the actual section (padding, alignment,
//     debug strings) via a per-format PE/ELF/Mach-O walker; v1 has no such
//     walker, so it uses a trailer the caller appends after the real bytes.
package watermark
