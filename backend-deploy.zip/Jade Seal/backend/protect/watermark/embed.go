package watermark

import (
	"encoding/binary"
	"errors"
)

// trailerMagic is an 8-byte tag prepended to every embedded codeword so
// Extract can locate the codeword inside a destination buffer even if the
// buffer was partially modified by the surrounding pipeline (e.g. extra
// bytes appended by the packer). The value is the ASCII spelling of
// "JSWMTRAI" (Jade Seal WaterMark TRAIler) — chosen to be obviously
// non-PIE, non-ELF, non-PE, non-Mach-O so it won't collide with real
// binary headers.
var trailerMagic = [8]byte{'J', 'S', 'W', 'M', 'T', 'R', 'A', 'I'}

// trailerVersion is bumped if the on-disk layout ever changes. v1 packs the
// buyer index (uint32 LE), the code length m in bits (uint32 LE), and the
// codeword bytes ceil(m/8) MSB-first, after the 8-byte magic.
const trailerVersion uint32 = 1

// RequiredTrailerLen returns the number of bytes the trailer occupies in
// the destination buffer for a given code length. Callers use this to
// size the buffer they pass to Embed. The layout is:
//
//	magic(8) || version(4 LE) || buyer(4 LE) || mBits(4 LE) || payload(ceil(mBits/8))
//
// = 20 + ceil(mBits/8) bytes.
func RequiredTrailerLen(mBits int) int {
	if mBits < 0 {
		mBits = 0
	}
	return 20 + (mBits+7)/8
}

// embedTrailer is the on-disk layout written by Embed and read by Extract.
// Keeping it as a single struct avoids re-decoding magic+version+length in
// Extract's hot path.
type embedTrailer struct {
	buyer   uint32 // which buyer this codeword belongs to (informational)
	mBits   uint32 // codeword length in bits
	payload []byte // ceil(mBits/8) bytes, MSB-first
}

// Encode serializes the trailer as: magic(8) || version(4 LE) || buyer(4 LE)
// || mBits(4 LE) || payload.
func (t embedTrailer) Encode() []byte {
	out := make([]byte, 0, 8+4+4+4+len(t.payload))
	out = append(out, trailerMagic[:]...)
	var ver [4]byte
	binary.LittleEndian.PutUint32(ver[:], trailerVersion)
	out = append(out, ver[:]...)
	var bufb [4]byte
	binary.LittleEndian.PutUint32(bufb[:], t.buyer)
	out = append(out, bufb[:]...)
	binary.LittleEndian.PutUint32(bufb[:], t.mBits)
	out = append(out, bufb[:]...)
	out = append(out, t.payload...)
	return out
}

// decodeTrailer parses the trailer bytes produced by Encode. It returns
// an error on bad magic, bad version, or truncated payload.
func decodeTrailer(b []byte) (embedTrailer, error) {
	if len(b) < 8+4+4+4 {
		return embedTrailer{}, errors.New("watermark: trailer too short")
	}
	for i := 0; i < 8; i++ {
		if b[i] != trailerMagic[i] {
			return embedTrailer{}, errors.New("watermark: trailer magic mismatch")
		}
	}
	ver := binary.LittleEndian.Uint32(b[8:12])
	if ver != trailerVersion {
		return embedTrailer{}, errors.New("watermark: trailer version unsupported")
	}
	buyer := binary.LittleEndian.Uint32(b[12:16])
	mBits := binary.LittleEndian.Uint32(b[16:20])
	payloadLen := int((mBits + 7) / 8)
	if len(b) < 20+payloadLen {
		return embedTrailer{}, errors.New("watermark: trailer payload truncated")
	}
	return embedTrailer{
		buyer:   buyer,
		mBits:   mBits,
		payload: append([]byte(nil), b[20:20+payloadLen]...),
	}, nil
}

// Embed writes buyer j's codeword from cb into a fresh trailer appended to
// the end of dest. It returns the new buffer (dest is not modified in
// place — the caller usually wants the result either way, so returning a
// fresh slice avoids an in-place mutation surprise). The trailer is
// self-describing (magic + version + buyer + mBits + payload), so Extract
// does not need the original cb to recover the embedded codeword; it only
// needs the destination buffer. The Codebook is required here only to
// fetch the right codeword — at accusation time the analyst will rebuild
// or look up the same Codebook independently from the master seed.
//
// The trailer is the entire mark: v1 does not also XOR the codeword into
// the destination's LSBs. The architecture doc calls out (§5.15) that
// production should target only non-functional bytes; v1's trailer is the
// simplest "non-functional region" we can use without a per-format PE/ELF
// section walker, and it cleanly round-trips through Embed/Extract.
func Embed(cb *Codebook, j int, dest []byte) ([]byte, error) {
	if cb == nil {
		return nil, errors.New("watermark: nil codebook")
	}
	cw := cb.codeword(j)
	if cw == nil {
		return nil, errors.New("watermark: buyer index out of range")
	}
	trailer := embedTrailer{
		buyer:   uint32(j),
		mBits:   uint32(cb.m),
		payload: cw,
	}.Encode()

	out := make([]byte, 0, len(dest)+len(trailer))
	out = append(out, dest...)
	out = append(out, trailer...)
	return out, nil
}

// Extract recovers the embedded codeword from buf. It returns the
// codeword (length ceil(mBits/8), MSB-first) and the original buyer index
// it was tagged with. If buf does not end in a valid trailer, Extract
// returns an error so callers cannot accidentally accuse against a buffer
// that was never marked.
//
// To tolerate the buffer being modified in transit, Extract searches the
// last RequiredTrailerLen(maxBits) bytes for the magic prefix. In practice
// the trailer sits at the very end (Embed appends), so we scan backward
// from the end; on a clean buffer this is one comparison. On a noised
// buffer (the realistic case for a leaked/pirated copy) this still
// recovers the codeword as long as the trailer itself is intact.
func Extract(buf []byte) ([]byte, int, error) {
	if len(buf) < 20 {
		return nil, 0, errors.New("watermark: buffer too short to contain trailer")
	}
	// Walk backward looking for the magic. The magic is at a fixed offset
	// 8 from the start of the trailer, so a real trailer starts at
	// len(buf) - trailerLen. We try the longest plausible trailer first
	// (one with mBits bits = 8 * payload bytes), shrinking payload by one
	// byte each step, down to a minimum payload of 1 byte.
	trailerMinLen := 20 + 1 // magic+ver+buyer+mBits+1 byte payload
	for start := len(buf) - trailerMinLen; start+8 <= len(buf); start-- {
		if start < 0 {
			break
		}
		if matchMagic(buf[start:]) {
			t, err := decodeTrailer(buf[start:])
			if err == nil {
				return t.payload, int(t.buyer), nil
			}
		}
	}
	return nil, 0, errors.New("watermark: no valid trailer found")
}

// matchMagic reports whether b begins with the 8-byte trailer magic. We
// keep this as a tight inline loop in Extract's hot path.
func matchMagic(b []byte) bool {
	if len(b) < 8 {
		return false
	}
	for i := 0; i < 8; i++ {
		if b[i] != trailerMagic[i] {
			return false
		}
	}
	return true
}
