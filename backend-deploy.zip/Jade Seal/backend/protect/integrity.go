package protect

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
)

// ComputeIntegrityDigest measures an uploaded binary so a later anti-tamper
// check (§5.7) has a baseline to compare against. It detects the file format
// (PE / ELF / Mach-O / unknown) from the header magic and returns the SHA-256
// of the whole file as a lowercase hex string.
//
// v0 hashes the whole file — the honest, format-agnostic baseline. Scoping the
// hash to the executable's code (.text) section is the Phase B refinement that
// turns this into true anti-tamper; it needs per-format section parsing, which
// v0 deliberately defers rather than fake.
func ComputeIntegrityDigest(filePath string) (format string, digest string, err error) {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return "", "", fmt.Errorf("read for integrity: %w", err)
	}
	if len(data) == 0 {
		return "", "", fmt.Errorf("empty file: %s", filePath)
	}

	sum := sha256.Sum256(data)
	return detectFormat(data), hex.EncodeToString(sum[:]), nil
}

// detectFormat returns a short label for the binary format from the header
// magic. Anything unrecognised is reported as "unknown" rather than guessed.
func detectFormat(data []byte) string {
	if len(data) >= 2 && data[0] == 'M' && data[1] == 'Z' {
		return "PE"
	}
	if len(data) >= 4 && data[0] == 0x7f && data[1] == 'E' && data[2] == 'L' && data[3] == 'F' {
		return "ELF"
	}
	if len(data) >= 4 {
		b := data[0:4]
		big32 := b[0] == 0xfe && b[1] == 0xed && b[2] == 0xfa && b[3] == 0xce
		big64 := b[0] == 0xfe && b[1] == 0xed && b[2] == 0xfa && b[3] == 0xcf
		lit32 := b[0] == 0xce && b[1] == 0xfa && b[2] == 0xed && b[3] == 0xfe
		lit64 := b[0] == 0xcf && b[1] == 0xfa && b[2] == 0xed && b[3] == 0xfe
		if big32 || big64 || lit32 || lit64 {
			return "Mach-O"
		}
	}
	return "unknown"
}
