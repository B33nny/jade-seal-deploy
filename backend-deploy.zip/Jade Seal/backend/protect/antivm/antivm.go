// Package antivm is the user-mode virtual-machine detection layer for §5.11 of
// the Jade Seal protection spec. It runs a small set of portable checks and
// reports a 0-100 score the caller can act on (e.g. gate a high-value feature,
// or flag an activation for review).
//
// Design rules, matching the antidebug package:
//
//   - Detect, don't crash. Every check is wrapped so a missing file or failed
//     lookup can never panic the caller.
//   - Report, don't decide. The library only returns a score + reasons; the
//     caller chooses what the score means in its context.
//
// The checks shipped here are deliberately weak-signal: they detect the
// *artifacts* a VM commonly leaves behind (guest-tools drivers and files).
// The strong signals — the CPUID hypervisor bit, ACPI/DSDT tables, the
// VirtualBox/Vmware BIOS strings — need privileged reads and land with the
// kernel driver in Phase C (§5.19). This package is the honest, user-mode
// first-pass; treat a high score as "warrants a closer look", not proof.
//
// The package ships three files:
//
//   - antivm.go (this file): Score type + pure aggregate() core, so the
//     scoring logic is unit-testable without touching any OS API.
//   - windows.go: Windows-specific artifact checks. Gated by //go:build windows.
//   - stub.go: Non-Windows no-op. Gated by //go:build !windows.
package antivm

import "math"

// Score is the user-mode anti-VM result.
//
//	Value   0..100 — higher means more VM indicators fired.
//	Reasons names of the indicators that fired, for diagnostics.
type Score struct {
	Value   int
	Reasons []string
}

// aggregate turns parallel fired/name slices into a Score. It is pure so it can
// be tested without touching the OS. A mismatched or empty pair returns
// Score{Value: 0}, meaning "no checks ran" — NOT "not a VM".
func aggregate(fired []bool, names []string) Score {
	if len(fired) == 0 || len(fired) != len(names) {
		return Score{Value: 0}
	}

	count := 0
	reasons := make([]string, 0, len(fired))
	for i, f := range fired {
		if f {
			count++
			reasons = append(reasons, names[i])
		}
	}
	if count == 0 {
		return Score{Value: 0}
	}

	v := int(math.Round((float64(count) / float64(len(fired))) * 100.0))
	if v < 1 {
		v = 1
	}
	if v > 100 {
		v = 100
	}
	return Score{Value: v, Reasons: reasons}
}
