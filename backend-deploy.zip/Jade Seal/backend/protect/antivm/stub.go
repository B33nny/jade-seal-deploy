//go:build !windows

package antivm

// Detect returns a zero score on non-Windows hosts: the VM artifacts this
// package checks for are Windows-specific, and scoring them on a Linux/macOS
// server would be meaningless.
func Detect() Score {
	return Score{Value: 0}
}
