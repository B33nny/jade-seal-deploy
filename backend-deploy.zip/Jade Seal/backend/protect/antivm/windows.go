//go:build windows

package antivm

import "os"

// vmIndicators maps a human-readable indicator name to one or more well-known
// files/drivers that a specific hypervisor leaves behind when guest tools are
// installed. This is a *weak* signal: a VM without guest tools has none of
// these, and a stripped-down host rarely has false positives. The strong
// signals (CPUID hypervisor bit, ACPI tables) arrive with the kernel driver in
// Phase C (§5.19).
var vmIndicators = []struct {
	name  string
	paths []string
}{
	{
		name: "vmware",
		paths: []string{
			`C:\Windows\System32\drivers\vmhgfs.sys`,
			`C:\Windows\System32\drivers\vmmouse.sys`,
			`C:\Windows\System32\vm3dgl.dll`,
			`C:\Program Files\VMware\VMware Tools\vmtoolsd.exe`,
		},
	},
	{
		name: "virtualbox",
		paths: []string{
			`C:\Windows\System32\drivers\VBoxGuest.sys`,
			`C:\Windows\System32\drivers\VBoxMouse.sys`,
			`C:\Windows\System32\VBoxService.exe`,
			`C:\Program Files\Oracle\VirtualBox Guest Additions\VBoxTray.exe`,
		},
	},
	{
		name: "qemu",
		paths: []string{
			`C:\Windows\System32\drivers\qemupciserial.sys`,
			`C:\Program Files\QEMU\qemu-ga.exe`,
			`C:\Windows\System32\drivers\viofs.sys`, // virtio-fs (QEMU/KVM)
			`C:\Windows\System32\drivers\viostor.sys`,
		},
	},
	{
		name: "hyperv",
		paths: []string{
			`C:\Windows\System32\drivers\vmbus.sys`,
			`C:\Windows\System32\drivers\vms3cap.sys`,
			`C:\Windows\System32\vmbuspipe.dll`,
		},
	},
	{
		name: "parallels",
		paths: []string{
			`C:\Windows\System32\drivers\prl_tg.sys`,
			`C:\Windows\System32\drivers\prlfs.sys`,
			`C:\Program Files\Parallels\Parallels Tools\Services\coherence.exe`,
		},
	},
	{
		name: "xen",
		paths: []string{
			`C:\Windows\System32\drivers\xenevtchn.sys`,
			`C:\Windows\System32\drivers\xenbus.sys`,
			`C:\Program Files\Xen PV Drivers\XenSetup.exe`,
		},
	},
}

// Detect runs every VM indicator and returns the aggregated Score. It never
// panics: a stat that fails simply means that indicator did not fire.
func Detect() Score {
	fired := make([]bool, 0, len(vmIndicators))
	names := make([]string, 0, len(vmIndicators))
	for _, ind := range vmIndicators {
		fired = append(fired, anyExists(ind.paths))
		names = append(names, ind.name)
	}
	return aggregate(fired, names)
}

func anyExists(paths []string) bool {
	for _, p := range paths {
		if _, err := os.Stat(p); err == nil {
			return true
		}
	}
	return false
}
