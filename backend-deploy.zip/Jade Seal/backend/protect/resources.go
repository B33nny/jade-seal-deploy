// Package protect is the protection pipeline: the ordered chain of
// transformations applied to an uploaded binary. Phase A establishes the seam —
// the integrity measurement is real, and the remaining stages are documented
// no-op stubs, wired end-to-end so the backend honestly reports what it can do
// (validate + archive + measure) and does not pretend to transform anything.
// Real transforms land in Phase B/C (see the architecture doc, §5 Protection).
package protect

// EncryptResources encrypts embedded resources — string literals, constants,
// and other static data — inside the binary at filePath (§5.6 Resource
// Encryption).
//
// Phase A: STUB — no-op. Returns nil so the pipeline runs end-to-end today
// without claiming to have encrypted anything.
func EncryptResources(filePath string) error {
	// TODO(Phase C): implement string/resource encryption (XOR/AES).
	return nil
}
