// Package encrypt provides the byte-level transform primitives for the Jade
// Seal protection pipeline (§5.14): a fast obfuscation XOR, AES-256-GCM for
// blobs that must be recoverable, and HKDF-SHA256 key derivation.
//
// These are primitives, not a finished protector: they are honest, stdlib-only
// building blocks the pipeline composes into a protected artifact. XOR hides
// string literals; AESGCM protects resource blobs with tamper-evident
// authenticated encryption; DeriveKey yields stable sub-keys from one secret.
package encrypt

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hkdf"
	"crypto/rand"
	"crypto/sha256"
	"errors"
	"fmt"
	"io"
)

// DeriveKey derives length bytes of key material from a secret using
// HKDF-SHA256 (RFC 5869) with a domain-separation label. The same
// (secret, info, length) always yields the same bytes, so it can derive stable
// sub-keys (e.g. a packer key from the license signing seed) without managing
// a second secret. info disambiguates purposes so one secret never leaks
// another purpose's keys.
func DeriveKey(secret []byte, info string, length int) ([]byte, error) {
	if len(secret) == 0 {
		return nil, errors.New("encrypt: empty secret")
	}
	if length <= 0 {
		return nil, errors.New("encrypt: non-positive key length")
	}
	return hkdf.Key(sha256.New, secret, nil, info, length)
}

// XOR applies a repeating-key XOR. It is symmetric: XOR(XOR(d, k), k) == d.
//
// XOR is obfuscation, not encryption — it has no authentication and is trivial
// to undo if the key is known. Use it only to hide string literals and other
// non-secret-at-rest data; use AESGCMEncrypt for anything that must actually
// be confidential or tamper-evident.
func XOR(data, key []byte) []byte {
	if len(key) == 0 {
		return append([]byte(nil), data...)
	}
	out := make([]byte, len(data))
	for i, b := range data {
		out[i] = b ^ key[i%len(key)]
	}
	return out
}

// AESGCMEncrypt encrypts plaintext with AES-256-GCM under key and returns a
// blob of the form nonce(12) || ciphertext||tag. The nonce is fresh random on
// every call, so the same plaintext encrypts differently each time. key must
// be exactly 32 bytes.
func AESGCMEncrypt(plaintext, key []byte) ([]byte, error) {
	if len(key) != 32 {
		return nil, fmt.Errorf("encrypt: AES-256-GCM requires a 32-byte key, got %d", len(key))
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("encrypt: bad key: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	// Seal appends to nonce, yielding nonce || ciphertext||tag.
	return gcm.Seal(nonce, nonce, plaintext, nil), nil
}

// AESGCMDecrypt reverses AESGCMEncrypt. It returns an error if the blob is
// malformed, the key is wrong, or the ciphertext was tampered with. key must
// be exactly 32 bytes.
func AESGCMDecrypt(blob, key []byte) ([]byte, error) {
	if len(key) != 32 {
		return nil, fmt.Errorf("encrypt: AES-256-GCM requires a 32-byte key, got %d", len(key))
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("encrypt: bad key: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	if len(blob) < gcm.NonceSize() {
		return nil, errors.New("encrypt: blob too short")
	}
	nonce, ct := blob[:gcm.NonceSize()], blob[gcm.NonceSize():]
	return gcm.Open(nil, nonce, ct, nil)
}
