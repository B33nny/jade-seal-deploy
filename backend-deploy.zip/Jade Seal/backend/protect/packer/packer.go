// Package packer implements the Jade Seal "custom packer + Taggant" format.
//
// The packer compresses and encrypts-style-encodes a binary payload so that
// static analysis tools cannot trivially read the contents, while still
// allowing the legitimate receiver to recover the original bytes. An
// Ed25519 "Taggant" signature is attached to the header so that a verifier
// (e.g. an antivirus integration) can distinguish legitimate vendor
// packer output from unsigned / tampered blobs.
//
// Format (all integers little-endian, fixed-size header):
//
//	offset  size  field
//	0       4     Magic         "JSPK"
//	4       1     Version       = 1
//	5       1     Flags         bit 0 = compressed
//	6       16    BuildID       random per Pack
//	22      8     UncompressedLen (uint64)
//	30      8     CompressedLen   (uint64)
//	38      64    Taggant        ed25519 signature
//	102     N     Payload        CompressedLen bytes
//
// The Taggant is ed25519.Sign(priv, sha256(payload) || buildID || publicKey).
package packer

import (
	"bytes"
	"compress/flate"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"io"

	"github.com/klauspost/compress/zstd"
)

const (
	magic         = "JSPK"
	version       = uint8(1)
	flagCompressed = uint8(1 << 0)

	magicSize         = 4
	buildIDSize       = 16
	taggantSize       = ed25519.SignatureSize // 64
	publicKeySize     = ed25519.PublicKeySize // 32
	seedSize          = ed25519.SeedSize      // 32

	// headerSize = magic(4) + version(1) + flags(1) + buildID(16)
	//            + uncompressedLen(8) + compressedLen(8) + taggant(64)
	headerSize = magicSize + 1 + 1 + buildIDSize + 8 + 8 + taggantSize
)

// Packer holds an ed25519 keypair used to sign packed payloads (Taggant).
type Packer struct {
	priv ed25519.PrivateKey
	pub  ed25519.PublicKey
}

// New derives a Packer from a 32-byte ed25519 seed. seed must be exactly
// ed25519.SeedSize bytes long.
func New(seed []byte) (*Packer, error) {
	if len(seed) != seedSize {
		return nil, fmt.Errorf("packer: seed must be %d bytes, got %d", seedSize, len(seed))
	}
	priv := ed25519.NewKeyFromSeed(seed)
	pub, ok := priv.Public().(ed25519.PublicKey)
	if !ok {
		return nil, errors.New("packer: ed25519 public key has unexpected type")
	}
	return &Packer{priv: priv, pub: pub}, nil
}

// NewRandom returns a Packer backed by a fresh, cryptographically random
// ed25519 keypair.
func NewRandom() (*Packer, error) {
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, fmt.Errorf("packer: generate key: %w", err)
	}
	pub := priv.Public().(ed25519.PublicKey)
	return &Packer{priv: priv, pub: pub}, nil
}

// PublicKey returns the 32-byte ed25519 public key associated with this
// Packer. The returned slice is a copy; callers may retain it freely.
func (p *Packer) PublicKey() []byte {
	out := make([]byte, len(p.pub))
	copy(out, p.pub)
	return out
}

// Pack compresses input with zstd and returns a self-describing packed
// blob that includes a Taggant signature over the payload. A random
// BuildID is generated for every call.
func (p *Packer) Pack(input []byte) ([]byte, error) {
	if p == nil {
		return nil, errors.New("packer: nil receiver")
	}

	// Compress with zstd (BestSpeed — packer runs at build time, ratio
	// is secondary to throughput). Fall back to flate if zstd ever
	// refuses to initialise.
	payload, err := zstdCompress(input)
	if err != nil {
		return nil, fmt.Errorf("packer: compress: %w", err)
	}

	buildID := make([]byte, buildIDSize)
	if _, err := rand.Read(buildID); err != nil {
		return nil, fmt.Errorf("packer: read build id: %w", err)
	}

	taggant := p.signTaggant(payload, buildID)

	out := make([]byte, 0, headerSize+len(payload))
	out = append(out, magic...)
	out = append(out, version)
	out = append(out, flagCompressed)
	out = append(out, buildID...)
	var lenBuf [8]byte
	binary.LittleEndian.PutUint64(lenBuf[:], uint64(len(input)))
	out = append(out, lenBuf[:]...)
	binary.LittleEndian.PutUint64(lenBuf[:], uint64(len(payload)))
	out = append(out, lenBuf[:]...)
	out = append(out, taggant...)
	out = append(out, payload...)
	return out, nil
}

// Unpack validates the header, verifies the Taggant, and decompresses
// the payload. It returns the original uncompressed bytes. On any
// validation failure (magic, version, length, signature) it returns
// an error and never partial data.
func (p *Packer) Unpack(packed []byte) ([]byte, error) {
	if p == nil {
		return nil, errors.New("packer: nil receiver")
	}
	if len(packed) < headerSize {
		return nil, fmt.Errorf("packer: input too short: %d < %d", len(packed), headerSize)
	}

	if !bytes.Equal([]byte(magic), packed[:magicSize]) {
		return nil, fmt.Errorf("packer: bad magic %q", packed[:magicSize])
	}
	if v := packed[magicSize]; v != version {
		return nil, fmt.Errorf("packer: unsupported version %d (expected %d)", v, version)
	}
	flags := packed[magicSize+1]
	if flags&flagCompressed == 0 {
		return nil, errors.New("packer: payload is not compressed (unsupported)")
	}

	buildID := packed[magicSize+2 : magicSize+2+buildIDSize]
	uncompressedLen := binary.LittleEndian.Uint64(packed[magicSize+2+buildIDSize : magicSize+2+buildIDSize+8])
	compressedLen := binary.LittleEndian.Uint64(packed[magicSize+2+buildIDSize+8 : magicSize+2+buildIDSize+16])
	taggant := packed[magicSize+2+buildIDSize+16 : headerSize]
	payload := packed[headerSize:]

	if uint64(len(payload)) != compressedLen {
		return nil, fmt.Errorf("packer: compressed length mismatch: header=%d actual=%d", compressedLen, len(payload))
	}
	if compressedLen == 0 {
		// An empty compressed blob is not a valid zstd/flate stream;
		// reject to keep the decoder logic uniform.
		return nil, errors.New("packer: empty payload")
	}

	if !ed25519.Verify(p.pub, taggantMessage(payload, buildID, p.pub), taggant) {
		return nil, errors.New("packer: taggant signature verification failed")
	}

	raw, err := zstdDecompress(payload, int(uncompressedLen))
	if err != nil {
		return nil, fmt.Errorf("packer: decompress: %w", err)
	}
	if uint64(len(raw)) != uncompressedLen {
		return nil, fmt.Errorf("packer: uncompressed length mismatch: header=%d actual=%d", uncompressedLen, len(raw))
	}
	return raw, nil
}

// signTaggant produces the 64-byte ed25519 signature stored in the header.
// The signed message is sha256(payload) || buildID || publicKey.
func (p *Packer) signTaggant(payload, buildID []byte) []byte {
	return ed25519.Sign(p.priv, taggantMessage(payload, buildID, p.pub))
}

// taggantMessage builds the canonical bytes signed/verified by the Taggant.
func taggantMessage(payload, buildID, pub []byte) []byte {
	h := sha256.Sum256(payload)
	msg := make([]byte, 0, sha256.Size+len(buildID)+len(pub))
	msg = append(msg, h[:]...)
	msg = append(msg, buildID...)
	msg = append(msg, pub...)
	return msg
}

// zstdCompress compresses src with zstd (best speed). It is a thin
// wrapper kept separate so the zstd encoder/decoder objects can be
// reused and so any future fallback (e.g. flate) lives in one place.
func zstdCompress(src []byte) ([]byte, error) {
	enc, err := zstd.NewWriter(nil,
		zstd.WithEncoderLevel(zstd.SpeedFastest),
		zstd.WithEncoderConcurrency(1),
	)
	if err != nil {
		// Should never happen with the options above, but fall back
		// to flate so Pack still works.
		return flateCompress(src)
	}
	defer enc.Close()
	return enc.EncodeAll(src, make([]byte, 0, len(src))), nil
}

// zstdDecompress decompresses src, pre-allocating a buffer of the
// expected uncompressed size when the caller knows it (the header
// always carries uncompressedLen).
func zstdDecompress(src []byte, expected int) ([]byte, error) {
	dec, err := zstd.NewReader(nil,
		zstd.WithDecoderConcurrency(1),
	)
	if err != nil {
		return nil, err
	}
	defer dec.Close()
	out, err := dec.DecodeAll(src, make([]byte, 0, expected))
	if err != nil {
		// Fall back to flate in case the blob was produced by the
		// flate fallback path.
		return flateDecompress(src, expected)
	}
	return out, nil
}

// flateCompress is the flate fallback used when zstd is unavailable.
func flateCompress(src []byte) ([]byte, error) {
	var buf bytes.Buffer
	w, err := flate.NewWriter(&buf, flate.BestSpeed)
	if err != nil {
		return nil, err
	}
	if _, err := io.Copy(w, bytes.NewReader(src)); err != nil {
		_ = w.Close()
		return nil, err
	}
	if err := w.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// flateDecompress is the flate fallback used when zstd is unavailable.
func flateDecompress(src []byte, expected int) ([]byte, error) {
	r := flate.NewReader(bytes.NewReader(src))
	defer r.Close()
	out := bytes.NewBuffer(make([]byte, 0, expected))
	if _, err := io.Copy(out, r); err != nil {
		return nil, err
	}
	return out.Bytes(), nil
}
