package vm

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"fmt"
	"strconv"
	"strings"
)

// Instruction is one parsed instruction in a human-writable program.
// Immediates are stored as int64; the assembler emits them little-endian
// after the opcode byte.
type Instruction struct {
	Op   Opcode
	Arg  int64 // used by push, jmp, jz, jnz, call, load, store
	HasArg bool  // distinguishes "push 7" from "halt"
}

// String formats the instruction back to its mnemonic form. Used by
// Disassemble and by test error messages.
func (in Instruction) String() string {
	if in.HasArg {
		return fmt.Sprintf("%s %d", in.Op.Name(), in.Arg)
	}
	return in.Op.Name()
}

// Assemble encodes a structured program into v0 bytecode. The encoding is
// stable: opcode byte (1), then 8 little-endian bytes if the instruction
// carries an immediate. This means a `push 7` is the bytes 0x00 followed
// by 07 00 00 00 00 00 00 00 — the literal "7" only appears as a binary
// immediate, never as a printable constant in the bytecode blob.
//
// Pass an explicit HasArg=true on every push/jmp/jz/jnz/call/load/store
// instruction; the assembler ignores Arg otherwise. For "halt" leave
// HasArg=false.
func Assemble(prog []Instruction) ([]byte, error) {
	var buf bytes.Buffer
	for i, in := range prog {
		if int(in.Op) >= len(opcodeName) && !hasName(in.Op) {
			return nil, fmt.Errorf("assemble[%d]: unknown opcode %d", i, in.Op)
		}
		if _, err := buf.Write([]byte{byte(in.Op)}); err != nil {
			return nil, err
		}
		if in.HasArg {
			var scratch [8]byte
			binary.LittleEndian.PutUint64(scratch[:], uint64(in.Arg))
			buf.Write(scratch[:])
		}
	}
	return buf.Bytes(), nil
}

func hasName(op Opcode) bool { _, ok := opcodeName[op]; return ok }

// AssembleText parses a tiny line-oriented text program into bytecode.
// One instruction per line, '#' starts a comment to end of line, blank
// lines ignored. Useful for hand-authoring test programs without going
// through the []Instruction API.
//
// Example:
//
//	push 2
//	push 3
//	add
//	push 4
//	mul
//	halt
func AssembleText(src string) ([]byte, error) {
	var prog []Instruction
	sc := bufio.NewScanner(strings.NewReader(src))
	lineNum := 0
	for sc.Scan() {
		lineNum++
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) == 0 {
			continue
		}
		op, ok := LookupOpcode(fields[0])
		if !ok {
			return nil, fmt.Errorf("line %d: unknown mnemonic %q", lineNum, fields[0])
		}
		in := Instruction{Op: op}
		switch len(fields) {
		case 1:
			// no argument
		case 2:
			n, err := strconv.ParseInt(fields[1], 0, 64)
			if err != nil {
				return nil, fmt.Errorf("line %d: bad integer %q", lineNum, fields[1])
			}
			in.Arg = n
			in.HasArg = true
		default:
			return nil, fmt.Errorf("line %d: too many fields", lineNum)
		}
		prog = append(prog, in)
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	return Assemble(prog)
}

// Disassemble walks a bytecode blob and emits the structured Instruction
// list back. It is the inverse of Assemble() for well-formed programs;
// truncated input returns ErrTruncated, unknown opcodes return
// ErrBadOpcode.
//
// Branch immediates (jmp, jz, jnz, call) are returned as raw byte offsets
// from the current PC, NOT as absolute addresses — the assembler emits
// relative offsets, so the disassembler does too. That keeps the format
// position-independent.
func Disassemble(code []byte) ([]Instruction, error) {
	var out []Instruction
	var pc int
	for pc < len(code) {
		op := Opcode(code[pc])
		if !hasName(op) {
			return nil, fmt.Errorf("%w: 0x%02x at pc=%d", ErrBadOpcode, byte(op), pc)
		}
		pc++
		in := Instruction{Op: op}
		if needsArg(op) {
			if pc+8 > len(code) {
				return nil, fmt.Errorf("%w: opcode %s at pc=%d needs 8 bytes, have %d",
					ErrTruncated, op.Name(), pc-1, len(code)-pc)
			}
			raw := binary.LittleEndian.Uint64(code[pc : pc+8])
			in.Arg = int64(raw)
			in.HasArg = true
			pc += 8
		}
		out = append(out, in)
	}
	return out, nil
}

// needsArg reports whether an opcode carries an int64 immediate in the
// bytecode stream.
func needsArg(op Opcode) bool {
	switch op {
	case OpPush, OpLoad, OpStore, OpJmp, OpJz, OpJnz, OpCall:
		return true
	}
	return false
}

// FormatBytecode is a convenience for printing: disassemble then join.
// Used in test failure messages.
func FormatBytecode(code []byte) (string, error) {
	prog, err := Disassemble(code)
	if err != nil {
		return "", err
	}
	var b strings.Builder
	for i, in := range prog {
		if i > 0 {
			b.WriteByte('\n')
		}
		fmt.Fprintf(&b, "%04d  %s", i, in.String())
	}
	return b.String(), nil
}
