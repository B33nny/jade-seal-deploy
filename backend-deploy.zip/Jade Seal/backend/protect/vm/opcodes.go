package vm

// Opcode is the numeric tag for a VM instruction. Each opcode is one byte
// in the bytecode stream; any immediates follow immediately after it.
type Opcode byte

// The v0 instruction set. Keep them in one block so the encoding table
// below stays in sync.
//
//	push  int64   -- push an immediate
//	pop            -- discard top of stack
//	load  slot     -- push locals[slot]
//	store slot     -- pop top, store into locals[slot]
//	add/sub/mul/div/mod     -- binary int64 arithmetic
//	neg/not/and/or/xor      -- unary / bitwise / logical
//	eq/lt/gt                -- comparison, pushes 0 or 1
//	jmp  offset             -- pc += offset
//	jz   offset             -- if top == 0 { pc += offset; pop }
//	jnz  offset             -- if top != 0 { pc += offset; pop }
//	call offset             -- push return pc, pc += offset
//	ret                     -- pop return pc into pc
//	halt                    -- stop, leaving top of stack as the result
const (
	OpPush Opcode = iota
	OpPop
	OpLoad
	OpStore
	OpAdd
	OpSub
	OpMul
	OpDiv
	OpMod
	OpNeg
	OpNot
	OpAnd
	OpOr
	OpXor
	OpEq
	OpLt
	OpGt
	OpJmp
	OpJz
	OpJnz
	OpCall
	OpRet
	OpHalt
)

// opcodeName maps every opcode to a short, human-readable mnemonic. It is
// the single source of truth for Disassemble() and the human text-parser
// in the Assembler; the reverse lookup is in opcodesByName below.
var opcodeName = map[Opcode]string{
	OpPush:  "push",
	OpPop:   "pop",
	OpLoad:  "load",
	OpStore: "store",
	OpAdd:   "add",
	OpSub:   "sub",
	OpMul:   "mul",
	OpDiv:   "div",
	OpMod:   "mod",
	OpNeg:   "neg",
	OpNot:   "not",
	OpAnd:   "and",
	OpOr:    "or",
	OpXor:   "xor",
	OpEq:    "eq",
	OpLt:    "lt",
	OpGt:   "gt",
	OpJmp:   "jmp",
	OpJz:    "jz",
	OpJnz:   "jnz",
	OpCall:  "call",
	OpRet:   "ret",
	OpHalt:  "halt",
}

// opcodesByName is the reverse lookup. Populated in init() so we have one
// map to maintain, not two.
var opcodesByName = func() map[string]Opcode {
	m := make(map[string]Opcode, len(opcodeName))
	for op, name := range opcodeName {
		m[name] = op
	}
	return m
}()

// Name returns the mnemonic for an opcode. Unknown opcodes produce an
// empty string — the caller is expected to treat that as a bad-opcode
// error.
func (op Opcode) Name() string { return opcodeName[op] }

// LookupOpcode returns the opcode for a mnemonic, or false if the name is
// not a v0 instruction.
func LookupOpcode(name string) (Opcode, bool) {
	op, ok := opcodesByName[name]
	return op, ok
}

// AllOpcodes returns the registered opcode set in numeric order. It is
// only used by tests.
func AllOpcodes() []Opcode {
	out := make([]Opcode, 0, len(opcodeName))
	for op := range opcodeName {
		out = append(out, op)
	}
	return out
}
