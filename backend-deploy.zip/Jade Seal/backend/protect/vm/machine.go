package vm

import (
	"encoding/binary"
	"fmt"
)

// Machine is the live interpreter state for one Run().
//
// It is intentionally a plain struct, not a goroutine-safe object. The
// caller creates one per execution; the package never mutates a shared
// instance across goroutines.
type Machine struct {
	code   []byte
	pc     int
	stack  []int64
	locals []int64
	calls  []int
	steps  int
}

// NewMachine constructs an interpreter bound to the given bytecode and
// pre-loads locals[0..len(args)-1] from args. By convention slot 0
// receives the first argument, slot 1 the second, etc.
//
// locals is allocated up front and never grows, so a malformed bytecode
// that writes to an arbitrary slot cannot leak heap.
func NewMachine(code []byte, args ...int64) (*Machine, error) {
	if len(args) > MaxLocals {
		return nil, fmt.Errorf("vm: too many args: %d > %d", len(args), MaxLocals)
	}
	locals := make([]int64, MaxLocals)
	for i, a := range args {
		locals[i] = a
	}
	return &Machine{
		code:   code,
		pc:     0,
		stack:  make([]int64, 0, 32),
		locals: locals,
		calls:  make([]int, 0, 8),
	}, nil
}

// Push is exposed for embedders who want to feed values into the machine
// before calling Step() / Run(). It is not used by Run() itself.
func (m *Machine) Push(v int64) error {
	if len(m.stack) >= MaxStack {
		return ErrStackOverflow
	}
	m.stack = append(m.stack, v)
	return nil
}

// Step executes one instruction and returns true if execution should
// continue, false if the machine halted. Errors are returned as soon as
// they occur; the machine is left in whatever state it was in.
func (m *Machine) Step() (bool, error) {
	if m.pc < 0 || m.pc >= len(m.code) {
		return false, fmt.Errorf("%w: pc=%d len=%d", ErrTruncated, m.pc, len(m.code))
	}
	m.steps++
	if m.steps > MaxSteps {
		return false, ErrTooManySteps
	}
	op := Opcode(m.code[m.pc])
	if !hasName(op) {
		return false, fmt.Errorf("%w: 0x%02x at pc=%d", ErrBadOpcode, byte(op), m.pc)
	}
	m.pc++
	switch op {
	case OpPush:
		if m.pc+8 > len(m.code) {
			return false, ErrTruncated
		}
		v := int64(binary.LittleEndian.Uint64(m.code[m.pc : m.pc+8]))
		m.pc += 8
		if err := m.Push(v); err != nil {
			return false, err
		}
	case OpPop:
		if len(m.stack) == 0 {
			return false, ErrStackUnderflow
		}
		m.stack = m.stack[:len(m.stack)-1]
	case OpLoad:
		if m.pc+8 > len(m.code) {
			return false, ErrTruncated
		}
		slot := int(int64(binary.LittleEndian.Uint64(m.code[m.pc : m.pc+8])))
		m.pc += 8
		if slot < 0 || slot >= MaxLocals {
			return false, fmt.Errorf("vm: bad locals slot %d", slot)
		}
		if err := m.Push(m.locals[slot]); err != nil {
			return false, err
		}
	case OpStore:
		if m.pc+8 > len(m.code) {
			return false, ErrTruncated
		}
		slot := int(int64(binary.LittleEndian.Uint64(m.code[m.pc : m.pc+8])))
		m.pc += 8
		if slot < 0 || slot >= MaxLocals {
			return false, fmt.Errorf("vm: bad locals slot %d", slot)
		}
		if len(m.stack) == 0 {
			return false, ErrStackUnderflow
		}
		v := m.stack[len(m.stack)-1]
		m.stack = m.stack[:len(m.stack)-1]
		m.locals[slot] = v
	case OpAdd, OpSub, OpMul, OpDiv, OpMod, OpEq, OpLt, OpGt, OpAnd, OpOr, OpXor:
		if err := m.binop(op); err != nil {
			return false, err
		}
	case OpNeg, OpNot:
		if err := m.unop(op); err != nil {
			return false, err
		}
	case OpJmp:
		if m.pc+8 > len(m.code) {
			return false, ErrTruncated
		}
		off := int64(binary.LittleEndian.Uint64(m.code[m.pc : m.pc+8]))
		m.pc += 8
		if err := m.jump(off); err != nil {
			return false, err
		}
	case OpJz:
		if m.pc+8 > len(m.code) {
			return false, ErrTruncated
		}
		off := int64(binary.LittleEndian.Uint64(m.code[m.pc : m.pc+8]))
		m.pc += 8
		if len(m.stack) == 0 {
			return false, ErrStackUnderflow
		}
		cond := m.stack[len(m.stack)-1]
		m.stack = m.stack[:len(m.stack)-1]
		if cond == 0 {
			if err := m.jump(off); err != nil {
				return false, err
			}
		}
	case OpJnz:
		if m.pc+8 > len(m.code) {
			return false, ErrTruncated
		}
		off := int64(binary.LittleEndian.Uint64(m.code[m.pc : m.pc+8]))
		m.pc += 8
		if len(m.stack) == 0 {
			return false, ErrStackUnderflow
		}
		cond := m.stack[len(m.stack)-1]
		m.stack = m.stack[:len(m.stack)-1]
		if cond != 0 {
			if err := m.jump(off); err != nil {
				return false, err
			}
		}
	case OpCall:
		if m.pc+8 > len(m.code) {
			return false, ErrTruncated
		}
		off := int64(binary.LittleEndian.Uint64(m.code[m.pc : m.pc+8]))
		m.pc += 8
		if len(m.calls) >= 256 {
			return false, ErrCallOver
		}
		m.calls = append(m.calls, m.pc)
		if err := m.jump(off); err != nil {
			return false, err
		}
	case OpRet:
		if len(m.calls) == 0 {
			return false, fmt.Errorf("vm: ret with empty call stack")
		}
		ret := m.calls[len(m.calls)-1]
		m.calls = m.calls[:len(m.calls)-1]
		m.pc = ret
	case OpHalt:
		return false, nil
	default:
		return false, fmt.Errorf("%w: opcode %s", ErrBadOpcode, op.Name())
	}
	return true, nil
}

// jump applies a relative offset to pc. We allow both forward and backward
// jumps; the only constraint is that the destination is inside code.
func (m *Machine) jump(off int64) error {
	dest := m.pc + int(off)
	if dest < 0 || dest > len(m.code) {
		return fmt.Errorf("%w: offset=%d pc=%d len=%d", ErrBadJumpTarget, off, m.pc, len(m.code))
	}
	m.pc = dest
	return nil
}

// binop pops the right operand, then the left operand, and pushes the
// result. The "right then left" order matters for div/mod but not for the
// commutative ops — keeping it consistent makes the implementation boring
// and obvious.
func (m *Machine) binop(op Opcode) error {
	if len(m.stack) < 2 {
		return ErrStackUnderflow
	}
	r := m.stack[len(m.stack)-1]
	l := m.stack[len(m.stack)-2]
	m.stack = m.stack[:len(m.stack)-2]
	var out int64
	switch op {
	case OpAdd:
		out = l + r
	case OpSub:
		out = l - r
	case OpMul:
		out = l * r
	case OpDiv:
		if r == 0 {
			return ErrDivByZero
		}
		// Match Go's semantics: l/r truncates toward zero. MinInt64 / -1
		// overflows; we just let it wrap — that matches the hardware.
		out = l / r
	case OpMod:
		if r == 0 {
			return ErrModByZero
		}
		out = l % r
	case OpEq:
		if l == r {
			out = 1
		}
	case OpLt:
		if l < r {
			out = 1
		}
	case OpGt:
		if l > r {
			out = 1
		}
	case OpAnd:
		out = l & r
	case OpOr:
		out = l | r
	case OpXor:
		out = l ^ r
	default:
		return fmt.Errorf("%w: binary %s", ErrBadOpcode, op.Name())
	}
	if err := m.Push(out); err != nil {
		return err
	}
	return nil
}

// unop pops one value and pushes its transformed result.
func (m *Machine) unop(op Opcode) error {
	if len(m.stack) == 0 {
		return ErrStackUnderflow
	}
	v := m.stack[len(m.stack)-1]
	m.stack = m.stack[:len(m.stack)-1]
	var out int64
	switch op {
	case OpNeg:
		out = -v
	case OpNot:
		if v == 0 {
			out = 1
		}
	default:
		return fmt.Errorf("%w: unary %s", ErrBadOpcode, op.Name())
	}
	if err := m.Push(out); err != nil {
		return err
	}
	return nil
}

// Run executes the program to completion. The top of the stack on `halt`
// is returned as the result; an empty stack on halt returns 0.
//
// args are bound to locals[0..len(args)-1] before execution starts.
func Run(program []byte, args ...int64) (int64, error) {
	m, err := NewMachine(program, args...)
	if err != nil {
		return 0, err
	}
	for {
		cont, err := m.Step()
		if err != nil {
			return 0, err
		}
		if !cont {
			break
		}
	}
	if len(m.stack) == 0 {
		return 0, nil
	}
	return m.stack[len(m.stack)-1], nil
}

// PC exposes the current program counter. Useful for tests / debuggers.
func (m *Machine) PC() int { return m.pc }

// StackDepth exposes the current stack height.
func (m *Machine) StackDepth() int { return len(m.stack) }

// Steps returns how many instructions have executed so far.
func (m *Machine) Steps() int { return m.steps }
