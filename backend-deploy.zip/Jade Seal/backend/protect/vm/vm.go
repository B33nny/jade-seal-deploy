// Package vm implements a small, custom stack-based virtual machine used by
// Jade Seal's code-virtualisation protection (§5.5 of the architecture doc).
//
// # What a VM is, in plain English
//
// A virtual machine (VM) is a tiny computer that lives inside the real one.
// Instead of executing your function's original x86/ARM instructions, you
// translate them into a private instruction set — "bytecode" — and ship a
// small interpreter that runs that bytecode. The original instructions
// never appear in the binary, so an attacker disassembling the release
// sees only the interpreter loop and an opaque blob of bytes.
//
// # Scope of THIS package (the v0 primitive)
//
// This is the honest baseline:
//
//   - A fixed, single interpreter ("v0"). Every protected function runs on
//     the same instruction set.
//   - One stack, one call stack, one small locals frame. No registers.
//   - Hand-authored translation of small expression trees only — the
//     demonstrator hard-codes `a*b + 7` into bytecode to prove the flow.
//   - Int64 arithmetic only. No floats, no objects, no syscalls.
//
// Explicitly OUT of scope (called out so we don't oversell):
//
//   - Per-function VM diversification ("v1"): each protected function gets
//     its own randomised opcode table, junk-byte dispatcher, etc. That is a
//     Phase B/C hardening item, not v0.
//   - Native x86/ARM VMs ("v2"): a JIT or translator that maps VM bytecode
//     back to real CPU instructions. v0 is interpreter-only.
//   - Lifting arbitrary Go SSA or real machine code into VM bytecode. v0
//     translates only the tiny fixed expression patterns in Protect().
//
// # AV-false-positive warning
//
// Custom interpreters are notoriously AV-unfriendly: the dispatcher loop
// plus an arithmetic-heavy bytecode blob looks like a polymorphic
// cryptor or a shellcode stager to many heuristics. Per §5.5, apply VM
// protection ONLY to one or two high-value functions (e.g. the final
// licence-check), never blanket the codebase.
package vm

import "errors"

// MaxStack is the interpreter's hard stack depth. A program that grows the
// stack beyond this returns ErrStackOverflow rather than panicking.
const MaxStack = 4096

// MaxSteps bounds how many instructions a single Run() may execute. It is a
// guard against runaway / maliciously crafted bytecode, not a real limit
// for honest programs.
const MaxSteps = 1 << 20 // ~1M ops

// MaxLocals is the size of the locals frame.
const MaxLocals = 256

// Errors returned by the interpreter. They are sentinel values so callers
// can errors.Is() against them.
var (
	ErrBadOpcode     = errors.New("vm: bad opcode")
	ErrTruncated     = errors.New("vm: truncated instruction")
	ErrStackUnderflow = errors.New("vm: stack underflow")
	ErrStackOverflow  = errors.New("vm: stack overflow")
	ErrDivByZero      = errors.New("vm: division by zero")
	ErrModByZero      = errors.New("vm: modulo by zero")
	ErrBadJumpTarget  = errors.New("vm: jump target out of range")
	ErrCallOver       = errors.New("vm: call depth exceeded")
	ErrTooManySteps   = errors.New("vm: step limit exceeded")
)
