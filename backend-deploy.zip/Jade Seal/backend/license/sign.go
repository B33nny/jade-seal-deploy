// Package license implements Jade Seal's license token signing: an Ed25519
// private key signs a canonical, deterministic description of a license's
// entitlements; only the public key is ever exposed, so a customer's app can
// verify a license offline without holding any authority secret (§6.10).
package license

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"
)

var (
	priv ed25519.PrivateKey
	pub  ed25519.PublicKey
)

// Token is the set of fields a license signature attests to. It deliberately
// excludes the mutable `status` and the bind-time `hardware_fingerprint` —
// revocation and machine-lock stay server-side (see the architecture doc §6).
type Token struct {
	LicenseID string
	ProductID string
	OrgID     string
	Model     string
	Email     string
	Features  []string
	MaxSeats  int
	ExpiresAt time.Time // zero value = perpetual
}

// payload is the exact, field-ordered struct that is marshalled and signed.
// json.Marshal on a struct is deterministic (fixed field order, slices in
// order), so the same Token always produces the same bytes to sign and verify.
type payload struct {
	V         int      `json:"v"`
	ID        string   `json:"id"`
	Product   string   `json:"product"`
	Org       string   `json:"org"`
	Model     string   `json:"model"`
	Email     string   `json:"email"`
	Features  []string `json:"features"`
	MaxSeats  int      `json:"max_seats"`
	ExpiresAt int64    `json:"expires_at"` // unix seconds, 0 = perpetual
}

func (t Token) canonical() ([]byte, error) {
	features := t.Features
	if features == nil {
		features = []string{}
	}
	var exp int64
	if !t.ExpiresAt.IsZero() {
		exp = t.ExpiresAt.Unix()
	}
	return json.Marshal(payload{
		V:         1,
		ID:        t.LicenseID,
		Product:   t.ProductID,
		Org:       t.OrgID,
		Model:     t.Model,
		Email:     t.Email,
		Features:  features,
		MaxSeats:  t.MaxSeats,
		ExpiresAt: exp,
	})
}

// Init loads or creates the Ed25519 signing keypair. The private key stays in
// memory (and, if generated, in a 0600 file); only the public key is ever
// handed out. Priority: seedEnv (hex) → keyPath file → generate + persist.
func Init(seedEnv, keyPath string) error {
	switch {
	case seedEnv != "":
		seed, err := hex.DecodeString(strings.TrimSpace(seedEnv))
		if err != nil {
			return fmt.Errorf("LICENSE_SIGNING_KEY is not valid hex: %w", err)
		}
		if len(seed) != ed25519.SeedSize {
			return fmt.Errorf("LICENSE_SIGNING_KEY must be %d bytes", ed25519.SeedSize)
		}
		priv = ed25519.NewKeyFromSeed(seed)
	default:
		seed, err := loadOrCreateSeed(keyPath)
		if err != nil {
			return err
		}
		priv = ed25519.NewKeyFromSeed(seed)
	}
	pub = priv.Public().(ed25519.PublicKey)
	return nil
}

func loadOrCreateSeed(keyPath string) ([]byte, error) {
	if keyPath == "" {
		keyPath = "jade-seal-signing.key"
	}
	if b, err := os.ReadFile(keyPath); err == nil {
		seed, derr := hex.DecodeString(strings.TrimSpace(string(b)))
		if derr != nil || len(seed) != ed25519.SeedSize {
			return nil, fmt.Errorf("%s does not hold a valid Ed25519 seed", keyPath)
		}
		return seed, nil
	}
	seed := make([]byte, ed25519.SeedSize)
	if _, err := rand.Read(seed); err != nil {
		return nil, fmt.Errorf("generate signing seed: %w", err)
	}
	if err := os.WriteFile(keyPath, []byte(hex.EncodeToString(seed)), 0600); err != nil {
		return nil, fmt.Errorf("persist signing seed: %w", err)
	}
	return seed, nil
}

// Sign returns the hex-encoded Ed25519 signature over the token's canonical
// bytes. It requires Init to have been called.
func Sign(t Token) (string, error) {
	if priv == nil {
		return "", errors.New("license signing key not initialised")
	}
	msg, err := t.canonical()
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(ed25519.Sign(priv, msg)), nil
}

// Verify reports whether sigHex is a valid signature over the token's
// canonical bytes under the loaded public key.
func Verify(t Token, sigHex string) bool {
	if pub == nil {
		return false
	}
	sig, err := hex.DecodeString(strings.TrimSpace(sigHex))
	if err != nil {
		return false
	}
	msg, err := t.canonical()
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, msg, sig)
}

// PublicKeyHex returns the hex-encoded public key — the only key a customer's
// app should receive. Empty if Init has not run.
func PublicKeyHex() string {
	if pub == nil {
		return ""
	}
	return hex.EncodeToString(pub)
}

// SigningSeed returns the 32-byte Ed25519 seed of the loaded signing key. The
// packer derives its own key from this seed (domain-separated via HKDF), so the
// packer key is stable across restarts without managing a second secret. The
// returned slice is a copy.
func SigningSeed() ([]byte, error) {
	if priv == nil {
		return nil, errors.New("license signing key not initialised")
	}
	seed := priv.Seed()
	out := make([]byte, len(seed))
	copy(out, seed)
	return out, nil
}

// GenerateKey returns a fresh, unguessable license key: 24 random bytes encoded
// as 32 URL-safe base64 characters (192 bits of entropy) under a "js-" prefix.
// This is the bearer token a customer copies — the customer's only credential,
// deliberately distinct from the enumerable internal DB id (§6.4).
func GenerateKey() (string, error) {
	b := make([]byte, 24)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return "js-" + base64.RawURLEncoding.EncodeToString(b), nil
}

// Activation is the signed "you may run" token returned by online activation
// (§6.4). It binds a seat to a specific machine fingerprint, so a client can
// prove — offline, against the public key — that this license was activated for
// this hardware and has not yet expired.
type Activation struct {
	LicenseID string
	SeatID    string
	FPHash    string
	MaxSeats  int
	IssuedAt  time.Time
	ExpiresAt time.Time // zero = perpetual
}

type activationPayload struct {
	V        int    `json:"v"`
	License  string `json:"license"`
	Seat     string `json:"seat"`
	FPHash   string `json:"fp"`
	MaxSeats int    `json:"max_seats"`
	IssuedAt int64  `json:"issued_at"`
	ExpiresAt int64  `json:"expires_at"` // unix seconds, 0 = perpetual
}

func (a Activation) canonical() ([]byte, error) {
	var exp int64
	if !a.ExpiresAt.IsZero() {
		exp = a.ExpiresAt.Unix()
	}
	return json.Marshal(activationPayload{
		V:        1,
		License:  a.LicenseID,
		Seat:     a.SeatID,
		FPHash:   a.FPHash,
		MaxSeats: a.MaxSeats,
		IssuedAt: a.IssuedAt.Unix(),
		ExpiresAt: exp,
	})
}

// SignActivation signs an activation claim under the platform key.
func SignActivation(a Activation) (string, error) {
	if priv == nil {
		return "", errors.New("license signing key not initialised")
	}
	msg, err := a.canonical()
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(ed25519.Sign(priv, msg)), nil
}

// VerifyActivation reports whether sigHex is a valid signature over the
// activation claim under the loaded public key.
func VerifyActivation(a Activation, sigHex string) bool {
	if pub == nil {
		return false
	}
	sig, err := hex.DecodeString(strings.TrimSpace(sigHex))
	if err != nil {
		return false
	}
	msg, err := a.canonical()
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, msg, sig)
}

// CRL is the signed certificate-revocation-list claim (§6.8): the set of
// revoked license ids at a given monotonic sequence. It is signed so a client
// can verify it offline against the public key, and the sequence only ever
// increases so a stale CRL cannot be replayed to "un-revoke" a license.
type CRL struct {
	Sequence   int64
	LicenseIDs []string
}

type crlPayload struct {
	V          int      `json:"v"`
	Sequence   int64    `json:"seq"`
	LicenseIDs []string `json:"license_ids"`
}

func (c CRL) canonical() ([]byte, error) {
	ids := c.LicenseIDs
	if ids == nil {
		ids = []string{}
	}
	return json.Marshal(crlPayload{V: 1, Sequence: c.Sequence, LicenseIDs: ids})
}

// SignCRL signs a revocation list under the platform key.
func SignCRL(c CRL) (string, error) {
	if priv == nil {
		return "", errors.New("license signing key not initialised")
	}
	msg, err := c.canonical()
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(ed25519.Sign(priv, msg)), nil
}

// VerifyCRL reports whether sigHex is a valid signature over the CRL under the
// loaded public key.
func VerifyCRL(c CRL, sigHex string) bool {
	if pub == nil {
		return false
	}
	sig, err := hex.DecodeString(strings.TrimSpace(sigHex))
	if err != nil {
		return false
	}
	msg, err := c.canonical()
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, msg, sig)
}
