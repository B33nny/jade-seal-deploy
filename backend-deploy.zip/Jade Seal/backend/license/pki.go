// Package license — the PKI layer (pki.go).
//
// This file implements Jade Seal's two-level software PKI, the design called
// out in §6.11 of the architecture doc:
//
//	ROOT (offline, air-gapped)
//	  │
//	  │ signs an INTERMEDIATE certificate
//	  ▼
//	INTERMEDIATE (online, in the signing service)
//	  │
//	  │ signs every License / Activation / CRL token
//	  ▼
//	TOKEN (delivered to customers; verified against the intermediate's pub)
//
// Why two levels, not one:
//
//  1. The root key is the single point of trust for the whole platform. If it
//     leaks, every customer and every historical license is compromised, and
//     there is no way to recover short of a coordinated, customer-visible key
//     rotation. So the root lives offline — generated on a machine that never
//     touches the network, stored on hardware that is physically locked away,
//     and used only to sign intermediate certificates (a rare, manual event).
//
//  2. The intermediate is the key that actually signs traffic. It lives on
//     the signing service, signs every license it issues, and is rotated on
//     routine schedules (and on suspicion of compromise). Rotating the
//     intermediate does NOT require touching the root — the root stays put
//     and signs a fresh intermediate. Customers only need to learn the new
//     intermediate's public key (via the cert chain they trust back to the
//     root), which is the same dual-active window that TLS CAs use.
//
//  3. Losing the intermediate is recoverable without a customer-visible
//     outage: issue a new intermediate, sign it with the offline root, ship
//     the new cert + pub to the signing service. Losing the root is
//     catastrophic: every issued token must be re-signed and every customer's
//     trust store updated — equivalent to re-issuing the entire PKI.
//
//  4. In production this code is the *software layer* that an HSM (AWS
//     CloudHSM or YubiHSM2) eventually backs. The functions here take and
//     return ed25519 keys; swapping in an HSM-backed signer is a matter of
//     replacing the raw signing calls with the HSM's API. The structures
//     (keys, certs, manifests) are the durable contract.
//
// The piece in this file are exactly the offline-root / online-intermediate
// hierarchy plus a rotation scaffold. The Token sign/verify path is
// deliberately kept in sync with sign.go's canonical form so a token signed
// here (with the intermediate) verifies identically under the same Token
// type.
package license

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

// Keypair is an Ed25519 keypair plus its seed. The seed is returned so the
// caller can persist it (HSM migration should replace persistence, not sign).
type Keypair struct {
	Private ed25519.PrivateKey
	Public  ed25519.PublicKey
	Seed    []byte // 32-byte Ed25519 seed; nil when reconstructed from pub only
}

// GenerateRootKey returns a fresh Ed25519 keypair intended for the offline
// root. The seed is the only thing that needs to be backed up — losing only
// the in-memory private key is fine because the seed deterministically
// reconstructs the pair via ed25519.NewKeyFromSeed.
func GenerateRootKey() (Keypair, error) {
	return generateKeypair()
}

// GenerateIntermediateKey returns a fresh Ed25519 keypair intended for the
// online signing service (the intermediate). Same shape as the root; the
// "offline / online" distinction is operational, not cryptographic.
func GenerateIntermediateKey() (Keypair, error) {
	return generateKeypair()
}

// KeypairFromSeed reconstructs a keypair from a 32-byte Ed25519 seed. This
// is how the root is rebuilt from cold storage on the offline box.
func KeypairFromSeed(seed []byte) (Keypair, error) {
	if len(seed) != ed25519.SeedSize {
		return Keypair{}, fmt.Errorf("seed must be %d bytes, got %d", ed25519.SeedSize, len(seed))
	}
	priv := ed25519.NewKeyFromSeed(seed)
	seedCopy := make([]byte, len(seed))
	copy(seedCopy, seed)
	return Keypair{Private: priv, Public: priv.Public().(ed25519.PublicKey), Seed: seedCopy}, nil
}

func generateKeypair() (Keypair, error) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return Keypair{}, fmt.Errorf("generate ed25519 keypair: %w", err)
	}
	seed := priv.Seed()
	seedCopy := make([]byte, len(seed))
	copy(seedCopy, seed)
	return Keypair{Private: priv, Public: pub, Seed: seedCopy}, nil
}

// KeyID is a deterministic, short identifier for an Ed25519 public key.
//
// Scheme: base64url(no padding) of the first 8 bytes of SHA-256(pubkey).
// That gives 64 bits of collision resistance from a 256-bit public key —
// more than enough to disambiguate intermediates in a manifest, short
// enough to embed in logs and audit records, and stable across serialisations
// (it only depends on the public-key bytes, not on how the key is stored).
func KeyID(pub ed25519.PublicKey) string {
	sum := sha256.Sum256(pub)
	return base64.RawURLEncoding.EncodeToString(sum[:8])
}

// IntermediateCert is the root's signed attestation that "this public key is
// an intermediate, trust it for token signatures, until notAfter".
//
// Version is the cert format version (currently 1). Kid is the intermediate's
// KeyID so the manifest can look it up by name. PublicKey is the hex-encoded
// raw Ed25519 public key. NotBefore / NotAfter are unix seconds; the cert is
// valid when notBefore <= now < notAfter. Signature is the root's Ed25519
// signature over the canonical serialisation of every other field, in this
// order:
//
//	{"v":1,"kid":"...","public_key":"...","not_before":N,"not_after":M}
//
// That field order is fixed by the intermediateCertPayload struct, so any
// two implementations that marshal with the same struct agree on the bytes.
type IntermediateCert struct {
	Version   int    `json:"v"`
	Kid       string `json:"kid"`
	PublicKey string `json:"public_key"`
	NotBefore int64  `json:"not_before"`
	NotAfter  int64  `json:"not_after"`
	Signature string `json:"signature"`
}

// intermediateCertPayload is the canonical, signed form of an intermediate
// cert. Mirrors IntermediateCert minus the Signature field, in fixed order.
type intermediateCertPayload struct {
	Version   int    `json:"v"`
	Kid       string `json:"kid"`
	PublicKey string `json:"public_key"`
	NotBefore int64  `json:"not_before"`
	NotAfter  int64  `json:"not_after"`
}

func (c IntermediateCert) canonical() ([]byte, error) {
	return json.Marshal(intermediateCertPayload{
		Version:   c.Version,
		Kid:       c.Kid,
		PublicKey: c.PublicKey,
		NotBefore: c.NotBefore,
		NotAfter:  c.NotAfter,
	})
}

// SignIntermediate has the root key sign an attestation for an intermediate
// public key, valid in [notBefore, notAfter). The returned cert holds the
// intermediate's pub, the validity window, and the root's signature — the
// whole thing the customer's app needs to decide "I trust this intermediate".
func SignIntermediate(rootPriv ed25519.PrivateKey, intermediatePub ed25519.PublicKey, notBefore, notAfter int64) (*IntermediateCert, error) {
	if rootPriv == nil {
		return nil, errors.New("root private key is nil")
	}
	if intermediatePub == nil {
		return nil, errors.New("intermediate public key is nil")
	}
	if notAfter <= notBefore {
		return nil, fmt.Errorf("notAfter (%d) must be greater than notBefore (%d)", notAfter, notBefore)
	}
	cert := &IntermediateCert{
		Version:   1,
		Kid:       KeyID(intermediatePub),
		PublicKey: hex.EncodeToString(intermediatePub),
		NotBefore: notBefore,
		NotAfter:  notAfter,
	}
	msg, err := cert.canonical()
	if err != nil {
		return nil, fmt.Errorf("canonicalise cert: %w", err)
	}
	cert.Signature = hex.EncodeToString(ed25519.Sign(rootPriv, msg))
	return cert, nil
}

// VerifyIntermediateCert reports whether the cert's signature is valid under
// rootPub. It does NOT check the validity window — callers that care (e.g.
// Token verification) should check CertValidAt themselves. It does NOT check
// that the cert's embedded public key matches any particular intermediate;
// ChainVerify does that.
func VerifyIntermediateCert(rootPub ed25519.PublicKey, cert *IntermediateCert) bool {
	if rootPub == nil || cert == nil {
		return false
	}
	sig, err := hex.DecodeString(cert.Signature)
	if err != nil {
		return false
	}
	msg, err := cert.canonical()
	if err != nil {
		return false
	}
	return ed25519.Verify(rootPub, msg, sig)
}

// CertValidAt reports whether `now` (in seconds) is inside the cert's
// [notBefore, notAfter) window.
func CertValidAt(cert *IntermediateCert, now int64) bool {
	if cert == nil {
		return false
	}
	return now >= cert.NotBefore && now < cert.NotAfter
}

// ChainVerify verifies the full trust chain: the root pub certifies the
// intermediate pub via the cert, AND the cert's embedded public key matches
// the intermediate pub the caller actually plans to use. A verifier that
// holds only the root pub can therefore trust an intermediate pub handed to
// it by a signing service.
func ChainVerify(rootPub ed25519.PublicKey, cert *IntermediateCert, intermediatePub ed25519.PublicKey) bool {
	if cert == nil || intermediatePub == nil {
		return false
	}
	if !VerifyIntermediateCert(rootPub, cert) {
		return false
	}
	got, err := hex.DecodeString(cert.PublicKey)
	if err != nil {
		return false
	}
	if len(got) != len(intermediatePub) {
		return false
	}
	for i := range got {
		if got[i] != intermediatePub[i] {
			return false
		}
	}
	return true
}

// tokenPayload is the canonical signed form of a Token. Mirrors the payload
// in sign.go exactly (same field order, same semantic for nil/zero) so a
// SignWithKey here and a Sign in sign.go produce interchangeable bytes for
// the same Token value. This is what lets the signing service swap the
// intermediate in for the platform key without breaking verifiers.
type tokenPayload struct {
	V         int      `json:"v"`
	ID        string   `json:"id"`
	Product   string   `json:"product"`
	Org       string   `json:"org"`
	Model     string   `json:"model"`
	Email     string   `json:"email"`
	Features  []string `json:"features"`
	MaxSeats  int      `json:"max_seats"`
	ExpiresAt int64    `json:"expires_at"`
}

// canonicalToken is the package-internal helper that gives pki clients the
// same canonical bytes the existing Token verifier uses. Exported so callers
// can canonicalise a Token without having to import sign.go internals; kept
// deliberately in sync with Token.canonical() in sign.go (identical struct
// literal, identical nil/empty/unix-zero handling).
func canonicalToken(t Token) ([]byte, error) {
	features := t.Features
	if features == nil {
		features = []string{}
	}
	var exp int64
	if !t.ExpiresAt.IsZero() {
		exp = t.ExpiresAt.Unix()
	}
	return json.Marshal(tokenPayload{
		V:         1,
		ID:        t.LicenseID,
		Product:   t.ProductID,
		Org:       t.OrgID,
		Model:     t.Model,
		Email:     t.Email,
		Features:  features,
		MaxSeats:  t.MaxSeats,
		ExpiresAt: exp,
	})
}

// SignWithKey signs a Token under an arbitrary Ed25519 private key. This is
// the intermediate's signing path. Sig is hex-encoded for portability. The
// returned bytes are identical to the bytes sign.go's Sign would produce for
// the same Token + matching key, so verifiers written against either path
// accept the signature.
func SignWithKey(priv ed25519.PrivateKey, token Token) (string, error) {
	if priv == nil {
		return "", errors.New("private key is nil")
	}
	msg, err := canonicalToken(token)
	if err != nil {
		return "", fmt.Errorf("canonicalise token: %w", err)
	}
	return hex.EncodeToString(ed25519.Sign(priv, msg)), nil
}

// VerifyWithKey verifies a Token signature under an arbitrary Ed25519 public
// key. This is the "verify with the intermediate's pub" path.
func VerifyWithKey(pub ed25519.PublicKey, token Token, sigHex string) bool {
	if pub == nil {
		return false
	}
	sig, err := hex.DecodeString(sigHex)
	if err != nil {
		return false
	}
	msg, err := canonicalToken(token)
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, msg, sig)
}

// KeyManifest is the public, signed-by-the-root view of "which intermediates
// exist, and which one is currently active". A customer app can ship the
// root public key once and then accept any cert the manifest lists while
// it is inside the dual-active window.
//
// RootPub is the offline root's public key (the customer's trust anchor).
// Intermediates is every cert the root has signed, current or historical.
// CurrentKid is the intermediate a new Token should be expected under; it
// may differ from the kid of the cert that signed a specific historical
// token (rotation in flight).
type KeyManifest struct {
	RootPub      string             `json:"root_pub"`
	Intermediates []IntermediateCert `json:"intermediates"`
	CurrentKid   string             `json:"current_kid"`
}

// BuildManifest assembles a manifest from a root pub and a list of certs.
// It does NOT verify the certs against the root — that's the caller's job
// (the manifest itself is signed by the shipping process, not by the root),
// but every cert listed here is expected to be verified by ChainVerify
// before it is used.
func BuildManifest(rootPub ed25519.PublicKey, currentKid string, certs ...*IntermediateCert) KeyManifest {
	cs := make([]IntermediateCert, 0, len(certs))
	for _, c := range certs {
		if c != nil {
			cs = append(cs, *c)
		}
	}
	return KeyManifest{
		RootPub:       hex.EncodeToString(rootPub),
		Intermediates: cs,
		CurrentKid:    currentKid,
	}
}

// ValidIntermediates returns the subset of the manifest's certs that are
// currently valid at `now` — i.e. inside [notBefore, notAfter). Caller is
// still responsible for ChainVerify-ing each returned cert against the
// manifest's root pub. This is the "dual-active window" query: during a
// rotation, two intermediates may both be valid for a while so old tokens
// keep verifying while new tokens sign under the fresh key.
func (m KeyManifest) ValidIntermediates(now int64) []IntermediateCert {
	out := make([]IntermediateCert, 0, len(m.Intermediates))
	for _, c := range m.Intermediates {
		if CertValidAt(&c, now) {
			out = append(out, c)
		}
	}
	return out
}

// ValidNow is a convenience over ValidIntermediates using time.Now().Unix().
func (m KeyManifest) ValidNow() []IntermediateCert {
	return m.ValidIntermediates(time.Now().Unix())
}
