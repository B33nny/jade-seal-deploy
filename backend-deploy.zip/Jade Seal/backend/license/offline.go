// Offline activation (§6.5): the c2d/d2c envelope. An air-gapped machine that
// cannot reach the license server mints a *challenge* (c2d), an operator carries
// it to an online box which returns a signed *ticket* (d2c), and the machine
// verifies that ticket against the platform public key — proving the license is
// real and not yet expired, without the server ever being reachable.
package license

import (
	"crypto/ed25519"
	"encoding/hex"
	"encoding/json"
	"errors"
	"strings"
	"time"
)

// OfflineChallenge is the §6.5 c2d message an air-gapped machine generates. It
// carries enough for the online side to (re)verify the license — key, machine
// fingerprint, app id, email — plus a nonce and timestamp so the d2c reply can
// be matched to this exact request and stale requests can be refused.
type OfflineChallenge struct {
	LicenseKey string `json:"license_key"`
	FPHash     string `json:"fp_hash"`
	AppID      string `json:"app_id"`
	Email      string `json:"email"`
	Nonce      string `json:"nonce"`
	TS         int64  `json:"ts"`
}

// OfflineTicket is the §6.5 d2c "you may run" claim. Counter is the monotonic
// per-license counter: a client must reject a ticket whose counter is not
// strictly greater than the last one it accepted, which defeats replaying an old
// ticket. ExpiresAt caps the ticket's life even for a perpetual license.
type OfflineTicket struct {
	LicenseKey string
	SeatID     string
	FPHash     string
	Counter    int64
	IssuedAt   time.Time
	ExpiresAt  time.Time
}

type offlineTicketPayload struct {
	V         int    `json:"v"`
	License   string `json:"license"`
	Seat      string `json:"seat"`
	FPHash    string `json:"fp"`
	Counter   int64  `json:"counter"`
	IssuedAt  int64  `json:"issued_at"`
	ExpiresAt int64  `json:"expires_at"` // unix seconds, 0 = perpetual
}

// canonical returns the deterministic bytes that are signed/verified. It signs
// every field a client must trust — key, seat, fingerprint, counter, both
// timestamps — so tampering any of them breaks the signature.
func (t OfflineTicket) canonical() ([]byte, error) {
	var exp int64
	if !t.ExpiresAt.IsZero() {
		exp = t.ExpiresAt.Unix()
	}
	return json.Marshal(offlineTicketPayload{
		V:         1,
		License:   t.LicenseKey,
		Seat:      t.SeatID,
		FPHash:    t.FPHash,
		Counter:   t.Counter,
		IssuedAt:  t.IssuedAt.Unix(),
		ExpiresAt: exp,
	})
}

// SignOfflineTicket signs an offline ticket under the platform key. Requires Init.
func SignOfflineTicket(t OfflineTicket) (string, error) {
	if priv == nil {
		return "", errors.New("license signing key not initialised")
	}
	msg, err := t.canonical()
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(ed25519.Sign(priv, msg)), nil
}

// VerifyOfflineTicket reports whether sigHex is a valid signature over the
// ticket under the loaded public key. It is what the air-gapped machine runs.
func VerifyOfflineTicket(t OfflineTicket, sigHex string) bool {
	if pub == nil {
		return false
	}
	sig, err := hex.DecodeString(strings.TrimSpace(sigHex))
	if err != nil {
		return false
	}
	msg, err := t.canonical()
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, msg, sig)
}
