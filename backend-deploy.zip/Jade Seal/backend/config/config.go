package config

import (
	"os"
)

type Config struct {
	Port         string
	DatabaseURL  string
	JWTSecret    string
	DockerHost   string
	BenAIAPIKey  string
	CORSOrigins  string
	ArtifactDir  string
	LicenseSigningKey     string
	LicenseSigningKeyPath string
}

func Load() *Config {
	return &Config{
		Port:         getEnv("PORT", "8080"),
		DatabaseURL:  getEnv("DATABASE_URL", "jade-seal.db"),
		JWTSecret:    getEnv("JWT_SECRET", "jade-seal-dev-secret-change-in-production"),
		DockerHost:   getEnv("DOCKER_HOST", "unix:///var/run/docker.sock"),
		BenAIAPIKey:  getEnv("BEN_AI_API_KEY", ""),
		CORSOrigins:  getEnv("CORS_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000"),
		ArtifactDir:  getEnv("ARTIFACT_DIR", "./artifacts"),
		LicenseSigningKey:     getEnv("LICENSE_SIGNING_KEY", ""),
		LicenseSigningKeyPath: getEnv("LICENSE_SIGNING_KEY_PATH", "jade-seal-signing.key"),
	}
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
