package sandbox

import (
	"context"
	"fmt"
	"log"

	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/api/types/mount"
	"github.com/docker/docker/client"
	"github.com/docker/go-connections/nat"
)

type DockerRuntime struct {
	client *client.Client
}

func NewDockerRuntime(host string) (*DockerRuntime, error) {
	cli, err := client.NewClientWithOpts(client.WithHost(host), client.WithAPIVersionNegotiation())
	if err != nil {
		return nil, fmt.Errorf("failed to create Docker client: %w", err)
	}
	return &DockerRuntime{client: cli}, nil
}

func (d *DockerRuntime) Ping() error {
	_, err := d.client.Ping(context.Background())
	return err
}

func (d *DockerRuntime) CreateContainer(name, image string, cpuCores, memoryMB int) (string, error) {
	ctx := context.Background()

	// Pull image if not present
	log.Printf("Pulling image: %s", image)
	// In production we'd use ImagePull, but for dev we skip

	resp, err := d.client.ContainerCreate(ctx,
		&container.Config{
			Image: image,
			Cmd:   []string{"/bin/bash"},
			Tty:   true,
			Env: []string{
				"JADESEAL_SANDBOX=true",
			},
			ExposedPorts: nat.PortSet{
				"8080/tcp": struct{}{},
				"5901/tcp": struct{}{},
			},
		},
		&container.HostConfig{
			Resources: container.Resources{
				CPUCount: int64(cpuCores),
				Memory:   int64(memoryMB) * 1024 * 1024,
			},
			Mounts: []mount.Mount{
				{
					Type:   mount.TypeVolume,
					Source: fmt.Sprintf("jadeseal-%s-data", name),
					Target: "/workspace",
				},
			},
			PortBindings: nat.PortMap{
				"8080/tcp": []nat.PortBinding{{HostIP: "0.0.0.0", HostPort: "0"}},
				"5901/tcp": []nat.PortBinding{{HostIP: "0.0.0.0", HostPort: "0"}},
			},
		},
		nil, nil, name,
	)
	if err != nil {
		return "", fmt.Errorf("failed to create container: %w", err)
	}

	log.Printf("Container created: %s (%s)", resp.ID, name)
	return resp.ID, nil
}

func (d *DockerRuntime) StartContainer(containerID string) error {
	ctx := context.Background()
	return d.client.ContainerStart(ctx, containerID, container.StartOptions{})
}

func (d *DockerRuntime) StopContainer(containerID string) error {
	ctx := context.Background()
	timeout := 30
	return d.client.ContainerStop(ctx, containerID, container.StopOptions{Timeout: &timeout})
}

func (d *DockerRuntime) RemoveContainer(containerID string) error {
	ctx := context.Background()
	return d.client.ContainerRemove(ctx, containerID, container.RemoveOptions{Force: true})
}

func (d *DockerRuntime) GetContainerInfo(containerID string) (status, ip string, port int, err error) {
	ctx := context.Background()
	info, err := d.client.ContainerInspect(ctx, containerID)
	if err != nil {
		return "", "", 0, err
	}

	status = info.State.Status
	if info.NetworkSettings != nil {
		for _, net := range info.NetworkSettings.Networks {
			if net.IPAddress != "" {
				ip = net.IPAddress
				break
			}
		}
	}

	return status, ip, 0, nil
}

func (d *DockerRuntime) ListContainers() ([]string, error) {
	ctx := context.Background()
	containers, err := d.client.ContainerList(ctx, container.ListOptions{All: true})
	if err != nil {
		return nil, err
	}
	ids := make([]string, len(containers))
	for i, c := range containers {
		ids[i] = c.ID[:12]
	}
	return ids, nil
}

func (d *DockerRuntime) Close() error {
	return d.client.Close()
}
