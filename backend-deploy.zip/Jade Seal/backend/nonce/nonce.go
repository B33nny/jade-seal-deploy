// Package nonce implements the anti-replay nonce store of §6.4/§6.12: a
// bounded, TTL-expiring set of already-seen nonces. An activation request that
// reuses a nonce is refused, so a captured request cannot be replayed to mint
// extra seats or extend a quota.
//
// The store is deliberately a small in-memory structure, not the database: a
// nonce only matters within its short clock-skew window, and persisting it adds
// a write on every activation for no replay benefit once it has expired.
package nonce

import (
	"sync"
	"time"
)

// Store is a concurrency-safe, bounded, TTL-expiring set of seen nonces.
type Store struct {
	mu      sync.Mutex
	entries map[string]time.Time
	ttl     time.Duration
	max     int
}

// New returns a store that keeps at most max entries, each valid for ttl.
func New(ttl time.Duration, max int) *Store {
	return &Store{entries: make(map[string]time.Time), ttl: ttl, max: max}
}

// Record reports whether key is fresh. It returns true (and records key) if the
// key has never been seen or its prior entry has expired; it returns false if
// the key is still live — a replay. Callers should key on license+nonce.
func (s *Store) Record(key string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()

	now := time.Now()
	if t, ok := s.entries[key]; ok && now.Sub(t) < s.ttl {
		return false
	}
	s.entries[key] = now

	if len(s.entries) > s.max {
		s.evict(now)
	}
	return true
}

// evict drops expired entries first, then — if still over budget — the oldest
// entry. Called with s.mu held. The store is bounded, so it can never grow
// without limit even under a nonce-flooding attempt.
func (s *Store) evict(now time.Time) {
	for k, t := range s.entries {
		if now.Sub(t) >= s.ttl {
			delete(s.entries, k)
		}
	}
	if len(s.entries) <= s.max {
		return
	}
	var oldestK string
	var oldestT time.Time
	first := true
	for k, t := range s.entries {
		if first || t.Before(oldestT) {
			oldestK, oldestT, first = k, t, false
		}
	}
	delete(s.entries, oldestK)
}
