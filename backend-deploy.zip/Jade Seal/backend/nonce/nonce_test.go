package nonce

import (
	"testing"
	"time"
)

func TestRejectsReplay(t *testing.T) {
	s := New(time.Minute, 100)
	if !s.Record("lic-1\x00nonceA") {
		t.Fatal("first use should be fresh")
	}
	if s.Record("lic-1\x00nonceA") {
		t.Fatal("replay should be refused")
	}
}

func TestDistinctNoncesPass(t *testing.T) {
	s := New(time.Minute, 100)
	s.Record("lic-1\x00nonceA")
	if !s.Record("lic-1\x00nonceB") {
		t.Fatal("distinct nonce should be fresh")
	}
	if !s.Record("lic-2\x00nonceA") {
		t.Fatal("same nonce under a different license should be fresh")
	}
}

func TestExpiryAllowsReuse(t *testing.T) {
	s := New(20*time.Millisecond, 100)
	s.Record("k")
	if s.Record("k") {
		t.Fatal("should refuse within TTL")
	}
	time.Sleep(30 * time.Millisecond)
	if !s.Record("k") {
		t.Fatal("should allow after TTL expiry")
	}
}

func TestBoundedEviction(t *testing.T) {
	s := New(time.Minute, 3)
	for i := 0; i < 10; i++ {
		s.Record(string(rune('a' + i)))
	}
	s.mu.Lock()
	n := len(s.entries)
	s.mu.Unlock()
	if n > 3 {
		t.Fatalf("store grew to %d entries, want <= 3", n)
	}
}
