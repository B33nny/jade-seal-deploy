package models

import (
	"time"
)

// User represents a platform user
type User struct {
	ID           string    `json:"id"`
	Email        string    `json:"email"`
	PasswordHash string    `json:"-"`
	Name         string    `json:"name"`
	Role         string    `json:"role"` // viewer, analyst, tester, developer, admin, superadmin
	OrgID        string    `json:"org_id"`
	MFAEnabled   bool      `json:"mfa_enabled"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

// Organization represents a tenant
type Organization struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	PlanTier  string    `json:"plan_tier"` // free, pro, enterprise
	CreatedAt time.Time `json:"created_at"`
}

// Sandbox represents an isolated execution environment
type Sandbox struct {
	ID            string     `json:"id"`
	OrgID         string     `json:"org_id"`
	UserID        string     `json:"user_id"`
	Name          string     `json:"name"`
	TemplateID    string     `json:"template_id"`
	TemplateName  string     `json:"template_name,omitempty"`
	Status        string     `json:"status"` // queued, provisioning, ready, running, paused, terminated, error
	IsolationTier string     `json:"isolation_tier"` // container, gvisor, firecracker
	LicenseID     *string    `json:"license_id,omitempty"`
	ContainerID   string     `json:"container_id,omitempty"`
	IPAddress     string     `json:"ip_address,omitempty"`
	Port          int        `json:"port,omitempty"`
	VNCWebSocket  string     `json:"vnc_websocket,omitempty"`
	CPUCores      int        `json:"cpu_cores"`
	MemoryMB      int        `json:"memory_mb"`
	DiskGB        int        `json:"disk_gb"`
	CreatedAt     time.Time  `json:"created_at"`
	StartedAt     *time.Time `json:"started_at,omitempty"`
	StoppedAt     *time.Time `json:"stopped_at,omitempty"`
}

// SandboxTemplate represents a pre-built sandbox image
type SandboxTemplate struct {
	ID               string   `json:"id"`
	Name             string   `json:"name"`
	Description      string   `json:"description"`
	OSType           string   `json:"os_type"`
	Image            string   `json:"image"`
	DefaultIsolation string   `json:"default_isolation"`
	PreinstalledApps []string `json:"preinstalled_apps"`
	Icon             string   `json:"icon"`
	Category         string   `json:"category"`
}

// License represents a software license
type License struct {
	ID              string     `json:"id"`
	ProductID       string     `json:"product_id"`
	ProductName     string     `json:"product_name,omitempty"`
	OrgID           string     `json:"org_id"`
	Type            string     `json:"type"`  // cloud, soft, dongle
	Model           string     `json:"model"` // trial, perpetual, subscription, floating
	Status          string     `json:"status"` // active, expired, revoked, suspended
	IssuedToEmail   string     `json:"issued_to_email"`
	IssuedToUserID  string     `json:"issued_to_user_id,omitempty"`
	IssuedByUserID  string     `json:"issued_by_user_id"`
	Features        []string   `json:"features"`
	MaxSeats        int        `json:"max_seats"`
	IssuedAt        time.Time  `json:"issued_at"`
	ExpiresAt       *time.Time `json:"expires_at,omitempty"`
	HardwareFingerprint string `json:"hardware_fingerprint,omitempty"`
	Signature       string     `json:"signature,omitempty"`
	LicenseKey      string     `json:"license_key,omitempty"`
	CreatedAt       time.Time  `json:"created_at"`
}

// Product represents a protectable software product
type Product struct {
	ID          string    `json:"id"`
	OrgID       string    `json:"org_id"`
	Name        string    `json:"name"`
	Version     string    `json:"version"`
	CreatedAt   time.Time `json:"created_at"`
}

// ProtectionJob represents a code protection job
type ProtectionJob struct {
	ID             string     `json:"id"`
	OrgID          string     `json:"org_id"`
	UserID         string     `json:"user_id"`
	ProfileID      string     `json:"profile_id"`
	InputFileName  string     `json:"input_file_name"`
	Platform       string     `json:"platform"`
	Status         string     `json:"status"` // queued, analyzing, protecting, packaging, completed, failed
	ProgressPct    int        `json:"progress_pct"`
	Duration       string     `json:"duration,omitempty"`
	OutputFileName string     `json:"output_file_name,omitempty"`
	ErrorMessage   string     `json:"error_message,omitempty"`
	IntegrityHash  string     `json:"integrity_hash,omitempty"`
	BinaryFormat   string     `json:"binary_format,omitempty"`
	CreatedAt      time.Time  `json:"created_at"`
	CompletedAt    *time.Time `json:"completed_at,omitempty"`
}

// AuditEvent represents an immutable log entry
type AuditEvent struct {
	ID           string    `json:"id"`
	OrgID        string    `json:"org_id"`
	UserID       string    `json:"user_id"`
	UserEmail    string    `json:"user_email,omitempty"`
	Action       string    `json:"action"`
	ResourceType string    `json:"resource_type"`
	ResourceID   string    `json:"resource_id"`
	Details      string    `json:"details,omitempty"`
	CreatedAt    time.Time `json:"created_at"`
}

// --- Request / Response types ---

type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type LoginResponse struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	User         User   `json:"user"`
}

type CreateSandboxRequest struct {
	TemplateID    string  `json:"template_id"`
	IsolationTier string  `json:"isolation_tier"`
	LicenseID     *string `json:"license_id,omitempty"`
	CPUCores      int     `json:"cpu_cores"`
	MemoryMB      int     `json:"memory_mb"`
	DiskGB        int     `json:"disk_gb"`
}

type IssueLicenseRequest struct {
	ProductID      string   `json:"product_id"`
	Type           string   `json:"type"`
	Model          string   `json:"model"`
	IssuedToEmail  string   `json:"issued_to_email"`
	Features       []string `json:"features"`
	MaxSeats       int      `json:"max_seats"`
	ExpiresInDays  int      `json:"expires_in_days"`
}

type VerifyLicenseRequest struct {
	LicenseID    string `json:"license_id"`   // legacy: internal id (pre-key rows)
	LicenseKey   string `json:"license_key"`  // preferred: unguessable bearer token
	ProductID    string `json:"product_id"`
	HWID         string `json:"hwid"`
	RequestedFeature string `json:"requested_feature"`
	Email            string `json:"email"`
}

type VerifyLicenseResponse struct {
	Status   string   `json:"status"`
	LicenseID string  `json:"license_id,omitempty"`
	Features []string `json:"features,omitempty"`
	Reason   string   `json:"reason,omitempty"`
	Message  string   `json:"message,omitempty"`
	ExpiresAt *time.Time `json:"expires_at,omitempty"`
}

// ActivateRequest is the §6.4 online-activation payload. ts is Unix seconds;
// the server rejects ts outside ±300s and any nonce it has already seen.
type ActivateRequest struct {
	LicenseKey string `json:"license_key"`
	ProductID  string `json:"product_id"`
	FPHash     string `json:"fp_hash"`
	Email      string `json:"email"`
	Nonce      string `json:"nonce"`
	TS         int64  `json:"ts"`
}

type ActivateResponse struct {
	Status      string     `json:"status"`
	LicenseID   string     `json:"license_id,omitempty"`
	Reason      string     `json:"reason,omitempty"`
	Message     string     `json:"message,omitempty"`
	SeatID      string     `json:"seat_id,omitempty"`
	Signature   string     `json:"signature,omitempty"` // Ed25519 over the activation
	ServerTime  int64      `json:"server_time"`
	ExpiresAt   *time.Time `json:"expires_at,omitempty"`
}

// OfflineActivateRequest is the §6.5 c2d challenge: an air-gapped machine sends
// its license key + fingerprint + a nonce/timestamp for replay defence.
type OfflineActivateRequest struct {
	LicenseKey string `json:"license_key"`
	FPHash     string `json:"fp_hash"`
	AppID      string `json:"app_id"`
	Email      string `json:"email"`
	Nonce      string `json:"nonce"`
	TS         int64  `json:"ts"`
}

// OfflineActivateResponse is the §6.5 d2c reply: a signed offline ticket. The
// signature covers license_key, seat, fp, counter, issued_at, expires_at and is
// verifiable against the public key at /api/license/public-key. Counter is the
// monotonic per-license value a client uses to reject replayed tickets.
type OfflineActivateResponse struct {
	Status     string     `json:"status"`
	Reason     string     `json:"reason,omitempty"`
	Message    string     `json:"message,omitempty"`
	SeatID     string     `json:"seat_id,omitempty"`
	FPHash     string     `json:"fp_hash,omitempty"`
	Counter    int64      `json:"counter"`
	IssuedAt   int64      `json:"issued_at"`
	ExpiresAt  *time.Time `json:"expires_at,omitempty"`
	Signature  string     `json:"signature,omitempty"`
	ServerTime int64      `json:"server_time"`
}

type PaginatedResponse struct {
	Data       interface{} `json:"data"`
	Total      int         `json:"total"`
	Page       int         `json:"page"`
	Limit      int         `json:"limit"`
}

// --- Dao Assistant types ---

type DaoCommandRequest struct {
	Command   string `json:"command"`            // Natural language command
	SessionID string `json:"session_id,omitempty"` // Ben AI session tracking
	Context   string `json:"context,omitempty"`    // Additional context
}

type DaoCommandResponse struct {
	Intent    string                 `json:"intent"`              // Parsed intent (e.g., "sandbox.launch")
	Action    string                 `json:"action"`              // ACTION: marker string
	Confidence float64               `json:"confidence"`          // 0.0 - 1.0
	Result    map[string]interface{} `json:"result,omitempty"`    // Execution result
	Reasoning string                 `json:"reasoning,omitempty"` // LLM reasoning trace
	Error     string                 `json:"error,omitempty"`
}

type DaoIntentRequest struct {
	Command string `json:"command"`
}

type DaoIntentResponse struct {
	Intent     string   `json:"intent"`
	Action     string   `json:"action"`
	Confidence float64  `json:"confidence"`
	Parameters map[string]interface{} `json:"parameters,omitempty"`
}

type DaoStatusResponse struct {
	Service      string                 `json:"service"`
	Version      string                 `json:"version"`
	BenAIConnected bool                 `json:"ben_ai_connected"`
	Capabilities []string               `json:"capabilities"`
	Metrics      map[string]interface{} `json:"metrics"`
	Health       string                 `json:"health"` // "healthy", "degraded", "down"
}

type BenAIEvent struct {
	ID        string    `json:"id"`
	Type      string    `json:"type"`      // "action.completed", "action.failed", "sandbox.status", "license.issued", etc.
	Data      map[string]interface{} `json:"data"`
	Timestamp time.Time `json:"timestamp"`
}

type SchoolLearningEntry struct {
	ID          string    `json:"id"`
	SessionID   string    `json:"session_id"`
	Command     string    `json:"command"`
	Intent      string    `json:"intent"`
	Outcome     string    `json:"outcome"` // "success", "failure", "corrected"
	ErrorPattern string   `json:"error_pattern,omitempty"`
	Confidence  float64   `json:"confidence"`
	CreatedAt   time.Time `json:"created_at"`
}
