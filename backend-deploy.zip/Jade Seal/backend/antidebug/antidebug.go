// Package antidebug is the user-mode anti-debug layer for §5.6 of the Jade
// Seal protection spec. It runs a small set of portable checks and reports a
// 0-100 score that callers can act on (e.g. refuse to mint a license, or
// surface a warning to the operator console).
//
// Design rules from §5.6:
//
//   - Detect, don't crash. Every check is wrapped so a failed syscall or
//     unavailable DLL can never panic the caller.
//   - Refuse visibly, don't silently degrade. The library only REPORTS — it
//     never exits, never panics, never modifies global state on its own.
//     The caller decides what the score means in its context.
//
// The package ships three files:
//
//   - antidebug.go (this file): Score type + pure aggregate() core. The
//     aggregate function is intentionally pure so it can be unit-tested
//     without touching any OS API.
//   - windows.go: Windows-specific checks. Gated by //go:build windows.
//   - stub.go: Non-Windows no-op. Gated by //go:build !windows.
//
// On non-Windows hosts Detect() returns Score{Value: 0}. The score is only
// meaningful on Windows; on Linux/macOS servers we want to score zero so the
// caller has nothing to react to.
package antidebug

import "math"

// Score is the user-mode anti-debug result.
//
//	Value   0..100 — higher means more debugger indicators fired.
//	         0 means "clean" (no checks fired, or no checks applicable).
//	Reasons names of the checks that fired, for diagnostics.
//
// The struct is safe to copy by value.
type Score struct {
	Value   int
	Reasons []string
}

// firedName pairs a check outcome with its human-readable name. The aggregate
// function takes parallel slices of these rather than a slice of structs so
// the helper functions in windows.go can stay allocation-light and so the
// test surface stays obvious.
func aggregate(fired []bool, names []string) Score {
	if len(fired) == 0 || len(fired) != len(names) {
		// No checks applicable (non-Windows, or someone called us
		// with mismatched slices). A score of 0 means "no signal" —
		// NOT "no problem". The caller must interpret zero as
		// "no checks ran", not "system is clean".
		return Score{Value: 0}
	}

	count := 0
	reasons := make([]string, 0, len(fired))
	for i, f := range fired {
		if f {
			count++
			reasons = append(reasons, names[i])
		}
	}

	if count == 0 {
		// Checks ran, nothing fired — genuinely clean.
		return Score{Value: 0}
	}

	// Proportional: count/length * 100, rounded to nearest int.
	// We compute it as float to keep rounding correct on ties.
	pct := (float64(count) / float64(len(fired))) * 100.0
	v := int(math.Round(pct))
	if v < 1 {
		// At least one fired but rounding to zero would lose the
		// signal. Floor at 1 so the caller never sees Value==0 with
		// a non-empty Reasons list.
		v = 1
	}
	if v > 100 {
		v = 100
	}
	return Score{Value: v, Reasons: reasons}
}