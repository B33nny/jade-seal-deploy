//go:build windows

// windows.go is the Windows implementation of Detect(). It calls a small set
// of user-mode anti-debug checks via stdlib syscall only (no golang.org/x/sys)
// and reports a proportional 0-100 score via aggregate().
//
// Checks shipped here:
//
//  1. IsDebuggerPresent — kernel32!IsDebuggerPresent. Fast, user-mode, but
//     trivially bypassed by patching the PEB.BeingDebugged byte. We treat a
//     nonzero return as "fired".
//
//  2. ProcessDebugPort — ntdll!NtQueryInformationProcess with info class 7
//     (ProcessDebugPort). Returns a DWORD_PTR; nonzero means a debug port is
//     attached to this process. This is a separate signal from
//     IsDebuggerPresent and survives simple PEB patches.
//
// Checks deliberately NOT shipped (and why):
//
//   - PEB.BeingDebugged and PEB.NtGlobalFlag direct reads — these need to
//     fetch the TEB via NtCurrentTEB() then walk offsets that differ between
//     32-bit and 64-bit Windows. Doing that safely with stdlib syscall only
//     is fragile and easy to get wrong; per the §5.6 "detect, don't crash"
//     rule we'd rather omit it than ship a panicking read.
//   - CheckRemoteDebuggerPresent — same family as IsDebuggerPresent, just
//     for remote debuggers. Useful but the Win32k/WinAPI surface is larger
//     than the marginal signal we'd get; left for Phase B.
//
// Every syscall here is wrapped so that:
//   - DLL load failures (LoadLibrary returning a bad handle) become "check
//     didn't fire" rather than a panic.
//   - Procedure-not-found errors become "check didn't fire".
//   - Wrong-status from the NT call becomes "check didn't fire".
//   - Wrong type/size from the NT call becomes "check didn't fire".
//
// We never panic, never os.Exit, never modify global state. The caller
// decides what the score means.
package antidebug

import (
	"syscall"
	"unsafe"
)

// processInfoClassProcessDebugPort is the value of ProcessInformationClass
// for ProcessDebugPort on ntdll!NtQueryInformationProcess. See the public NT
// status code reference; class 7 is stable across Windows 7..11.
const processInfoClassProcessDebugPort = 7

// ntstatusSuccess is the NTSTATUS return value that NtQueryInformationProcess
// uses to signal success. Anything else (negative or non-zero warning) is a
// non-success and we treat the check as not having fired.
const ntstatusSuccess = 0x00000000

// checkIsDebuggerPresent calls kernel32!IsDebuggerPresent. A nonzero return
// value is treated as "a debugger is attached to this process". The check
// fires (returns fired=true) when the BOOL return is nonzero.
//
// If the DLL/proc can't be loaded for any reason we return (false, name). The
// caller still records the check ran; we just can't observe its result.
func checkIsDebuggerPresent() (fired bool, name string) {
	name = "IsDebuggerPresent"
	dll := syscall.NewLazyDLL("kernel32.dll")
	if dll == nil {
		return false, name
	}
	proc := dll.NewProc("IsDebuggerPresent")
	if proc == nil {
		return false, name
	}

	// IsDebuggerPresent takes no parameters and returns a BOOL (uint32).
	// On Windows the BOOL is 1 byte historically but the stdlib syscall
	// surface treats it as uintptr — nonzero is the signal we want.
	r1, _, _ := proc.Call()
	return uint32(r1) != 0, name
}

// checkProcessDebugPort calls ntdll!NtQueryInformationProcess with
// ProcessInformationClass = ProcessDebugPort (7). The system fills
// ProcessInformation with a DWORD_PTR that is nonzero when a debugger is
// attached to this process via the kernel debug port.
//
// Call signature (from ntdll.dll):
//
//	NTSTATUS NtQueryInformationProcess(
//	    HANDLE           ProcessHandle,
//	    PROCESSINFOCLASS ProcessInformationClass,
//	    PVOID            ProcessInformation,
//	    ULONG            ProcessInformationLength,
//	    PULONG           ReturnLength OPTIONAL);
//
// ProcessInformationLength must be the size of the output buffer. On
// 64-bit Windows that's 8 bytes for a DWORD_PTR; on 32-bit it's 4. We use
// unsafe.Sizeof(uintptr(0)) so the call is correct on whichever build GO
// produces (the Jade Seal backend is amd64-only in practice, but the
// stdlib uintptr size adapts either way).
func checkProcessDebugPort() (fired bool, name string) {
	name = "ProcessDebugPort"
	dll := syscall.NewLazyDLL("ntdll.dll")
	if dll == nil {
		return false, name
	}
	proc := dll.NewProc("NtQueryInformationProcess")
	if proc == nil {
		return false, name
	}

	// HANDLE for "this process" is -1 (the documented pseudo-handle value
		// that always refers to the calling process, equivalent to a
		// duplicated current-process handle). See the Windows API docs
		// for GetCurrentProcess / NtCurrentProcess.
	const currentProcess = ^uintptr(0) // -1 cast to uintptr

	// Output buffer: a single DWORD_PTR-sized slot. We zero it first
	// so an "all bits set" success return is still distinguishable
	// from a non-fire.
	var info uintptr
	infoLen := uint32(unsafe.Sizeof(info))

	// ReturnLength is optional — pass NULL (zero) since we don't need
	// to know how many bytes the system would have written.
	var retLen uintptr

	r1, _, _ := proc.Call(
		currentProcess,
		uintptr(processInfoClassProcessDebugPort),
		uintptr(unsafe.Pointer(&info)),
		uintptr(infoLen),
		uintptr(unsafe.Pointer(&retLen)),
	)

	// r1 is the NTSTATUS. Anything other than STATUS_SUCCESS means we
	// can't trust the buffer — treat the check as not fired.
	if uint32(r1) != uint32(ntstatusSuccess) {
		return false, name
	}

	// STATUS_SUCCESS with a nonzero DWORD_PTR means a debug port is
	// attached. A zero return means no debug port.
	return info != 0, name
}

// Detect runs every Windows check, aggregates the fired flags, and returns
// the proportional score. It never panics: each helper swallows the error
// path and returns (false, name), which still feeds the aggregate so the
// "no checks applicable" zero is reserved for the case where we genuinely
// had nothing to run.
//
// Adding a check here is two lines: append (bool, string) to fired/names
// from the helper, then call the helper. aggregate() does the rest.
func Detect() Score {
	helpers := []func() (bool, string){
		checkIsDebuggerPresent,
		checkProcessDebugPort,
	}

	fired := make([]bool, 0, len(helpers))
	names := make([]string, 0, len(helpers))
	for _, h := range helpers {
		f, n := h()
		fired = append(fired, f)
		names = append(names, n)
	}
	return aggregate(fired, names)
}