//go:build !windows

// stub.go is the non-Windows implementation of Detect(). On Linux/macOS test
// hosts and CI runners there are no user-mode debugger indicators we want to
// score — a Linux debugger doesn't attach to a Windows PE — so we return a
// zero score and no-op.
//
// The build tag must be the very first non-comment line of the source file
// (per https://pkg.go.dev/cmd/go#hdr-Build_constraints). It sits above the
// package clause here.
package antidebug

// Detect returns a zero score on non-Windows platforms. See windows.go for
// the real implementation.
func Detect() Score {
	return Score{Value: 0}
}