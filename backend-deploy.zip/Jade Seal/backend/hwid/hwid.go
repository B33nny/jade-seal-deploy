// Package hwid implements the server side of §6.3 hardware fingerprinting: it
// compares a device-presented fingerprint against a stored one using weighted,
// fuzzy matching, so a licence survives a single minor hardware change (new
// disk, re-ordered MACs) but re-binds when the load-bearing component changes.
//
// The device never sends raw hardware IDs — each component is SHA-256 hashed
// (salted per-product) on the device, and the server stores and compares only
// the hashes. A strict single-component match is a support-ticket avalanche;
// weighted fuzzy matching is the fix (§6.3 second-order note).
package hwid

import (
	"encoding/json"
	"strings"
)

// componentWeights is the §6.3 weighting (sum = 100). The motherboard is the
// load-bearing component: losing it (35%) drops the match to 65%, below the 70%
// floor, forcing a re-bind. Losing any single other component stays ≥70%.
var componentWeights = map[string]int{
	"motherboard": 35,
	"cpu":         25,
	"disk":        20,
	"mac":         15,
	"os_guid":     5,
}

// Threshold is the §6.3 pass floor: a ≥70% weighted match passes.
const Threshold = 0.70

// Fingerprint is the device's on-device-hashed component set. Component keys
// are the stable names in componentWeights; values are hex SHA-256 hashes.
type Fingerprint struct {
	Components map[string]string `json:"components"`
}

// String renders the fingerprint in its canonical on-disk form (deterministic:
// Go sorts map keys when marshalling).
func (f Fingerprint) String() string {
	if f.Components == nil {
		return ""
	}
	b, err := json.Marshal(f)
	if err != nil {
		return ""
	}
	return string(b)
}

// parse decodes a stored/presented fingerprint string. A JSON object carrying a
// "components" map is a structured fingerprint; anything else is treated as a
// legacy opaque token (one pseudo-component matched exactly).
func parse(s string) Fingerprint {
	s = strings.TrimSpace(s)
	if s == "" {
		return Fingerprint{}
	}
	var f Fingerprint
	if err := json.Unmarshal([]byte(s), &f); err == nil && f.Components != nil {
		return f
	}
	return Fingerprint{Components: map[string]string{"opaque": s}}
}

// match returns the weighted match fraction in [0,1] between two fingerprints.
func match(stored, presented Fingerprint) float64 {
	if stored.Components == nil || presented.Components == nil {
		return 0
	}
	// Legacy opaque token: exact equality only, on both sides.
	if s, ok := stored.Components["opaque"]; ok {
		if p, ok2 := presented.Components["opaque"]; ok2 && s == p {
			return 1
		}
		return 0
	}
	if _, ok := presented.Components["opaque"]; ok {
		return 0
	}

	matched := 0
	for comp, ph := range presented.Components {
		if sh, ok := stored.Components[comp]; ok && sh != "" && sh == ph {
			matched += componentWeights[comp]
		}
	}
	return float64(matched) / 100.0
}

// Decision is the outcome of comparing a presented fingerprint to a stored one.
type Decision int

const (
	// Deny means the presented fingerprint is below threshold — hard fail.
	Deny Decision = iota
	// BindFirst means there is no stored fingerprint yet — bind to presented.
	BindFirst
	// Pass means the match is ≥ threshold — accept and soft-rebind changes.
	Pass
)

// Compare classifies a presented fingerprint against a stored one and returns
// (decision, weight, persist). persist is the value to store — the normalized
// presented fingerprint on BindFirst, the merged fingerprint on Pass, and ""
// on Deny. An empty presented fingerprint denies immediately.
func Compare(stored, presented string) (Decision, float64, string) {
	p := parse(presented)
	if p.Components == nil {
		return Deny, 0, ""
	}
	s := parse(stored)
	if s.Components == nil {
		return BindFirst, 0, p.String()
	}
	w := match(s, p)
	if w >= Threshold {
		return Pass, w, merge(s, p).String()
	}
	return Deny, w, ""
}

// merge folds the presented component hashes into the stored set so a tolerated
// change becomes the new baseline (soft re-bind). Unknown component keys are
// dropped rather than stored.
func merge(stored, presented Fingerprint) Fingerprint {
	out := Fingerprint{Components: map[string]string{}}
	for k, v := range stored.Components {
		out.Components[k] = v
	}
	for k, v := range presented.Components {
		if _, known := componentWeights[k]; known {
			out.Components[k] = v
		}
	}
	return out
}
