package hwid

import "testing"

func full() Fingerprint {
	return Fingerprint{Components: map[string]string{
		"motherboard": "mb1",
		"cpu":         "cpu1",
		"disk":        "disk1",
		"mac":         "mac1",
		"os_guid":     "os1",
	}}
}

func TestMatchExact(t *testing.T) {
	if w := match(full(), full()); w != 1.0 {
		t.Fatalf("exact match = %v, want 1.0", w)
	}
}

func TestMatchOneMinorChangeAboveThreshold(t *testing.T) {
	// Change the MAC (15%): 100 - 15 = 85% ≥ 70% → passes.
	p := full()
	p.Components["mac"] = "mac2"
	d, w, _ := Compare(full().String(), p.String())
	if d != Pass || w != 0.85 {
		t.Fatalf("minor change: decision=%v weight=%v, want Pass 0.85", d, w)
	}
}

func TestMatchMotherboardChangeBelowThreshold(t *testing.T) {
	// Change the motherboard (35%): 100 - 35 = 65% < 70% → deny (load-bearing).
	p := full()
	p.Components["motherboard"] = "mb2"
	d, w, _ := Compare(full().String(), p.String())
	if d != Deny || w != 0.65 {
		t.Fatalf("motherboard change: decision=%v weight=%v, want Deny 0.65", d, w)
	}
}

func TestMatchTwoChangesDeny(t *testing.T) {
	p := full()
	p.Components["cpu"] = "cpu2"
	p.Components["disk"] = "disk2"
	d, w, _ := Compare(full().String(), p.String())
	if d != Deny {
		t.Fatalf("two changes: decision=%v weight=%v, want Deny", d, w)
	}
	if w >= Threshold {
		t.Fatalf("two changes weight=%v should be below threshold", w)
	}
}

func TestBindFirst(t *testing.T) {
	d, _, persist := Compare("", full().String())
	if d != BindFirst {
		t.Fatalf("empty stored = %v, want BindFirst", d)
	}
	if persist == "" {
		t.Fatal("BindFirst should persist the presented fingerprint")
	}
}

func TestDenyEmptyPresented(t *testing.T) {
	d, _, persist := Compare(full().String(), "")
	if d != Deny {
		t.Fatalf("empty presented = %v, want Deny", d)
	}
	if persist != "" {
		t.Fatal("Deny must not persist")
	}
}

func TestMergeSoftRebindsChangedComponent(t *testing.T) {
	stored := full()
	presented := full()
	presented.Components["mac"] = "mac2"

	d, _, persist := Compare(stored.String(), presented.String())
	if d != Pass {
		t.Fatalf("expected Pass, got %v", d)
	}
	merged := parse(persist)
	if merged.Components["mac"] != "mac2" {
		t.Fatalf("merge did not rebind mac: %v", merged.Components)
	}
	if merged.Components["motherboard"] != "mb1" {
		t.Fatalf("merge dropped unchanged component: %v", merged.Components)
	}
}

func TestLegacyOpaqueExactMatch(t *testing.T) {
	// Pre-fuzzy rows may store a plain opaque token; those must still exact-match.
	d, w, _ := Compare("legacy-token", "legacy-token")
	if d != Pass || w != 1.0 {
		t.Fatalf("legacy exact: decision=%v weight=%v, want Pass 1.0", d, w)
	}
	d, _, _ = Compare("legacy-token", "other-token")
	if d != Deny {
		t.Fatalf("legacy mismatch: decision=%v, want Deny", d)
	}
}

func TestMergeDropsUnknownComponents(t *testing.T) {
	p := full()
	p.Components["gpu"] = "gpu1" // not in the weighting
	merged := merge(full(), p)
	if _, ok := merged.Components["gpu"]; ok {
		t.Fatal("merge stored an unknown component")
	}
}
