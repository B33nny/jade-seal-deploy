// Package jsonutil provides a small JSON helper used by main.go without
// pulling encoding/json into the import block at the top.
package jsonutil

import "encoding/json"

// Marshal is a thin wrapper around encoding/json that returns nil on error
// so callers can use `string(jsonutil.Marshal(v))` in a one-liner.
func Marshal(v interface{}) []byte {
	b, err := json.Marshal(v)
	if err != nil {
		return []byte("{}")
	}
	return b
}
