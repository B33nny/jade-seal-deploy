package db

import (
	"database/sql"
	"log"
	"strings"

	_ "modernc.org/sqlite"
)

var DB *sql.DB

func Init(databaseURL string) {
	dsn := databaseURL
	if !strings.HasPrefix(dsn, "file:") {
		dsn = "file:" + dsn
	}
	// Note: WAL journal mode is not used here because Cloud Run mounts the
	// database on Google Cloud Storage via FUSE, which does not support the
	// shared-memory locking that WAL requires. The default DELETE journal mode
	// is fully compatible and works correctly at pilot-scale concurrency.
	dsn += "?_pragma=foreign_keys(1)"

	var err error
	DB, err = sql.Open("sqlite", dsn)
	if err != nil {
		log.Fatalf("Failed to open database: %v", err)
	}

	if err = DB.Ping(); err != nil {
		log.Fatalf("Failed to ping database: %v", err)
	}

	migrate()
	seed()
	log.Println("Database initialized successfully")
}

func migrate() {
	schema := `
	CREATE TABLE IF NOT EXISTS organizations (
		id TEXT PRIMARY KEY,
		name TEXT NOT NULL,
		plan_tier TEXT NOT NULL DEFAULT 'free',
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS users (
		id TEXT PRIMARY KEY,
		org_id TEXT NOT NULL REFERENCES organizations(id),
		email TEXT UNIQUE NOT NULL,
		password_hash TEXT NOT NULL,
		name TEXT NOT NULL,
		role TEXT NOT NULL DEFAULT 'viewer',
		mfa_enabled INTEGER DEFAULT 0,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS products (
		id TEXT PRIMARY KEY,
		org_id TEXT NOT NULL REFERENCES organizations(id),
		name TEXT NOT NULL,
		version TEXT NOT NULL,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS licenses (
		id TEXT PRIMARY KEY,
		product_id TEXT NOT NULL REFERENCES products(id),
		org_id TEXT NOT NULL REFERENCES organizations(id),
		type TEXT NOT NULL CHECK(type IN ('cloud','soft','dongle')),
		model TEXT NOT NULL CHECK(model IN ('trial','perpetual','subscription','floating')),
		status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','expired','revoked','suspended')),
		issued_to_email TEXT NOT NULL,
		issued_to_user_id TEXT REFERENCES users(id),
		issued_by_user_id TEXT NOT NULL REFERENCES users(id),
		features TEXT NOT NULL DEFAULT '[]',
		max_seats INTEGER NOT NULL DEFAULT 1,
		issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		expires_at DATETIME,
		hardware_fingerprint TEXT,
		signature TEXT,
		license_key TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS sandbox_templates (
		id TEXT PRIMARY KEY,
		name TEXT NOT NULL,
		description TEXT,
		os_type TEXT NOT NULL,
		image TEXT NOT NULL,
		default_isolation TEXT NOT NULL DEFAULT 'container',
		preinstalled_apps TEXT DEFAULT '[]',
		icon TEXT DEFAULT 'box',
		category TEXT DEFAULT 'general'
	);

	CREATE TABLE IF NOT EXISTS sandboxes (
		id TEXT PRIMARY KEY,
		org_id TEXT NOT NULL REFERENCES organizations(id),
		template_id TEXT NOT NULL REFERENCES sandbox_templates(id),
		user_id TEXT NOT NULL REFERENCES users(id),
		name TEXT,
		status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','provisioning','ready','running','paused','terminated','error')),
		isolation_tier TEXT NOT NULL DEFAULT 'container' CHECK(isolation_tier IN ('container','gvisor','firecracker')),
		license_id TEXT REFERENCES licenses(id),
		container_id TEXT,
		ip_address TEXT,
		port INTEGER,
		vnc_websocket TEXT,
		cpu_cores INTEGER DEFAULT 2,
		memory_mb INTEGER DEFAULT 4096,
		disk_gb INTEGER DEFAULT 20,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		started_at DATETIME,
		stopped_at DATETIME
	);

	CREATE TABLE IF NOT EXISTS protection_jobs (
		id TEXT PRIMARY KEY,
		org_id TEXT NOT NULL REFERENCES organizations(id),
		user_id TEXT NOT NULL REFERENCES users(id),
		profile_id TEXT NOT NULL,
		input_file_name TEXT NOT NULL,
		platform TEXT NOT NULL DEFAULT 'windows',
		status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','analyzing','protecting','packaging','completed','failed')),
		progress_pct INTEGER DEFAULT 0,
		duration TEXT,
		output_file_name TEXT,
		error_message TEXT,
		integrity_hash TEXT,
		binary_format TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		completed_at DATETIME
	);

	CREATE TABLE IF NOT EXISTS revocation_list (
		id TEXT PRIMARY KEY,
		org_id TEXT NOT NULL REFERENCES organizations(id),
		license_id TEXT NOT NULL,
		reason TEXT,
		revoked_by TEXT,
		sequence INTEGER NOT NULL,
		revoked_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS audit_log (
		id TEXT PRIMARY KEY,
		org_id TEXT NOT NULL REFERENCES organizations(id),
		user_id TEXT REFERENCES users(id),
		action TEXT NOT NULL,
		resource_type TEXT NOT NULL,
		resource_id TEXT,
		details TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS school_learning (
		id TEXT PRIMARY KEY,
		session_id TEXT NOT NULL,
		command TEXT NOT NULL,
		intent TEXT NOT NULL,
		outcome TEXT NOT NULL DEFAULT 'success',
		error_pattern TEXT,
		confidence REAL DEFAULT 0.0,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	CREATE TABLE IF NOT EXISTS offline_counters (
		license_id TEXT PRIMARY KEY,
		counter INTEGER NOT NULL DEFAULT 0,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);
	`
	if _, err := DB.Exec(schema); err != nil {
		log.Fatalf("Failed to run migrations: %v", err)
	}

	// Additive migrations: CREATE TABLE IF NOT EXISTS does not add columns to a
	// table that already exists, so existing databases pick up new columns here.
	ensureColumn("protection_jobs", "integrity_hash", "TEXT")
	ensureColumn("protection_jobs", "binary_format", "TEXT")
	ensureColumn("licenses", "license_key", "TEXT")
}

// ensureColumn adds a column to a table only if it is not already present.
func ensureColumn(table, column, ddl string) {
	rows, err := DB.Query("PRAGMA table_info(" + table + ")")
	if err != nil {
		log.Printf("Migration check failed for %s: %v", table, err)
		return
	}
	defer rows.Close()

	exists := false
	for rows.Next() {
		var cid, notnull, pk int
		var name, ctype string
		var dflt sql.NullString
		if err := rows.Scan(&cid, &name, &ctype, &notnull, &dflt, &pk); err != nil {
			continue
		}
		if name == column {
			exists = true
		}
	}
	if !exists {
		if _, err := DB.Exec("ALTER TABLE " + table + " ADD COLUMN " + column + " " + ddl); err != nil {
			log.Printf("Migration failed for %s.%s: %v", table, column, err)
		}
	}
}

func seed() {
	var count int
	DB.QueryRow("SELECT COUNT(*) FROM organizations").Scan(&count)
	if count > 0 {
		return
	}

	// Seed organization
	DB.Exec(`INSERT INTO organizations (id, name, plan_tier) VALUES ('org-001', 'Dao Systems', 'enterprise')`)

	// Seed users (password is "password123" bcrypt hashed)
	DB.Exec(`INSERT INTO users (id, org_id, email, password_hash, name, role) VALUES 
		('usr-admin', 'org-001', 'admin@jadeseal.io', '$2a$10$yYLEySKAoDdx6q4V3tMb/uX5ukmqnJHhZdmFGoXrhxRxaWP/gi5Se', 'Admin User', 'admin'),
		('usr-tester', 'org-001', 'tester@jadeseal.io', '$2a$10$yYLEySKAoDdx6q4V3tMb/uX5ukmqnJHhZdmFGoXrhxRxaWP/gi5Se', 'QA Tester', 'tester'),
		('usr-analyst', 'org-001', 'analyst@jadeseal.io', '$2a$10$yYLEySKAoDdx6q4V3tMb/uX5ukmqnJHhZdmFGoXrhxRxaWP/gi5Se', 'Business Analyst', 'analyst'),
		('usr-student', 'org-001', 'student@jadeseal.io', '$2a$10$yYLEySKAoDdx6q4V3tMb/uX5ukmqnJHhZdmFGoXrhxRxaWP/gi5Se', 'Student', 'viewer'),
		('usr-dev', 'org-001', 'dev@jadeseal.io', '$2a$10$yYLEySKAoDdx6q4V3tMb/uX5ukmqnJHhZdmFGoXrhxRxaWP/gi5Se', 'Developer', 'developer')`)

	// Seed templates
	DB.Exec(`INSERT INTO sandbox_templates (id, name, description, os_type, image, default_isolation, preinstalled_apps, icon, category) VALUES
		('tmpl-ubuntu', 'Ubuntu 24.04 Dev', 'Development environment with Python, Node.js, Git, VS Code Server', 'linux', 'ubuntu:24.04', 'container', '["python3","nodejs","git","curl","vim","build-essential"]', 'linux', 'development'),
		('tmpl-kali', 'Kali Linux', 'Security testing lab with Wireshark, nmap, Metasploit, John the Ripper', 'linux', 'kalilinux/kali-rolling', 'container', '["nmap","wireshark","metasploit","hydra","john","aircrack-ng"]', 'shield', 'security'),
		('tmpl-datascience', 'Data Science Stack', 'Jupyter, Python, R, pandas, scikit-learn, TensorFlow', 'linux', 'jupyter/datascience-notebook', 'container', '["python3","r-base","jupyter","pandas","numpy","scikit-learn","tensorflow"]', 'chart', 'data-science'),
		('tmpl-win11', 'Windows 11 Evaluation', 'Windows 11 environment with Office, browsers, and basic tools', 'windows', 'mcr.microsoft.com/windows:ltsc2022', 'container', '["office","edge","notepad++","7zip"]', 'windows', 'general'),
		('tmpl-webdev', 'Web Development', 'Node.js, React, PostgreSQL, Redis, Nginx pre-installed', 'linux', 'node:20-slim', 'container', '["nodejs","npm","yarn","git","postgresql","redis","nginx"]', 'code', 'development')`)

	// Seed products
	DB.Exec(`INSERT INTO products (id, org_id, name, version) VALUES
		('prod-myapp', 'org-001', 'MyApp Pro', '2.3.0'),
		('prod-cad', 'org-001', 'SecureCAD', '5.0.0'),
		('prod-datatool', 'org-001', 'DataTool', '1.0.0')`)

	// Seed a couple of sample licenses
	DB.Exec(`INSERT INTO licenses (id, product_id, org_id, type, model, status, issued_to_email, issued_to_user_id, issued_by_user_id, features, max_seats, expires_at) VALUES
		('lic-001', 'prod-myapp', 'org-001', 'cloud', 'trial', 'active', 'tester@jadeseal.io', 'usr-tester', 'usr-admin', '["core","reporting"]', 1, datetime('now', '+7 days')),
		('lic-002', 'prod-cad', 'org-001', 'dongle', 'perpetual', 'active', 'tester@jadeseal.io', 'usr-tester', 'usr-admin', '["core","advanced","export"]', 1, NULL)`)

	log.Println("Database seeded with sample data")
}
