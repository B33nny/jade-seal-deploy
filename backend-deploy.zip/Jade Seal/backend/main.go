package main

import (
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/cors"

	"github.com/jadeseal/platform/config"
	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/license"
	appMiddleware "github.com/jadeseal/platform/middleware"
	"github.com/jadeseal/platform/handlers"
	"github.com/jadeseal/platform/sandbox"
	jsws "github.com/jadeseal/platform/websocket"
	"github.com/jadeseal/platform/jsonutil"
)

func main() {
	cfg := config.Load()

	// Initialize database
	db.Init(cfg.DatabaseURL)

	// Initialise the license signing keypair (private key stays server-side).
	if err := license.Init(cfg.LicenseSigningKey, cfg.LicenseSigningKeyPath); err != nil {
		log.Fatalf("Failed to initialise license signing key: %v", err)
	}

	// Set JWT secret
	appMiddleware.SetJWTSecret(cfg.JWTSecret)

	// Set Ben AI API key
	appMiddleware.SetBenAIAPIKey(cfg.BenAIAPIKey)

	// Initialize rate limiter (100 requests per minute per IP)
	rateLimiter := appMiddleware.NewRateLimiter(100, 1*time.Minute)

	// Initialize Docker runtime (optional - graceful if Docker is unavailable)
	var dockerRuntime *sandbox.DockerRuntime
	dockerRuntime, err := sandbox.NewDockerRuntime(cfg.DockerHost)
	if err != nil {
		log.Printf("WARNING: Docker not available: %v - running in simulated mode", err)
		dockerRuntime = nil
	} else {
		if err := dockerRuntime.Ping(); err != nil {
			log.Printf("WARNING: Docker daemon unreachable: %v - running in simulated mode", err)
			dockerRuntime = nil
		} else {
			log.Println("Docker runtime connected successfully")
		}
	}

	h := handlers.NewHandler(dockerRuntime, cfg.ArtifactDir)

	// Sign any legacy licenses that predate the Ed25519 anchor (idempotent).
	if err := handlers.BackfillLicenseSignatures(); err != nil {
		log.Printf("WARNING: license signature backfill failed: %v", err)
	}

	// Assign unguessable bearer-token keys to any license predating §6.4.
	if err := handlers.BackfillLicenseKeys(); err != nil {
		log.Printf("WARNING: license key backfill failed: %v", err)
	}

	// Correct any stale license status at startup, then sweep hourly (§6.7).
	if n, err := handlers.SweepExpiredLicenses(db.DB); err != nil {
		log.Printf("WARNING: initial expiry sweep failed: %v", err)
	} else if n > 0 {
		log.Printf("Initial expiry sweep: expired %d license(s)", n)
	}
	go func() {
		ticker := time.NewTicker(time.Hour)
		defer ticker.Stop()
		for range ticker.C {
			if n, err := handlers.SweepExpiredLicenses(db.DB); err != nil {
				log.Printf("Expiry sweep failed: %v", err)
			} else if n > 0 {
				log.Printf("Expiry sweep: expired %d license(s)", n)
			}
		}
	}()

	// Wire up the WebSocket command handler: same intent parser & executor
	// as the REST Dao endpoints, but returns over a WS result frame.
	jsws.DefaultCommandHandler = func(c *jsws.Client, msg *jsws.InboundMessage) *jsws.OutboundMessage {
		fakeReq, _ := http.NewRequest(http.MethodPost, "/", nil)
		intent := handlers.ParseIntentPublic(msg.Command)
		resp := &jsws.OutboundMessage{
			Type:       "result",
			Intent:     intent.Intent,
			Action:     intent.Action,
			Confidence: intent.Confidence,
			Reasoning:  intent.Reasoning,
		}
		if intent.Confidence >= 0.7 && intent.Action != "" {
			result, err := h.ExecuteDaoActionPublic(intent, fakeReq)
			if err != nil {
				resp.Error = err.Error()
			} else {
				resp.Result = result
			}
		}
		// Broadcast the command to any subscribers of "command.executed".
		jsws.DefaultHub.Broadcast("command.executed", map[string]interface{}{
			"client_id":  c.ID,
			"auth_mode":  c.AuthMode,
			"command":    msg.Command,
			"intent":     intent.Intent,
			"confidence": intent.Confidence,
		})
		return resp
	}

	r := chi.NewRouter()

	// Parse CORS origins from config
	corsOrigins := strings.Split(cfg.CORSOrigins, ",")
	for i := range corsOrigins {
		corsOrigins[i] = strings.TrimSpace(corsOrigins[i])
	}

	// Middleware stack
	r.Use(middleware.Logger)
	r.Use(middleware.Recoverer)
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(rateLimiter.Middleware)
	r.Use(cors.Handler(cors.Options{
		AllowedOrigins:   corsOrigins,
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-CSRF-Token", "X-BenAI-API-Key"},
		ExposedHeaders:   []string{"Link"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// Public routes
	r.Group(func(r chi.Router) {
		r.Post("/api/auth/login", h.Login)
		r.Post("/api/auth/refresh", h.RefreshToken)
		r.Get("/api/health", func(w http.ResponseWriter, r *http.Request) {
			w.Write([]byte(`{"status":"ok","service":"jade-seal"}`))
		})

		// Public license verification — customer apps call this (no admin auth).
		// Rate-limited by the global limiter; bind-on-first-use + email match
		// happen inside the handler.
		r.Post("/api/license/verify", h.VerifyLicense)
		r.Post("/api/license/activate", h.Activate)
		r.Post("/api/license/offline/activate", h.ActivateOffline)
		r.Get("/api/license/crl", h.GetCRL)
		r.Get("/api/license/public-key", h.GetLicensePublicKey)
		r.Get("/api/protection/builder-key", h.GetBuilderPublicKey)

		// WebSocket - Ben AI / dashboard / Flutter clients connect here.
		// Auth: ?token=<jwt> for human users, ?api_key=<key> for Ben AI,
		// none for guest (read-only).
		r.Get("/api/ws", jsws.ServeWS)

		// WebSocket stats (public for monitoring)
		r.Get("/api/ws/stats", func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			stats := jsws.DefaultHub.Stats()
			stats["service"] = "jade-seal"
			stats["version"] = "2.1.0"
			stats["websocket_url"] = "/api/ws"
			stats["auth_modes"] = []string{"user-jwt", "benai-key", "guest"}
			w.Write([]byte(toJSON(stats)))
		})
	})

	// Ben AI routes (API key authenticated)
	r.Group(func(r chi.Router) {
		r.Use(appMiddleware.BenAIAuthMiddleware)
		r.Post("/api/dao/command", h.DaoCommand)
		r.Post("/api/dao/intent", h.DaoIntent)
		r.Get("/api/dao/status", h.DaoStatus)
		r.Get("/api/dao/events", h.DaoEvents)
	})

	// Protected user routes
	r.Group(func(r chi.Router) {
		r.Use(appMiddleware.AuthMiddleware)

		// Auth
		r.Get("/api/auth/me", h.Me)

		// Templates
		r.Get("/api/templates", h.ListTemplates)

		// Sandboxes
		r.Get("/api/sandbox", h.ListSandboxes)
		r.Post("/api/sandbox", h.CreateSandbox)
		r.Get("/api/sandbox/{id}", h.GetSandbox)
		r.Post("/api/sandbox/{id}/stop", h.StopSandbox)
		r.Delete("/api/sandbox/{id}", h.DeleteSandbox)
		r.Get("/api/sandbox/{id}/connect", h.SandboxConnect)

		// Licenses
		r.Get("/api/license", h.ListLicenses)

		// Products
		r.Get("/api/products", h.ListProducts)

		// Protection
		r.Get("/api/protection", h.ListProtectionJobs)
		r.Post("/api/protection", h.SubmitProtectionJob)
		r.Get("/api/protection/profiles", h.GetProtectionProfiles)
		r.Get("/api/protection/{id}/download", h.GetProtectionDownload)
	})

	// Admin-only routes (§9.7 least-privilege): issuing and revoking licenses,
	// and reading audit/metrics, are privileged operations.
	r.Group(func(r chi.Router) {
		r.Use(appMiddleware.AuthMiddleware)
		r.Use(appMiddleware.RequireRole("admin", "superadmin"))

		r.Post("/api/license", h.IssueLicense)
		r.Post("/api/license/{id}/revoke", h.RevokeLicense)
		r.Get("/api/admin/metrics", h.GetMetrics)
		r.Get("/api/admin/audit", h.GetAuditLog)
	})

	log.Printf("Jade Seal Platform starting on :%s", cfg.Port)
	log.Printf("Dashboard:    http://localhost:3000")
	log.Printf("API:          http://localhost:%s", cfg.Port)
	log.Printf("Health:       http://localhost:%s/api/health", cfg.Port)
	log.Printf("WebSocket:    ws://localhost:%s/api/ws", cfg.Port)
	log.Printf("Dao REST:     http://localhost:%s/api/dao/status", cfg.Port)
	if cfg.BenAIAPIKey != "" {
		log.Println("Ben AI integration: ENABLED")
	} else {
		log.Println("Ben AI integration: DISABLED (set BEN_AI_API_KEY to enable)")
	}

	if err := http.ListenAndServe(":"+cfg.Port, r); err != nil {
		log.Fatalf("Server failed: %v", err)
	}
}

func toJSON(v interface{}) string {
	return string(jsonutil.Marshal(v))
}
