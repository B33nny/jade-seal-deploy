package handlers

import (
	"database/sql"
	"encoding/json"
	"testing"

	_ "modernc.org/sqlite"

	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/license"
)

// setupLicenseTestDB wires the package-global db.DB to an in-memory SQLite and
// initialises a fresh signing key, so verifyLicenseCore can be exercised
// against a real signed row.
func setupLicenseTestDB(t *testing.T) {
	t.Helper()
	d, err := sql.Open("sqlite", ":memory:")
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	db.DB = d
	if _, err := d.Exec(`CREATE TABLE licenses (
		id TEXT PRIMARY KEY, product_id TEXT, org_id TEXT, model TEXT,
		status TEXT, issued_to_email TEXT, features TEXT, max_seats INTEGER,
		expires_at DATETIME, hardware_fingerprint TEXT, signature TEXT, license_key TEXT)`); err != nil {
		t.Fatal(err)
	}
	if err := license.Init("", t.TempDir()+"/signing.key"); err != nil {
		t.Fatalf("license.Init: %v", err)
	}
}

func issueTestLicense(t *testing.T, key, id, product, email string, features []string) {
	t.Helper()
	feat, _ := json.Marshal(features)
	sig, err := license.Sign(license.Token{
		LicenseID: id, ProductID: product, OrgID: "org-001", Model: "trial",
		Email: email, Features: features, MaxSeats: 1,
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := db.DB.Exec(`INSERT INTO licenses (id, product_id, org_id, model, status, issued_to_email, features, max_seats, signature, license_key)
		VALUES (?,?,?,?, 'active', ?, ?, 1, ?, ?)`, id, product, "org-001", "trial", email, string(feat), sig, key); err != nil {
		t.Fatal(err)
	}
}

func TestVerifyCoreLooksUpByLicenseKey(t *testing.T) {
	setupLicenseTestDB(t)
	issueTestLicense(t, "js-key-1", "lic-internal", "prod-a", "buyer@x.com", []string{"core"})

	res, err := verifyLicenseCore("js-key-1", "prod-a", `{"components":{"motherboard":"mb","cpu":"c","disk":"d","mac":"m","os_guid":"o"}}`, "buyer@x.com")
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	if res.status != "valid" {
		t.Fatalf("status = %q (%s), want valid", res.status, res.message)
	}
	if res.licenseID != "lic-internal" {
		t.Fatalf("licenseID = %q, want lic-internal", res.licenseID)
	}
}

func TestVerifyCoreProductCrossCheck(t *testing.T) {
	setupLicenseTestDB(t)
	issueTestLicense(t, "js-key-1", "lic-internal", "prod-a", "buyer@x.com", []string{"core"})

	res, err := verifyLicenseCore("js-key-1", "prod-WRONG", "", "")
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	if res.status != "denied" || res.reason != "not_found" {
		t.Fatalf("cross-check: status=%q reason=%q, want denied/not_found", res.status, res.reason)
	}
}

func TestVerifyCoreDeniesUnknownKey(t *testing.T) {
	setupLicenseTestDB(t)
	res, err := verifyLicenseCore("js-nope", "", "", "")
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	if res.status != "denied" || res.reason != "not_found" {
		t.Fatalf("unknown key: status=%q reason=%q", res.status, res.reason)
	}
}

func TestVerifyCoreBindsMachineOnFirstUse(t *testing.T) {
	setupLicenseTestDB(t)
	issueTestLicense(t, "js-key-1", "lic-internal", "prod-a", "buyer@x.com", []string{"core"})

	fp := `{"components":{"motherboard":"mb","cpu":"c","disk":"d","mac":"m","os_guid":"o"}}`
	res, err := verifyLicenseCore("js-key-1", "prod-a", fp, "buyer@x.com")
	if err != nil || res.status != "valid" {
		t.Fatalf("first use: status=%q err=%v", res.status, err)
	}
	var stored string
	db.DB.QueryRow(`SELECT hardware_fingerprint FROM licenses WHERE id='lic-internal'`).Scan(&stored)
	if stored == "" {
		t.Fatal("machine lock was not bound on first use")
	}
}

func TestVerifyCoreRejectsTamperedSignature(t *testing.T) {
	setupLicenseTestDB(t)
	issueTestLicense(t, "js-key-1", "lic-internal", "prod-a", "buyer@x.com", []string{"core"})
	// Forge: bump max_seats after the signature was minted.
	db.DB.Exec(`UPDATE licenses SET max_seats = 999 WHERE id='lic-internal'`)

	res, err := verifyLicenseCore("js-key-1", "prod-a", "", "")
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	if res.status != "denied" || res.reason != "tampered" {
		t.Fatalf("tamper: status=%q reason=%q, want denied/tampered", res.status, res.reason)
	}
}
