package handlers

import (
	"encoding/json"
	"net/http"

	"github.com/google/uuid"
	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/license"
	"github.com/jadeseal/platform/middleware"
)

// nextRevocationSequence returns the next monotonic CRL sequence number. It is
// MAX(sequence)+1 over the append-only revocation_list; because rows are never
// deleted, the sequence only ever increases, which is what makes a stale CRL
// unreplayable (§6.8).
func nextRevocationSequence() (int64, error) {
	var seq int64
	if err := db.DB.QueryRow(`SELECT COALESCE(MAX(sequence),0) FROM revocation_list`).Scan(&seq); err != nil {
		return 0, err
	}
	return seq + 1, nil
}

// revokeLicense flips an active license to revoked, appends it to the signed
// CRL's backing list with a reason, and audits the action. It returns false
// (with no error) if the license was not active — revoking twice is a no-op,
// not an error (§6.8 idempotence).
func revokeLicense(licenseID, orgID, userID, reason string) (bool, error) {
	res, err := db.DB.Exec(`UPDATE licenses SET status='revoked' WHERE id = ? AND org_id = ? AND status = 'active'`, licenseID, orgID)
	if err != nil {
		return false, err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return false, nil
	}

	seq, err := nextRevocationSequence()
	if err != nil {
		return false, err
	}
	if _, err := db.DB.Exec(`INSERT INTO revocation_list (id, org_id, license_id, reason, revoked_by, sequence) VALUES (?,?,?,?,?,?)`,
		uuid.New().String(), orgID, licenseID, reason, userID, seq); err != nil {
		return false, err
	}
	logAudit(orgID, userID, "license.revoke", "license", licenseID, reason)
	return true, nil
}

// RevokeLicense revokes a license with an optional reason. The reason is what
// makes a revocation defensible in a dispute and auditable (§9.7); a bare
// revoke (no body) still works for backward compatibility.
func (h *Handler) RevokeLicense(w http.ResponseWriter, r *http.Request) {
	licenseID := r.PathValue("id")
	claims := middleware.GetUserClaims(r)

	var req struct {
		Reason string `json:"reason"`
	}
	if r.Body != nil {
		_ = json.NewDecoder(r.Body).Decode(&req)
	}

	revoked, err := revokeLicense(licenseID, claims.OrgID, claims.UserID, req.Reason)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to revoke license")
		return
	}
	if !revoked {
		jsonResponse(w, http.StatusOK, map[string]string{"status": "revoked", "note": "already revoked"})
		return
	}
	jsonResponse(w, http.StatusOK, map[string]string{"status": "revoked"})
}

// GetCRL returns the signed certificate revocation list (§6.8): the current
// sequence, the revoked license ids, and an Ed25519 signature over
// {sequence, license_ids} verifiable against the public key already published
// at /api/license/public-key. Public — a customer's app fetches this to check
// revocation without auth. Multi-tenant deployments should scope it by
// product/org; this single-tenant build serves one global list.
func (h *Handler) GetCRL(w http.ResponseWriter, r *http.Request) {
	rows, err := db.DB.Query(`SELECT license_id FROM revocation_list ORDER BY sequence ASC`)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to read revocation list")
		return
	}
	defer rows.Close()

	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			continue
		}
		ids = append(ids, id)
	}
	if err := rows.Err(); err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to read revocation list")
		return
	}
	if ids == nil {
		ids = []string{}
	}

	var seq int64
	_ = db.DB.QueryRow(`SELECT COALESCE(MAX(sequence),0) FROM revocation_list`).Scan(&seq)

	sig, err := license.SignCRL(license.CRL{Sequence: seq, LicenseIDs: ids})
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to sign revocation list")
		return
	}

	jsonResponse(w, http.StatusOK, map[string]interface{}{
		"sequence":    seq,
		"license_ids": ids,
		"signature":   sig,
	})
}
