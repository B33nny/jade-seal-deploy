package handlers

import (
	"encoding/hex"
	"fmt"
	"net/http"
	"os"
	"path/filepath"

	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/middleware"
)

// GetProtectionDownload streams a finished protection job's artifact back to the
// caller. learning_lab jobs return the validated original; every other profile
// returns the packed .jspk blob produced by the packaging stage (§5.13). The
// artifact is scoped to the caller's org, so one tenant can never fetch another
// tenant's build.
func (h *Handler) GetProtectionDownload(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)
	jobID := r.PathValue("id")

	var status, outputName string
	err := db.DB.QueryRow(`SELECT status, COALESCE(output_file_name,'') FROM protection_jobs WHERE id = ? AND org_id = ?`,
		jobID, claims.OrgID).Scan(&status, &outputName)
	if err != nil {
		jsonError(w, http.StatusNotFound, "Protection job not found")
		return
	}
	if status != "completed" || outputName == "" {
		jsonError(w, http.StatusConflict, "No artifact available for this job yet")
		return
	}

	data, err := os.ReadFile(filepath.Join(h.artifactDir, jobID, outputName))
	if err != nil {
		jsonError(w, http.StatusNotFound, "Artifact file missing")
		return
	}

	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", `attachment; filename="`+outputName+`"`)
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(data)))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(data)
}

// GetBuilderPublicKey returns the packer's Ed25519 public key (§5.13). A
// verifier — an antivirus partner or the customer's integrity checker — needs
// this to validate a Taggant on a packed artifact. It is the *verification*
// key only; it cannot sign, so publishing it leaks nothing an attacker can use
// to forge a packed blob. Public: no auth required.
func (h *Handler) GetBuilderPublicKey(w http.ResponseWriter, r *http.Request) {
	if h.packer == nil {
		jsonError(w, http.StatusServiceUnavailable, "Packer unavailable")
		return
	}
	jsonResponse(w, http.StatusOK, map[string]interface{}{
		"builder_public_key": hex.EncodeToString(h.packer.PublicKey()),
		"algorithm":          "ed25519",
		"format":             "jspk-v1",
	})
}
