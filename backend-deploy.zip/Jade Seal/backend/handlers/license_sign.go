package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"time"

	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/license"
)

// GetLicensePublicKey returns the platform's Ed25519 public key so a customer's
// app can verify a license offline (§6.10). This is the ONLY key a client ever
// receives — the private key stays in memory, server-side.
func (h *Handler) GetLicensePublicKey(w http.ResponseWriter, r *http.Request) {
	jsonResponse(w, http.StatusOK, map[string]string{
		"algorithm":  "ed25519",
		"encoding":   "hex",
		"public_key": license.PublicKeyHex(),
	})
}

// BackfillLicenseSignatures signs any license that predates the Ed25519 anchor
// (an empty signature column). It is idempotent — rows with a valid signature
// are never touched — and runs once at startup so the seeded demo licenses are
// verified, not rejected.
func BackfillLicenseSignatures() error {
	rows, err := db.DB.Query(`SELECT id, product_id, org_id, model, issued_to_email, features, max_seats, expires_at
		FROM licenses WHERE signature IS NULL OR signature = ''`)
	if err != nil {
		return err
	}
	defer rows.Close()

	type unsignedLicense struct {
		id, productID, orgID, model, email, featuresJSON string
		maxSeats                                        int
		expiresAt                                       sql.NullTime
	}
	var toSign []unsignedLicense
	for rows.Next() {
		var u unsignedLicense
		if err := rows.Scan(&u.id, &u.productID, &u.orgID, &u.model, &u.email, &u.featuresJSON, &u.maxSeats, &u.expiresAt); err != nil {
			continue
		}
		toSign = append(toSign, u)
	}

	for _, u := range toSign {
		var features []string
		json.Unmarshal([]byte(u.featuresJSON), &features)
		if features == nil {
			features = []string{}
		}
		var exp time.Time
		if u.expiresAt.Valid {
			exp = u.expiresAt.Time
		}
		sig, err := license.Sign(license.Token{
			LicenseID: u.id,
			ProductID: u.productID,
			OrgID:     u.orgID,
			Model:     u.model,
			Email:     u.email,
			Features:  features,
			MaxSeats:  u.maxSeats,
			ExpiresAt: exp,
		})
		if err != nil {
			return err
		}
		if _, err := db.DB.Exec(`UPDATE licenses SET signature = ? WHERE id = ?`, sig, u.id); err != nil {
			return err
		}
	}
	return nil
}

// BackfillLicenseKeys assigns an unguessable bearer-token license_key to any
// row that predates the §6.4 hardening. Idempotent; runs once at startup.
func BackfillLicenseKeys() error {
	rows, err := db.DB.Query(`SELECT id FROM licenses WHERE license_key IS NULL OR license_key = ''`)
	if err != nil {
		return err
	}
	defer rows.Close()

	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return err
		}
		ids = append(ids, id)
	}
	if err := rows.Err(); err != nil {
		return err
	}

	for _, id := range ids {
		key, err := license.GenerateKey()
		if err != nil {
			return err
		}
		if _, err := db.DB.Exec(`UPDATE licenses SET license_key = ? WHERE id = ? AND (license_key IS NULL OR license_key = '')`, key, id); err != nil {
			return err
		}
	}
	return nil
}
