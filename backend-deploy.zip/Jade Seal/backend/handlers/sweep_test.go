package handlers

import (
	"database/sql"
	"testing"
	"time"

	_ "modernc.org/sqlite"
)

func TestSweepExpiredLicenses(t *testing.T) {
	db, err := sql.Open("sqlite", ":memory:")
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer db.Close()

	if _, err := db.Exec(`CREATE TABLE licenses (id TEXT PRIMARY KEY, status TEXT, expires_at DATETIME)`); err != nil {
		t.Fatal(err)
	}
	past := time.Now().Add(-24 * time.Hour)
	future := time.Now().Add(24 * time.Hour)
	if _, err := db.Exec(`INSERT INTO licenses (id, status, expires_at) VALUES
		('past', 'active', ?),
		('future', 'active', ?),
		('perpetual', 'active', NULL)`, past, future); err != nil {
		t.Fatal(err)
	}

	n, err := SweepExpiredLicenses(db)
	if err != nil {
		t.Fatalf("sweep: %v", err)
	}
	if n != 1 {
		t.Fatalf("swept %d, want 1", n)
	}

	var status string
	if err := db.QueryRow(`SELECT status FROM licenses WHERE id='past'`).Scan(&status); err != nil {
		t.Fatal(err)
	}
	if status != "expired" {
		t.Fatalf("past status = %q, want expired", status)
	}
	for _, id := range []string{"future", "perpetual"} {
		if err := db.QueryRow(`SELECT status FROM licenses WHERE id=?`, id).Scan(&status); err != nil {
			t.Fatal(err)
		}
		if status != "active" {
			t.Fatalf("%s status = %q, want active", id, status)
		}
	}
}
