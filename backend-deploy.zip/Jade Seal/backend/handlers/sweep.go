package handlers

import (
	"database/sql"
	"time"
)

// SweepExpiredLicenses flips any active license whose expires_at has passed to
// status='expired' (§6.7 expiry sweeper). It compares timestamps in Go rather
// than SQL so it matches VerifyLicense's lazy check exactly — the licenses table
// mixes SQLite datetime strings (seeded rows) with Go-serialised times (rows
// written by IssueLicense), and a SQL string compare would mis-handle that.
// Returns the number of licenses expired.
func SweepExpiredLicenses(database *sql.DB) (int, error) {
	rows, err := database.Query(`SELECT id, expires_at FROM licenses WHERE status = 'active' AND expires_at IS NOT NULL`)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	now := time.Now()
	var expired []string
	for rows.Next() {
		var id string
		var at time.Time
		if err := rows.Scan(&id, &at); err != nil {
			continue
		}
		if at.Before(now) {
			expired = append(expired, id)
		}
	}
	if err := rows.Err(); err != nil {
		return 0, err
	}

	n := 0
	for _, id := range expired {
		if _, err := database.Exec(`UPDATE licenses SET status = 'expired' WHERE id = ? AND status = 'active'`, id); err != nil {
			return n, err
		}
		n++
	}
	return n, nil
}
