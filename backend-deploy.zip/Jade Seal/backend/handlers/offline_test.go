package handlers

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/license"
	"github.com/jadeseal/platform/models"
	"github.com/jadeseal/platform/nonce"
)

// setupOfflineTestDB reuses the shared license test fixture and adds the
// offline_counters table the offline path advances.
func setupOfflineTestDB(t *testing.T) {
	t.Helper()
	setupLicenseTestDB(t)
	if _, err := db.DB.Exec(`CREATE TABLE IF NOT EXISTS offline_counters (
		license_id TEXT PRIMARY KEY, counter INTEGER NOT NULL DEFAULT 0)`); err != nil {
		t.Fatal(err)
	}
}

func newOfflineHandler() *Handler {
	return &Handler{nonces: nonce.New(5*time.Minute, 1024)}
}

func TestNextOfflineCounterMonotonic(t *testing.T) {
	setupOfflineTestDB(t)
	c1, err := nextOfflineCounter("lic-1")
	if err != nil {
		t.Fatalf("first counter: %v", err)
	}
	c2, err := nextOfflineCounter("lic-1")
	if err != nil {
		t.Fatalf("second counter: %v", err)
	}
	if c1 >= c2 {
		t.Fatalf("counter not monotonic: %d then %d", c1, c2)
	}
	// A different license gets its own sequence.
	c3, _ := nextOfflineCounter("lic-2")
	if c3 != 1 {
		t.Fatalf("separate license counter = %d, want 1", c3)
	}
}

func TestOfflineExpiryCapsPerpetual(t *testing.T) {
	issued := time.Unix(1700000000, 0)
	got := offlineExpiry(nil, issued)
	want := issued.Add(offlineMaxTTL)
	if !got.Equal(want) {
		t.Fatalf("perpetual cap = %v, want %v", got, want)
	}
}

func TestOfflineExpiryPrefersLicenseExpiry(t *testing.T) {
	issued := time.Unix(1700000000, 0)
	lic := issued.Add(24 * time.Hour) // license expires well before the 30d cap
	if got := offlineExpiry(&lic, issued); !got.Equal(lic) {
		t.Fatalf("expected license expiry %v, got %v", lic, got)
	}
}

func TestActivateOfflineReturnsSignedTicket(t *testing.T) {
	setupOfflineTestDB(t)
	issueTestLicense(t, "js-offline-1", "lic-offline", "prod-a", "buyer@x.com", []string{"core"})

	h := newOfflineHandler()
	body, _ := json.Marshal(models.OfflineActivateRequest{
		LicenseKey: "js-offline-1",
		FPHash:     `{"components":{"motherboard":"mb","cpu":"c","disk":"d","mac":"m","os_guid":"o"}}`,
		Email:      "buyer@x.com",
		Nonce:      "nonce-1",
		TS:         time.Now().Unix(),
	})
	req := httptest.NewRequest(http.MethodPost, "/api/license/offline/activate", bytes.NewReader(body))
	rec := httptest.NewRecorder()
	h.ActivateOffline(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("status %d: %s", rec.Code, rec.Body.String())
	}
	var resp models.OfflineActivateResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if resp.Status != "valid" {
		t.Fatalf("status = %q (%s), want valid", resp.Status, resp.Message)
	}
	if resp.Signature == "" || resp.SeatID == "" {
		t.Fatalf("missing signature/seat: %+v", resp)
	}
	if resp.Counter != 1 {
		t.Fatalf("counter = %d, want 1", resp.Counter)
	}

	// The signature must verify against the platform public key.
	if !license.VerifyOfflineTicket(license.OfflineTicket{
		LicenseKey: "js-offline-1",
		SeatID:     resp.SeatID,
		FPHash:     `{"components":{"motherboard":"mb","cpu":"c","disk":"d","mac":"m","os_guid":"o"}}`,
		Counter:    resp.Counter,
		IssuedAt:   time.Unix(resp.IssuedAt, 0),
		ExpiresAt:  *resp.ExpiresAt,
	}, resp.Signature) {
		t.Fatal("offline ticket signature did not verify")
	}
}

func TestActivateOfflineRejectsReplay(t *testing.T) {
	setupOfflineTestDB(t)
	issueTestLicense(t, "js-offline-2", "lic-offline2", "prod-a", "buyer@x.com", []string{"core"})

	h := newOfflineHandler()
	mk := func(nonce string) *http.Request {
		body, _ := json.Marshal(models.OfflineActivateRequest{
			LicenseKey: "js-offline-2",
			FPHash:     `{"components":{"motherboard":"mb","cpu":"c","disk":"d","mac":"m","os_guid":"o"}}`,
			Email:      "buyer@x.com",
			Nonce:      nonce,
			TS:         time.Now().Unix(),
		})
		return httptest.NewRequest(http.MethodPost, "/api/license/offline/activate", bytes.NewReader(body))
	}

	first := httptest.NewRecorder()
	h.ActivateOffline(first, mk("nonce-dup"))
	if first.Code != http.StatusOK {
		t.Fatalf("first: %d %s", first.Code, first.Body.String())
	}

	second := httptest.NewRecorder()
	h.ActivateOffline(second, mk("nonce-dup"))
	var resp models.OfflineActivateResponse
	json.Unmarshal(second.Body.Bytes(), &resp)
	if resp.Status != "denied" || resp.Reason != "replay" {
		t.Fatalf("replay not refused: %+v", resp)
	}
}
