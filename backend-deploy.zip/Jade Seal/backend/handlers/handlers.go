package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"

	"github.com/google/uuid"
	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/hwid"
	"github.com/jadeseal/platform/license"
	"github.com/jadeseal/platform/middleware"
	"github.com/jadeseal/platform/nonce"
	"github.com/jadeseal/platform/models"
	"github.com/jadeseal/platform/protect"
	"github.com/jadeseal/platform/protect/encrypt"
	"github.com/jadeseal/platform/protect/packer"
	"github.com/jadeseal/platform/sandbox"
	jsws "github.com/jadeseal/platform/websocket"
)

type Handler struct {
	docker      *sandbox.DockerRuntime
	artifactDir string
	nonces      *nonce.Store
	packer      *packer.Packer
}

func NewHandler(docker *sandbox.DockerRuntime, artifactDir string) *Handler {
	h := &Handler{
		docker:      docker,
		artifactDir: artifactDir,
		// Anti-replay nonce store (§6.4): a bounded TTL set; ts skew is ±300s,
		// so 10 minutes is skew + processing buffer.
		nonces: nonce.New(10*time.Minute, 10000),
	}

	// The builder packer signs packed artifacts (Taggant, §5.13). Its key is
	// derived from the license signing seed via HKDF so it is stable across
	// restarts without managing a second secret; the same seed always yields
	// the same packer public key, which is what lets a verifier trust a packed
	// blob produced on a previous run.
	if seed, err := license.SigningSeed(); err == nil {
		if key, err := encrypt.DeriveKey(seed, "jade-seal-packer-v1", 32); err == nil {
			if p, err := packer.New(key); err == nil {
				h.packer = p
			}
		}
	}
	if h.packer == nil {
		// license.Init is fatal on failure, so this path is only reachable in a
		// misconfigured process. Fall back to an ephemeral key and say so: the
		// packer still works, but its public key is not stable across restarts.
		if p, err := packer.NewRandom(); err != nil {
			log.Printf("WARNING: packer key unavailable: %v — protected downloads disabled", err)
		} else {
			log.Printf("WARNING: using ephemeral packer key (license signing seed unavailable)")
			h.packer = p
		}
	}
	return h
}

// ─── HELPERS ──────────────────────────────────────────────

func jsonResponse(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func jsonError(w http.ResponseWriter, status int, message string) {
	jsonResponse(w, status, map[string]string{"error": message})
}

func logAudit(orgID, userID, action, resourceType, resourceID, details string) {
	db.DB.Exec(`INSERT INTO audit_log (id, org_id, user_id, action, resource_type, resource_id, details) VALUES (?,?,?,?,?,?,?)`,
		uuid.New().String(), orgID, userID, action, resourceType, resourceID, details)
}

// ─── AUTH HANDLERS ────────────────────────────────────────

func (h *Handler) Login(w http.ResponseWriter, r *http.Request) {
	var req models.LoginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	var user models.User
	err := db.DB.QueryRow(
		"SELECT id, org_id, email, password_hash, name, role, mfa_enabled FROM users WHERE email = ?",
		req.Email,
	).Scan(&user.ID, &user.OrgID, &user.Email, &user.PasswordHash, &user.Name, &user.Role, &user.MFAEnabled)

	if err == sql.ErrNoRows {
		jsonError(w, http.StatusUnauthorized, "Invalid email or password")
		return
	}
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Database error")
		return
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)); err != nil {
		jsonError(w, http.StatusUnauthorized, "Invalid email or password")
		return
	}

	accessToken, err := middleware.GenerateToken(user.ID, user.Email, user.Role, user.OrgID)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to generate token")
		return
	}

	refreshToken, err := middleware.GenerateRefreshToken(user.ID)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to generate refresh token")
		return
	}

	// Update last login
	db.DB.Exec("UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = ?", user.ID)
	logAudit(user.OrgID, user.ID, "user.login", "user", user.ID, "")

	jsonResponse(w, http.StatusOK, models.LoginResponse{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		User:         user,
	})
}

func (h *Handler) Me(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)
	if claims == nil {
		jsonError(w, http.StatusUnauthorized, "Unauthorized")
		return
	}

	var user models.User
	err := db.DB.QueryRow(
		"SELECT id, org_id, email, name, role, mfa_enabled FROM users WHERE id = ?",
		claims.UserID,
	).Scan(&user.ID, &user.OrgID, &user.Email, &user.Name, &user.Role, &user.MFAEnabled)

	if err != nil {
		jsonError(w, http.StatusNotFound, "User not found")
		return
	}

	jsonResponse(w, http.StatusOK, user)
}

func (h *Handler) RefreshToken(w http.ResponseWriter, r *http.Request) {
	var req struct {
		RefreshToken string `json:"refresh_token"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	// Validate refresh token independently (not reusing access token parser)
	claims, err := middleware.ValidateRefreshToken(req.RefreshToken)
	if err != nil {
		jsonError(w, http.StatusUnauthorized, "Invalid or expired refresh token")
		return
	}

	// Look up user to get current role/org
	var email, role, orgID string
	err = db.DB.QueryRow("SELECT email, role, org_id FROM users WHERE id = ?", claims.UserID).Scan(&email, &role, &orgID)
	if err != nil {
		jsonError(w, http.StatusUnauthorized, "User not found")
		return
	}

	accessToken, _ := middleware.GenerateToken(claims.UserID, email, role, orgID)
	newRefreshToken, _ := middleware.GenerateRefreshToken(claims.UserID)

	jsonResponse(w, http.StatusOK, map[string]string{
		"access_token":  accessToken,
		"refresh_token": newRefreshToken,
	})
}

// ─── SANDBOX HANDLERS ─────────────────────────────────────

func (h *Handler) ListTemplates(w http.ResponseWriter, r *http.Request) {
	rows, err := db.DB.Query("SELECT id, name, description, os_type, image, default_isolation, preinstalled_apps, icon, category FROM sandbox_templates ORDER BY name")
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to fetch templates")
		return
	}
	defer rows.Close()

	var templates []models.SandboxTemplate
	for rows.Next() {
		var t models.SandboxTemplate
		var appsJSON string
		if err := rows.Scan(&t.ID, &t.Name, &t.Description, &t.OSType, &t.Image, &t.DefaultIsolation, &appsJSON, &t.Icon, &t.Category); err != nil {
			continue
		}
		json.Unmarshal([]byte(appsJSON), &t.PreinstalledApps)
		if t.PreinstalledApps == nil {
			t.PreinstalledApps = []string{}
		}
		templates = append(templates, t)
	}

	jsonResponse(w, http.StatusOK, templates)
}

func (h *Handler) ListSandboxes(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	statusFilter := r.URL.Query().Get("status")
	searchFilter := r.URL.Query().Get("search")

	query := `SELECT s.id, s.org_id, s.user_id, COALESCE(s.name,''), s.template_id, 
		COALESCE(t.name,''), s.status, s.isolation_tier, s.license_id, 
		COALESCE(s.container_id,''), COALESCE(s.ip_address,''), COALESCE(s.port,0),
		COALESCE(s.vnc_websocket,''), s.cpu_cores, s.memory_mb, s.disk_gb,
		s.created_at, s.started_at, s.stopped_at
		FROM sandboxes s LEFT JOIN sandbox_templates t ON s.template_id = t.id
		WHERE s.org_id = ?`
	args := []interface{}{claims.OrgID}

	if statusFilter != "" {
		query += " AND s.status = ?"
		args = append(args, statusFilter)
	}
	if searchFilter != "" {
		query += " AND (s.name LIKE ? OR t.name LIKE ?)"
		args = append(args, "%"+searchFilter+"%", "%"+searchFilter+"%")
	}
	query += " ORDER BY s.created_at DESC"

	rows, err := db.DB.Query(query, args...)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to fetch sandboxes")
		return
	}
	defer rows.Close()

	var sandboxes []models.Sandbox
	for rows.Next() {
		var s models.Sandbox
		var startedAt, stoppedAt sql.NullTime
		if err := rows.Scan(&s.ID, &s.OrgID, &s.UserID, &s.Name, &s.TemplateID,
			&s.TemplateName, &s.Status, &s.IsolationTier, &s.LicenseID,
			&s.ContainerID, &s.IPAddress, &s.Port, &s.VNCWebSocket,
			&s.CPUCores, &s.MemoryMB, &s.DiskGB,
			&s.CreatedAt, &startedAt, &stoppedAt); err != nil {
			continue
		}
		if startedAt.Valid {
			s.StartedAt = &startedAt.Time
		}
		if stoppedAt.Valid {
			s.StoppedAt = &stoppedAt.Time
		}
		sandboxes = append(sandboxes, s)
	}
	if sandboxes == nil {
		sandboxes = []models.Sandbox{}
	}

	jsonResponse(w, http.StatusOK, sandboxes)
}

func (h *Handler) CreateSandbox(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	var req models.CreateSandboxRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if req.IsolationTier == "" {
		req.IsolationTier = "container"
	}
	if req.CPUCores == 0 {
		req.CPUCores = 2
	}
	if req.MemoryMB == 0 {
		req.MemoryMB = 4096
	}
	if req.DiskGB == 0 {
		req.DiskGB = 20
	}

	// Get template info
	var templateImage, templateName string
	err := db.DB.QueryRow("SELECT image, name FROM sandbox_templates WHERE id = ?", req.TemplateID).Scan(&templateImage, &templateName)
	if err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid template ID")
		return
	}

	sandboxID := "sbx-" + uuid.New().String()[:8]
	sandboxName := fmt.Sprintf("%s-%s", strings.Split(templateName, " ")[0], sandboxID[len(sandboxID)-4:])

	// Create DB record
	_, err = db.DB.Exec(`INSERT INTO sandboxes (id, org_id, template_id, user_id, name, status, isolation_tier, license_id, cpu_cores, memory_mb, disk_gb)
		VALUES (?,?,?,?,?, 'provisioning', ?, ?, ?, ?, ?)`,
		sandboxID, claims.OrgID, req.TemplateID, claims.UserID, sandboxName, req.IsolationTier, req.LicenseID, req.CPUCores, req.MemoryMB, req.DiskGB)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to create sandbox record")
		return
	}

	logAudit(claims.OrgID, claims.UserID, "sandbox.create", "sandbox", sandboxID, templateName)

	// Try to create Docker container
	if h.docker != nil {
		containerName := fmt.Sprintf("jadeseal-%s", sandboxID)
		containerID, err := h.docker.CreateContainer(containerName, templateImage, req.CPUCores, req.MemoryMB)
		if err != nil {
			log.Printf("Docker create error: %v (continuing with simulated sandbox)", err)
			db.DB.Exec("UPDATE sandboxes SET status='running', ip_address='127.0.0.1', port=0, vnc_websocket='', started_at=CURRENT_TIMESTAMP WHERE id=?", sandboxID)
		} else {
			if err := h.docker.StartContainer(containerID); err != nil {
				log.Printf("Docker start error: %v", err)
				db.DB.Exec("UPDATE sandboxes SET status='running', ip_address='127.0.0.1', port=0, started_at=CURRENT_TIMESTAMP WHERE id=?", sandboxID)
			} else {
				db.DB.Exec("UPDATE sandboxes SET status='running', container_id=?, ip_address='127.0.0.1', port=8080, started_at=CURRENT_TIMESTAMP WHERE id=?", containerID, sandboxID)
			}
		}
	} else {
		// Simulated mode - instantly "running"
		db.DB.Exec("UPDATE sandboxes SET status='running', ip_address='127.0.0.1', port=8080, vnc_websocket='ws://localhost:8080/ws/terminal', started_at=CURRENT_TIMESTAMP WHERE id=?", sandboxID)
	}

	jsonResponse(w, http.StatusCreated, map[string]string{
		"id":     sandboxID,
		"status": "running",
		"name":   sandboxName,
	})
}

func (h *Handler) GetSandbox(w http.ResponseWriter, r *http.Request) {
	sandboxID := r.PathValue("id")
	claims := middleware.GetUserClaims(r)

	var s models.Sandbox
	var startedAt, stoppedAt sql.NullTime
	err := db.DB.QueryRow(`SELECT s.id, s.org_id, s.user_id, COALESCE(s.name,''), s.template_id, 
		COALESCE(t.name,''), s.status, s.isolation_tier, s.license_id, 
		COALESCE(s.container_id,''), COALESCE(s.ip_address,''), COALESCE(s.port,0),
		COALESCE(s.vnc_websocket,''), s.cpu_cores, s.memory_mb, s.disk_gb,
		s.created_at, s.started_at, s.stopped_at
		FROM sandboxes s LEFT JOIN sandbox_templates t ON s.template_id = t.id
		WHERE s.id = ? AND s.org_id = ?`, sandboxID, claims.OrgID).
		Scan(&s.ID, &s.OrgID, &s.UserID, &s.Name, &s.TemplateID,
			&s.TemplateName, &s.Status, &s.IsolationTier, &s.LicenseID,
			&s.ContainerID, &s.IPAddress, &s.Port, &s.VNCWebSocket,
			&s.CPUCores, &s.MemoryMB, &s.DiskGB, &s.CreatedAt, &startedAt, &stoppedAt)

	if err == sql.ErrNoRows {
		jsonError(w, http.StatusNotFound, "Sandbox not found")
		return
	}
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Database error")
		return
	}
	if startedAt.Valid {
		s.StartedAt = &startedAt.Time
	}
	if stoppedAt.Valid {
		s.StoppedAt = &stoppedAt.Time
	}

	jsonResponse(w, http.StatusOK, s)
}

func (h *Handler) StopSandbox(w http.ResponseWriter, r *http.Request) {
	sandboxID := r.PathValue("id")
	claims := middleware.GetUserClaims(r)

	var containerID, status string
	err := db.DB.QueryRow("SELECT container_id, status FROM sandboxes WHERE id = ? AND org_id = ?", sandboxID, claims.OrgID).Scan(&containerID, &status)
	if err != nil {
		jsonError(w, http.StatusNotFound, "Sandbox not found")
		return
	}

	if status == "terminated" {
		jsonError(w, http.StatusBadRequest, "Sandbox is already stopped")
		return
	}

	if h.docker != nil && containerID != "" {
		h.docker.StopContainer(containerID)
	}

	db.DB.Exec("UPDATE sandboxes SET status='terminated', stopped_at=CURRENT_TIMESTAMP WHERE id=?", sandboxID)
	logAudit(claims.OrgID, claims.UserID, "sandbox.stop", "sandbox", sandboxID, "")

	jsonResponse(w, http.StatusOK, map[string]string{"status": "terminated"})
}

func (h *Handler) DeleteSandbox(w http.ResponseWriter, r *http.Request) {
	sandboxID := r.PathValue("id")
	claims := middleware.GetUserClaims(r)

	var containerID string
	db.DB.QueryRow("SELECT container_id FROM sandboxes WHERE id = ? AND org_id = ?", sandboxID, claims.OrgID).Scan(&containerID)

	if h.docker != nil && containerID != "" {
		h.docker.RemoveContainer(containerID)
	}

	db.DB.Exec("DELETE FROM sandboxes WHERE id = ? AND org_id = ?", sandboxID, claims.OrgID)
	logAudit(claims.OrgID, claims.UserID, "sandbox.delete", "sandbox", sandboxID, "")

	jsonResponse(w, http.StatusOK, map[string]string{"status": "deleted"})
}

func (h *Handler) SandboxConnect(w http.ResponseWriter, r *http.Request) {
	sandboxID := r.PathValue("id")
	claims := middleware.GetUserClaims(r)

	var status, ip string
	var port int
	err := db.DB.QueryRow("SELECT status, ip_address, port FROM sandboxes WHERE id = ? AND org_id = ?", sandboxID, claims.OrgID).Scan(&status, &ip, &port)
	if err != nil {
		jsonError(w, http.StatusNotFound, "Sandbox not found")
		return
	}

	if status != "running" {
		jsonError(w, http.StatusBadRequest, "Sandbox is not running")
		return
	}

	jsonResponse(w, http.StatusOK, map[string]interface{}{
		"vnc_url":         fmt.Sprintf("ws://%s:%d/ws/vnc", ip, port),
		"ssh_command":      fmt.Sprintf("ssh user@%s -p %d", ip, port+1),
		"websocket_url":    fmt.Sprintf("ws://%s:%d/ws/terminal", ip, port),
		"token":            "sandbox-token-" + sandboxID,
	})
}

// ─── LICENSE HANDLERS ─────────────────────────────────────

func (h *Handler) ListLicenses(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	statusFilter := r.URL.Query().Get("status")
	searchFilter := r.URL.Query().Get("search")

	query := `SELECT l.id, l.product_id, COALESCE(p.name,''), l.org_id, l.type, l.model, l.status,
		l.issued_to_email, COALESCE(l.issued_to_user_id,''), l.issued_by_user_id,
		l.features, l.max_seats, l.issued_at, l.expires_at, 
		COALESCE(l.hardware_fingerprint,''), COALESCE(l.signature,''), l.created_at
		FROM licenses l LEFT JOIN products p ON l.product_id = p.id
		WHERE l.org_id = ?`
	args := []interface{}{claims.OrgID}

	if statusFilter != "" {
		query += " AND l.status = ?"
		args = append(args, statusFilter)
	}
	if searchFilter != "" {
		query += " AND (l.issued_to_email LIKE ? OR p.name LIKE ? OR l.id LIKE ?)"
		args = append(args, "%"+searchFilter+"%", "%"+searchFilter+"%", "%"+searchFilter+"%")
	}
	query += " ORDER BY l.created_at DESC"

	rows, err := db.DB.Query(query, args...)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to fetch licenses")
		return
	}
	defer rows.Close()

	var licenses []models.License
	for rows.Next() {
		var l models.License
		var featuresJSON string
		var expiresAt sql.NullTime
		if err := rows.Scan(&l.ID, &l.ProductID, &l.ProductName, &l.OrgID, &l.Type, &l.Model, &l.Status,
			&l.IssuedToEmail, &l.IssuedToUserID, &l.IssuedByUserID,
			&featuresJSON, &l.MaxSeats, &l.IssuedAt, &expiresAt,
			&l.HardwareFingerprint, &l.Signature, &l.CreatedAt); err != nil {
			continue
		}
		json.Unmarshal([]byte(featuresJSON), &l.Features)
		if l.Features == nil {
			l.Features = []string{}
		}
		if expiresAt.Valid {
			l.ExpiresAt = &expiresAt.Time
		}
		licenses = append(licenses, l)
	}
	if licenses == nil {
		licenses = []models.License{}
	}

	jsonResponse(w, http.StatusOK, licenses)
}

func (h *Handler) IssueLicense(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	var req models.IssueLicenseRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if req.Type == "" {
		req.Type = "cloud"
	}
	if req.Model == "" {
		req.Model = "trial"
	}
	if req.MaxSeats == 0 {
		req.MaxSeats = 1
	}

	// Validate product exists
	var productName string
	err := db.DB.QueryRow("SELECT name FROM products WHERE id = ? AND org_id = ?", req.ProductID, claims.OrgID).Scan(&productName)
	if err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid product ID")
		return
	}

	licenseID := "lic-" + uuid.New().String()[:8]
	// The customer-facing license key is an unguessable bearer token (§6.4),
	// distinct from the enumerable internal id.
	licenseKey, err := license.GenerateKey()
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to generate license key")
		return
	}
	featuresJSON, _ := json.Marshal(req.Features)

	var expiresAt *time.Time
	if req.ExpiresInDays > 0 {
		t := time.Now().Add(time.Duration(req.ExpiresInDays) * 24 * time.Hour)
		expiresAt = &t
	}

	// Sign the entitlements so a customer's app can verify the license offline
	// against the platform public key — the Phase A "signed tokens" anchor (§6.10).
	// The signature is over the exact fields in license.Token; any mismatch later
	// fails verification closed.
	var tokenExpiresAt time.Time
	if expiresAt != nil {
		tokenExpiresAt = *expiresAt
	}
	signature, err := license.Sign(license.Token{
		LicenseID: licenseID,
		ProductID: req.ProductID,
		OrgID:     claims.OrgID,
		Model:     req.Model,
		Email:     req.IssuedToEmail,
		Features:  req.Features,
		MaxSeats:  req.MaxSeats,
		ExpiresAt: tokenExpiresAt,
	})
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to sign license")
		return
	}

	_, err = db.DB.Exec(`INSERT INTO licenses (id, product_id, org_id, type, model, status, issued_to_email, issued_by_user_id, features, max_seats, expires_at, signature, license_key)
		VALUES (?,?,?,?,?, 'active', ?, ?, ?, ?, ?, ?, ?)`,
		licenseID, req.ProductID, claims.OrgID, req.Type, req.Model, req.IssuedToEmail, claims.UserID, string(featuresJSON), req.MaxSeats, expiresAt, signature, licenseKey)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to issue license")
		return
	}

	logAudit(claims.OrgID, claims.UserID, "license.issue", "license", licenseID, fmt.Sprintf("Product: %s, Type: %s, Model: %s", productName, req.Type, req.Model))

	jsonResponse(w, http.StatusCreated, map[string]interface{}{
		"id":          licenseID,
		"license_key": licenseKey,
		"status":      "active",
		"product":     productName,
		"issued_to":   req.IssuedToEmail,
		"expires_at":  expiresAt,
		"signature":   signature,
	})
}

// licenseResult is the outcome of a license verification, independent of the
// wire format, so VerifyLicense (plain JSON) and Activate (signed token) share
// one enforcement path and can never drift apart.
type licenseResult struct {
	status    string
	reason    string
	message   string
	features  []string
	expiresAt *time.Time
	licenseID string
	orgID     string
	model     string
	maxSeats  int
	email     string
	productID string
}

// verifyLicenseCore is the single enforcement path for a license: the §6.10
// signed anchor → status/expiry/email gates → §6.3 fuzzy machine lock. It looks
// the license up by its customer-facing key, falling back to the internal id
// for legacy rows. The machine lock is bound/soft-rebound here as a side
// effect. A non-nil error means a genuine server fault, not a denied license.
func verifyLicenseCore(key, productID, fpHash, email string) (licenseResult, error) {
	deny := func(reason, message string) licenseResult {
		return licenseResult{status: "denied", reason: reason, message: message}
	}

	var licenseID, foundProductID, status, featuresJSON, fingerprint, issuedToEmail, model, orgID, signature string
	var maxSeats int
	var expiresAt sql.NullTime
	err := db.DB.QueryRow(
		`SELECT id, product_id, status, features, expires_at, COALESCE(hardware_fingerprint,''), COALESCE(issued_to_email,''), org_id, model, max_seats, COALESCE(signature,'')
		 FROM licenses WHERE license_key = ? OR id = ?`, key, key,
	).Scan(&licenseID, &foundProductID, &status, &featuresJSON, &expiresAt, &fingerprint, &issuedToEmail, &orgID, &model, &maxSeats, &signature)

	if err == sql.ErrNoRows {
		return deny("not_found", "License not found."), nil
	}
	if err != nil {
		return licenseResult{}, err
	}

	// If the caller also supplied a product id, it must match — a key must not
	// be honoured against a different product.
	if strings.TrimSpace(productID) != "" && productID != foundProductID {
		return deny("not_found", "License not found."), nil
	}

	var features []string
	json.Unmarshal([]byte(featuresJSON), &features)
	if features == nil {
		features = []string{}
	}

	var tokenExpiresAt time.Time
	if expiresAt.Valid {
		tokenExpiresAt = expiresAt.Time
	}

	// Cryptographic anchor: the license must carry a signature over exactly
	// these entitlements, verifiable against the platform public key (§6.10).
	// A missing or invalid signature means the record was forged or predates
	// the anchor — fail closed.
	if signature == "" || !license.Verify(license.Token{
		LicenseID: licenseID,
		ProductID: foundProductID,
		OrgID:     orgID,
		Model:     model,
		Email:     issuedToEmail,
		Features:  features,
		MaxSeats:  maxSeats,
		ExpiresAt: tokenExpiresAt,
	}, signature) {
		return deny("tampered", "License signature is missing or invalid."), nil
	}

	switch status {
	case "revoked":
		return deny("revoked", "This license has been revoked."), nil
	case "suspended":
		return deny("suspended", "This license is suspended."), nil
	case "expired":
		return deny("expired", "This license has expired."), nil
	}

	if expiresAt.Valid && expiresAt.Time.Before(time.Now()) {
		db.DB.Exec("UPDATE licenses SET status='expired' WHERE id=?", licenseID)
		return deny("expired", fmt.Sprintf("This license expired on %s. Please contact your administrator to renew.", expiresAt.Time.Format("2006-01-02"))), nil
	}

	// Email match — stops a guessed code from being bound first. Enforce
	// whenever the license has an issued email, so an empty email can't bypass.
	if strings.TrimSpace(issuedToEmail) != "" && !strings.EqualFold(strings.TrimSpace(email), issuedToEmail) {
		return deny("email_mismatch", "This license was issued to a different email address."), nil
	}

	// Machine lock: bind on first use, then require a weighted-fuzzy match
	// against the stored fingerprint (§6.3).
	decision, weight, persist := hwid.Compare(fingerprint, fpHash)
	switch decision {
	case hwid.BindFirst:
		db.DB.Exec("UPDATE licenses SET hardware_fingerprint = ? WHERE id = ?", persist, licenseID)
	case hwid.Deny:
		return deny("machine_mismatch", fmt.Sprintf("This license is bound to a different computer (fingerprint match %.0f%%). Contact your administrator to re-bind.", weight*100)), nil
	case hwid.Pass:
		if persist != "" {
			db.DB.Exec("UPDATE licenses SET hardware_fingerprint = ? WHERE id = ?", persist, licenseID)
		}
	}

	var expiresPtr *time.Time
	if expiresAt.Valid {
		expiresPtr = &expiresAt.Time
	}
	return licenseResult{
		status:    "valid",
		features:  features,
		expiresAt: expiresPtr,
		licenseID: licenseID,
		orgID:     orgID,
		model:     model,
		maxSeats:  maxSeats,
		email:     issuedToEmail,
		productID: foundProductID,
	}, nil
}

func (h *Handler) VerifyLicense(w http.ResponseWriter, r *http.Request) {
	var req models.VerifyLicenseRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request")
		return
	}

	key := req.LicenseKey
	if key == "" {
		key = req.LicenseID
	}

	res, err := verifyLicenseCore(key, req.ProductID, req.HWID, req.Email)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Verification failed")
		return
	}
	jsonResponse(w, http.StatusOK, models.VerifyLicenseResponse{
		Status:    res.status,
		LicenseID: res.licenseID,
		Features:  res.features,
		Reason:    res.reason,
		Message:   res.message,
		ExpiresAt: res.expiresAt,
	})
}

// activationSkew is the §6.4 clock-skew window in seconds: a request timestamp
// outside ±activationSkew of the server clock is rejected as stale.
const activationSkew = 300

// Activate is the §6.4 online-activation endpoint: it anti-replay-checks the
// request (nonce + timestamp), runs the shared verification path, and — on
// success — returns an Ed25519-signed "you may run" token bound to the machine
// fingerprint, plus a server time anchor the client can use to detect rollback.
func (h *Handler) Activate(w http.ResponseWriter, r *http.Request) {
	var req models.ActivateRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request")
		return
	}

	now := time.Now()

	// Anti-replay (§6.12): a stale timestamp or a reused nonce is refused before
	// any license work happens.
	if req.TS == 0 || now.Unix()-req.TS > activationSkew || req.TS-now.Unix() > activationSkew {
		jsonResponse(w, http.StatusOK, models.ActivateResponse{
			Status: "denied", Reason: "stale", Message: "Request timestamp is outside the allowed window.", ServerTime: now.Unix(),
		})
		return
	}
	if req.Nonce == "" || !h.nonces.Record(req.LicenseKey+"\x00"+req.Nonce) {
		jsonResponse(w, http.StatusOK, models.ActivateResponse{
			Status: "denied", Reason: "replay", Message: "Duplicate request (nonce already used).", ServerTime: now.Unix(),
		})
		return
	}

	res, err := verifyLicenseCore(req.LicenseKey, req.ProductID, req.FPHash, req.Email)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Activation failed")
		return
	}
	if res.status != "valid" {
		jsonResponse(w, http.StatusOK, models.ActivateResponse{
			Status: res.status, Reason: res.reason, Message: res.message, ServerTime: now.Unix(),
		})
		return
	}

	seatID := "seat-" + uuid.New().String()[:8]
	sig, err := license.SignActivation(license.Activation{
		LicenseID: res.licenseID,
		SeatID:    seatID,
		FPHash:    req.FPHash,
		MaxSeats:  res.maxSeats,
		IssuedAt:  now,
		ExpiresAt: zeroOr(res.expiresAt),
	})
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to sign activation")
		return
	}

	jsonResponse(w, http.StatusOK, models.ActivateResponse{
		Status:     "valid",
		LicenseID:  res.licenseID,
		SeatID:     seatID,
		Signature:  sig,
		ServerTime: now.Unix(),
		ExpiresAt:  res.expiresAt,
	})
}

func zeroOr(t *time.Time) time.Time {
	if t == nil {
		return time.Time{}
	}
	return *t
}

// ─── PRODUCT HANDLERS ─────────────────────────────────────

func (h *Handler) ListProducts(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	rows, err := db.DB.Query("SELECT id, org_id, name, version FROM products WHERE org_id = ?", claims.OrgID)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to fetch products")
		return
	}
	defer rows.Close()

	var products []models.Product
	for rows.Next() {
		var p models.Product
		if err := rows.Scan(&p.ID, &p.OrgID, &p.Name, &p.Version); err != nil {
			continue
		}
		products = append(products, p)
	}
	if products == nil {
		products = []models.Product{}
	}

	jsonResponse(w, http.StatusOK, products)
}

// ─── PROTECTION JOB HANDLERS ──────────────────────────────

func (h *Handler) ListProtectionJobs(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	rows, err := db.DB.Query(`SELECT id, org_id, user_id, profile_id, input_file_name, platform, status,
		progress_pct, COALESCE(duration,''), COALESCE(output_file_name,''), COALESCE(error_message,''),
		COALESCE(integrity_hash,''), COALESCE(binary_format,''), created_at, completed_at
		FROM protection_jobs WHERE org_id = ? ORDER BY created_at DESC`, claims.OrgID)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to fetch protection jobs")
		return
	}
	defer rows.Close()

	var jobs []models.ProtectionJob
	for rows.Next() {
		var j models.ProtectionJob
		var completedAt sql.NullTime
		if err := rows.Scan(&j.ID, &j.OrgID, &j.UserID, &j.ProfileID, &j.InputFileName, &j.Platform,
			&j.Status, &j.ProgressPct, &j.Duration, &j.OutputFileName, &j.ErrorMessage,
			&j.IntegrityHash, &j.BinaryFormat, &j.CreatedAt, &completedAt); err != nil {
			continue
		}
		if completedAt.Valid {
			j.CompletedAt = &completedAt.Time
		}
		jobs = append(jobs, j)
	}
	if jobs == nil {
		jobs = []models.ProtectionJob{}
	}

	jsonResponse(w, http.StatusOK, jobs)
}

// platformProfileMatrix is the Phase A truth table (§5.18 Platform Matrix):
// which protection profiles a given target platform can actually run against an
// uploaded BINARY today. fortress/stealth require source-in VM/watermarking
// (Phase C); android needs a separate DEX toolchain (deferred). The frontend
// mirrors this exact table for UX; the backend enforces it as the source of truth.
var platformProfileMatrix = map[string]map[string]bool{
	"windows": {"quick": true, "standard": true, "learning_lab": true},
	"linux":   {"quick": true, "standard": true, "learning_lab": true},
	"macos":   {"quick": true, "standard": true, "learning_lab": true},
	"android": {},
}

func profileSupportedForPlatform(platform, profileID string) bool {
	profiles, ok := platformProfileMatrix[platform]
	if !ok {
		return false
	}
	return profiles[profileID]
}

func (h *Handler) SubmitProtectionJob(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	// Parse multipart form
	if err := r.ParseMultipartForm(500 << 20); err != nil { // 500 MB
		jsonError(w, http.StatusBadRequest, "File too large or invalid form")
		return
	}

	profileID := r.FormValue("profile_id")
	platform := r.FormValue("platform")
	file, header, err := r.FormFile("file")
	if err != nil {
		jsonError(w, http.StatusBadRequest, "No file uploaded")
		return
	}
	defer file.Close()

	if profileID == "" {
		profileID = "standard"
	}
	if platform == "" {
		platform = "windows"
	}

	// Enforce the platform→profile gate server-side. This is the same truth the
	// frontend shows, but the backend must not trust the client.
	if !profileSupportedForPlatform(platform, profileID) {
		jsonError(w, http.StatusBadRequest,
			fmt.Sprintf("Profile '%s' is not supported for platform '%s' in Phase A", profileID, platform))
		return
	}

	// Read the uploaded bytes for real — Phase A archives the actual file rather
	// than sleeping on a fake timer.
	data, err := io.ReadAll(file)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to read uploaded file")
		return
	}
	if len(data) == 0 {
		jsonError(w, http.StatusBadRequest, "Uploaded file is empty")
		return
	}

	jobID := "pro-" + uuid.New().String()[:8]

	if _, err := db.DB.Exec(`INSERT INTO protection_jobs (id, org_id, user_id, profile_id, input_file_name, platform, status, progress_pct)
		VALUES (?,?,?,?,?,?,'queued', 0)`,
		jobID, claims.OrgID, claims.UserID, profileID, header.Filename, platform); err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to create protection job")
		return
	}

	logAudit(claims.OrgID, claims.UserID, "protection.submit", "protection_job", jobID, header.Filename)

	// Archive the binary under ARTIFACT_DIR/<jobID>/ so the pipeline operates on
	// a durable, per-job copy. Phase A stores the validated input; Phase C will
	// write the transformed output alongside it.
	artifactDir := filepath.Join(h.artifactDir, jobID)
	if err := os.MkdirAll(artifactDir, 0755); err != nil {
		db.DB.Exec(`UPDATE protection_jobs SET status='failed', error_message=? WHERE id=?`,
			"Failed to create artifact directory", jobID)
		jsonError(w, http.StatusInternalServerError, "Failed to store artifact")
		return
	}
	inputPath := filepath.Join(artifactDir, filepath.Base(header.Filename))
	if err := os.WriteFile(inputPath, data, 0644); err != nil {
		db.DB.Exec(`UPDATE protection_jobs SET status='failed', error_message=? WHERE id=?`,
			"Failed to write artifact", jobID)
		jsonError(w, http.StatusInternalServerError, "Failed to store artifact")
		return
	}

	// Pipeline: measure the uploaded binary (real SHA-256 integrity anchor),
	// then run the packaging stage (§5.13). learning_lab means "no protection":
	// its download is the validated original. Every other profile goes through
	// the custom packer (zstd + Ed25519 Taggant), producing a real protected
	// artifact with a verifiable signature.
	start := time.Now()
	format, digest, err := protect.ComputeIntegrityDigest(inputPath)
	if err != nil {
		db.DB.Exec(`UPDATE protection_jobs SET status='failed', progress_pct=100, error_message=?, duration=?, completed_at=CURRENT_TIMESTAMP WHERE id=?`,
			err.Error(), time.Since(start).String(), jobID)
		jsonError(w, http.StatusInternalServerError, "Integrity hashing failed: "+err.Error())
		return
	}

	var outputName string
	switch {
	case profileID == "learning_lab":
		// No protection applied (training environment) — serve the original.
		outputName = filepath.Base(header.Filename)
	case h.packer == nil:
		db.DB.Exec(`UPDATE protection_jobs SET status='failed', progress_pct=100, error_message=?, duration=?, completed_at=CURRENT_TIMESTAMP WHERE id=?`,
			"Packer unavailable", time.Since(start).String(), jobID)
		jsonError(w, http.StatusInternalServerError, "Packer unavailable")
		return
	default:
		packed, err := h.packer.Pack(data)
		if err != nil {
			db.DB.Exec(`UPDATE protection_jobs SET status='failed', progress_pct=100, error_message=?, duration=?, completed_at=CURRENT_TIMESTAMP WHERE id=?`,
				err.Error(), time.Since(start).String(), jobID)
			jsonError(w, http.StatusInternalServerError, "Packaging failed: "+err.Error())
			return
		}
		outputName = filepath.Base(header.Filename) + ".jspk"
		if err := os.WriteFile(filepath.Join(artifactDir, outputName), packed, 0644); err != nil {
			db.DB.Exec(`UPDATE protection_jobs SET status='failed', progress_pct=100, error_message=?, duration=?, completed_at=CURRENT_TIMESTAMP WHERE id=?`,
				"Failed to write packed artifact", time.Since(start).String(), jobID)
			jsonError(w, http.StatusInternalServerError, "Failed to store protected artifact")
			return
		}
	}

	db.DB.Exec(`UPDATE protection_jobs SET status='completed', progress_pct=100, duration=?, integrity_hash=?, binary_format=?, output_file_name=?, completed_at=CURRENT_TIMESTAMP WHERE id=?`,
		time.Since(start).String(), digest, format, outputName, jobID)

	jsonResponse(w, http.StatusCreated, map[string]string{
		"id":               jobID,
		"status":           "completed",
		"integrity_hash":   digest,
		"binary_format":    format,
		"output_file_name": outputName,
	})
}

// ─── ADMIN / METRICS HANDLERS ─────────────────────────────

func (h *Handler) GetMetrics(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	var sandboxTotal, sandboxActive, licensesActive, jobsToday int
	db.DB.QueryRow("SELECT COUNT(*) FROM sandboxes WHERE org_id = ?", claims.OrgID).Scan(&sandboxTotal)
	db.DB.QueryRow("SELECT COUNT(*) FROM sandboxes WHERE org_id = ? AND status = 'running'", claims.OrgID).Scan(&sandboxActive)
	db.DB.QueryRow("SELECT COUNT(*) FROM licenses WHERE org_id = ? AND status = 'active'", claims.OrgID).Scan(&licensesActive)
	db.DB.QueryRow("SELECT COUNT(*) FROM protection_jobs WHERE org_id = ? AND date(created_at) = date('now')", claims.OrgID).Scan(&jobsToday)

	jsonResponse(w, http.StatusOK, map[string]interface{}{
		"sandboxes_total":   sandboxTotal,
		"sandboxes_active":  sandboxActive,
		"licenses_active":   licensesActive,
		"protection_jobs_today": jobsToday,
		"compute_hours_today":  sandboxActive * 2,
	})
}

func (h *Handler) GetAuditLog(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetUserClaims(r)

	rows, err := db.DB.Query(`SELECT a.id, a.org_id, a.user_id, COALESCE(u.email,'system'), a.action, a.resource_type, 
		COALESCE(a.resource_id,''), COALESCE(a.details,''), a.created_at 
		FROM audit_log a LEFT JOIN users u ON a.user_id = u.id 
		WHERE a.org_id = ? ORDER BY a.created_at DESC LIMIT 100`, claims.OrgID)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to fetch audit log")
		return
	}
	defer rows.Close()

	var events []models.AuditEvent
	for rows.Next() {
		var e models.AuditEvent
		if err := rows.Scan(&e.ID, &e.OrgID, &e.UserID, &e.UserEmail, &e.Action, &e.ResourceType, &e.ResourceID, &e.Details, &e.CreatedAt); err != nil {
			continue
		}
		events = append(events, e)
	}
	if events == nil {
		events = []models.AuditEvent{}
	}

	jsonResponse(w, http.StatusOK, events)
}

func (h *Handler) GetProtectionProfiles(w http.ResponseWriter, r *http.Request) {
	profiles := []map[string]interface{}{
		{"id": "quick", "name": "Quick Shield", "description": "Light protection for internal tools. Symbol stripping, string XOR encryption.", "performance_impact": "<5%"},
		{"id": "standard", "name": "Standard Guard", "description": "Balanced protection for commercial apps. CF flattening, AES string encryption, basic RASP.", "performance_impact": "10-20%"},
		{"id": "fortress", "name": "Fortress", "description": "Maximum protection for high-value IP. Full VM, all obfuscation, full RASP.", "performance_impact": "20-40%"},
		{"id": "stealth", "name": "Stealth", "description": "Military-grade protection with anti-forensic features.", "performance_impact": "30-50%"},
		{"id": "learning_lab", "name": "Learning Lab", "description": "No protection applied. For student/training environments.", "performance_impact": "0%"},
	}

	jsonResponse(w, http.StatusOK, profiles)
}

// ─── DAO ASSISTANT HANDLERS ───────────────────────────────

func (h *Handler) DaoCommand(w http.ResponseWriter, r *http.Request) {
	var req models.DaoCommandRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if req.Command == "" {
		jsonError(w, http.StatusBadRequest, "Command is required")
		return
	}

	// Parse intent from natural language command
	intent := parseIntent(req.Command)

	resp := models.DaoCommandResponse{
		Intent:    intent.Intent,
		Action:    intent.Action,
		Confidence: intent.Confidence,
		Reasoning: intent.Reasoning,
	}

	// If confidence is high enough, execute the action
	if intent.Confidence >= 0.7 && intent.Action != "" {
		result, err := h.executeDaoAction(intent, r)
		if err != nil {
			resp.Error = err.Error()
		} else {
			resp.Result = result
		}
	}

	// Log to Ben AI School learning
	if req.SessionID != "" {
		logSchoolEntry(req.SessionID, req.Command, intent.Intent, resp.Error == "", resp.Error, intent.Confidence)
	}

	jsonResponse(w, http.StatusOK, resp)
}

func (h *Handler) DaoIntent(w http.ResponseWriter, r *http.Request) {
	var req models.DaoIntentRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if req.Command == "" {
		jsonError(w, http.StatusBadRequest, "Command is required")
		return
	}

	intent := parseIntent(req.Command)

	jsonResponse(w, http.StatusOK, models.DaoIntentResponse{
		Intent:     intent.Intent,
		Action:     intent.Action,
		Confidence: intent.Confidence,
		Parameters: intent.Parameters,
	})
}

func (h *Handler) DaoStatus(w http.ResponseWriter, r *http.Request) {
	dockerOK := h.docker != nil

	var sandboxTotal, sandboxActive, licensesActive int
	db.DB.QueryRow("SELECT COUNT(*) FROM sandboxes").Scan(&sandboxTotal)
	db.DB.QueryRow("SELECT COUNT(*) FROM sandboxes WHERE status = 'running'").Scan(&sandboxActive)
	db.DB.QueryRow("SELECT COUNT(*) FROM licenses WHERE status = 'active'").Scan(&licensesActive)

	health := "healthy"
	if !dockerOK {
		health = "degraded"
	}

	jsonResponse(w, http.StatusOK, models.DaoStatusResponse{
		Service:        "jade-seal",
		Version:        "2.0.0",
		BenAIConnected: middleware.BenAIAPIKey != "",
		Capabilities:   []string{"sandbox.launch", "sandbox.stop", "sandbox.list", "license.issue", "license.revoke", "license.verify", "protection.submit", "protection.list", "metrics.view", "audit.view"},
		Health:         health,
		Metrics: map[string]interface{}{
			"sandboxes_total":  sandboxTotal,
			"sandboxes_active": sandboxActive,
			"licenses_active":  licensesActive,
			"docker_available": dockerOK,
		},
	})
}

func (h *Handler) DaoEvents(w http.ResponseWriter, r *http.Request) {
	// SSE endpoint for Ben AI real-time event stream
	flusher, ok := w.(http.Flusher)
	if !ok {
		jsonError(w, http.StatusInternalServerError, "Streaming not supported")
		return
	}

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	// Send initial connection event
	event := models.BenAIEvent{
		ID:        uuid.New().String(),
		Type:      "connection.established",
		Timestamp: time.Now(),
		Data: map[string]interface{}{
			"service": "jade-seal",
			"version": "2.0.0",
		},
	}
	eventJSON, _ := json.Marshal(event)
	fmt.Fprintf(w, "data: %s\n\n", eventJSON)
	flusher.Flush()

	// Keep connection alive with heartbeat
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			fmt.Fprintf(w, ": heartbeat\n\n")
			flusher.Flush()
		case <-r.Context().Done():
			return
		}
	}
}

// ─── INTENT PARSER ────────────────────────────────────────

type parsedIntent struct {
	Intent     string
	Action     string
	Confidence float64
	Reasoning  string
	Parameters map[string]interface{}
}

func parseIntent(command string) parsedIntent {
	cmd := strings.ToLower(strings.TrimSpace(command))

	// Sandbox commands
	if strings.Contains(cmd, "launch") || strings.Contains(cmd, "start") || strings.Contains(cmd, "create") {
		if strings.Contains(cmd, "sandbox") || strings.Contains(cmd, "environment") || strings.Contains(cmd, "container") {
			return parsedIntent{
				Intent:     "sandbox.launch",
				Action:     "ACTION: sandbox.create { template: auto, isolation: container }",
				Confidence: 0.85,
				Reasoning:  "Detected sandbox launch request via keyword matching: 'launch/start/create' + 'sandbox/environment/container'",
			}
		}
	}

	if strings.Contains(cmd, "stop") || strings.Contains(cmd, "shutdown") || strings.Contains(cmd, "terminate") {
		if strings.Contains(cmd, "sandbox") || strings.Contains(cmd, "environment") {
			return parsedIntent{
				Intent:     "sandbox.stop",
				Action:     "ACTION: sandbox.stop { id: current }",
				Confidence: 0.85,
				Reasoning:  "Detected sandbox stop request via keyword matching: 'stop/shutdown/terminate' + 'sandbox/environment'",
			}
		}
	}

	// License commands
	if strings.Contains(cmd, "issue") || strings.Contains(cmd, "create") || strings.Contains(cmd, "generate") {
		if strings.Contains(cmd, "license") || strings.Contains(cmd, "key") {
			return parsedIntent{
				Intent:     "license.issue",
				Action:     "ACTION: license.issue { type: cloud, model: trial }",
				Confidence: 0.85,
				Reasoning:  "Detected license issuance request via keyword matching: 'issue/create/generate' + 'license/key'",
			}
		}
	}

	if strings.Contains(cmd, "revoke") || strings.Contains(cmd, "cancel") || strings.Contains(cmd, "disable") {
		if strings.Contains(cmd, "license") || strings.Contains(cmd, "key") {
			return parsedIntent{
				Intent:     "license.revoke",
				Action:     "ACTION: license.revoke { id: latest }",
				Confidence: 0.85,
				Reasoning:  "Detected license revocation request via keyword matching: 'revoke/cancel/disable' + 'license/key'",
			}
		}
	}

	// Protection commands
	if strings.Contains(cmd, "protect") || strings.Contains(cmd, "harden") || strings.Contains(cmd, "obfuscate") {
		if strings.Contains(cmd, "app") || strings.Contains(cmd, "binary") || strings.Contains(cmd, "file") || strings.Contains(cmd, "software") || strings.Contains(cmd, "exe") {
			return parsedIntent{
				Intent:     "protection.submit",
				Action:     "ACTION: protection.submit { profile: standard }",
				Confidence: 0.85,
				Reasoning:  "Detected protection request via keyword matching: 'protect/harden/obfuscate' + 'app/binary/file'",
			}
		}
	}

	// Status/Metrics commands
	if strings.Contains(cmd, "status") || strings.Contains(cmd, "health") || strings.Contains(cmd, "metrics") || strings.Contains(cmd, "overview") {
		return parsedIntent{
			Intent:     "system.status",
			Action:     "ACTION: metrics.view {}",
			Confidence: 0.90,
			Reasoning:  "Detected status/metrics request via keyword matching: 'status/health/metrics/overview'",
		}
	}

	if strings.Contains(cmd, "list") && (strings.Contains(cmd, "sandbox") || strings.Contains(cmd, "environment")) {
		return parsedIntent{
			Intent:     "sandbox.list",
			Action:     "ACTION: sandbox.list {}",
			Confidence: 0.90,
			Reasoning:  "Detected sandbox list request via keyword matching: 'list' + 'sandbox/environment'",
		}
	}

	if strings.Contains(cmd, "list") && (strings.Contains(cmd, "license") || strings.Contains(cmd, "key")) {
		return parsedIntent{
			Intent:     "license.list",
			Action:     "ACTION: license.list {}",
			Confidence: 0.90,
			Reasoning:  "Detected license list request via keyword matching: 'list' + 'license/key'",
		}
	}

	// Unknown intent
	return parsedIntent{
		Intent:     "unknown",
		Action:     "",
		Confidence: 0.1,
		Reasoning:  fmt.Sprintf("Unable to parse intent from command: '%s'. No matching keyword patterns found.", command),
	}
}

func (h *Handler) executeDaoAction(intent parsedIntent, r *http.Request) (map[string]interface{}, error) {
	claims := middleware.GetUserClaims(r)
	orgID := "org-001"
	userID := "system"
	if claims != nil {
		orgID = claims.OrgID
		userID = claims.UserID
	}

	logAudit(orgID, userID, "dao.execute", intent.Intent, "", intent.Reasoning)

	switch intent.Intent {
	case "system.status":
		var total, active, licenses int
		db.DB.QueryRow("SELECT COUNT(*) FROM sandboxes WHERE org_id = ?", orgID).Scan(&total)
		db.DB.QueryRow("SELECT COUNT(*) FROM sandboxes WHERE org_id = ? AND status = 'running'", orgID).Scan(&active)
		db.DB.QueryRow("SELECT COUNT(*) FROM licenses WHERE org_id = ? AND status = 'active'", orgID).Scan(&licenses)
		return map[string]interface{}{
			"sandboxes_total":  total,
			"sandboxes_active": active,
			"licenses_active":  licenses,
		}, nil

	case "sandbox.list":
		rows, err := db.DB.Query("SELECT id, COALESCE(name,''), status FROM sandboxes WHERE org_id = ? ORDER BY created_at DESC LIMIT 10", orgID)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		var list []map[string]interface{}
		for rows.Next() {
			var id, name, status string
			rows.Scan(&id, &name, &status)
			list = append(list, map[string]interface{}{"id": id, "name": name, "status": status})
		}
		if list == nil {
			list = []map[string]interface{}{}
		}
		return map[string]interface{}{"sandboxes": list}, nil

	case "license.list":
		rows, err := db.DB.Query("SELECT l.id, COALESCE(p.name,''), l.status FROM licenses l LEFT JOIN products p ON l.product_id = p.id WHERE l.org_id = ? ORDER BY l.created_at DESC LIMIT 10", orgID)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		var list []map[string]interface{}
		for rows.Next() {
			var id, product, status string
			rows.Scan(&id, &product, &status)
			list = append(list, map[string]interface{}{"id": id, "product": product, "status": status})
		}
		if list == nil {
			list = []map[string]interface{}{}
		}
		return map[string]interface{}{"licenses": list}, nil

	default:
		return map[string]interface{}{
			"message": fmt.Sprintf("Intent '%s' recognized but execution not yet implemented. Ben AI can handle this via the dashboard API.", intent.Intent),
		}, nil
	}

}

func logSchoolEntry(sessionID, command, intent string, success bool, errorPattern string, confidence float64) {
	outcome := "success"
	if !success {
		outcome = "failure"
	}
	db.DB.Exec(`INSERT INTO school_learning (id, session_id, command, intent, outcome, error_pattern, confidence, created_at) 
		VALUES (?,?,?,?,?,?,?, CURRENT_TIMESTAMP)`,
		uuid.New().String(), sessionID, command, intent, outcome, errorPattern, confidence)
}

// ─── Public entry points for WebSocket command bridge ─────

// ParseIntentPublic exposes the natural-language intent parser so the
// WebSocket command handler in main.go can reuse the same logic that
// the REST /api/dao/command endpoint uses.
func ParseIntentPublic(command string) parsedIntent {
	return parseIntent(command)
}

// ExecuteDaoActionPublic exposes the action executor for the same reason.
// The http.Request is used to extract the caller's claims from context.
func (h *Handler) ExecuteDaoActionPublic(intent parsedIntent, r *http.Request) (map[string]interface{}, error) {
	return h.executeDaoAction(intent, r)
}

// ─── WebSocket broadcast helpers ────────────────────────────

// BroadcastEvent pushes an event to all connected WebSocket clients.
// Safe to call from any goroutine. Subscribed clients receive the event
// even when no other Hub event has been triggered.
func BroadcastEvent(eventType string, data map[string]interface{}) {
	jsws.Broadcast(eventType, data)
}
