package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/google/uuid"
	"github.com/jadeseal/platform/db"
	"github.com/jadeseal/platform/license"
	"github.com/jadeseal/platform/models"
)

// offlineMaxTTL caps how long an offline d2c ticket stays valid (§6.5). It is
// deliberately short: offline revocation is delayed by definition — the ticket
// keeps working until it expires no matter what the server does — so a 30-day
// cap bounds the exposure window. A perpetual license still needs to renew its
// offline ticket every 30 days.
const offlineMaxTTL = 30 * 24 * time.Hour

// nextOfflineCounter advances the per-license monotonic counter atomically and
// returns the new value (§6.5/§6.12). Because it only ever increases, a client
// that has already accepted counter N can prove a ticket bearing N or less is a
// replay, even fully offline.
func nextOfflineCounter(licenseID string) (int64, error) {
	var counter int64
	err := db.DB.QueryRow(`INSERT INTO offline_counters (license_id, counter) VALUES (?, 1)
		ON CONFLICT(license_id) DO UPDATE SET counter = counter + 1
		RETURNING counter`, licenseID).Scan(&counter)
	return counter, err
}

// offlineExpiry returns the earlier of the license's own expiry and the offline
// TTL cap, so neither a perpetual license nor a long-dated one can be used
// offline indefinitely.
func offlineExpiry(licExp *time.Time, issued time.Time) time.Time {
	cap := issued.Add(offlineMaxTTL)
	if licExp != nil && licExp.Before(cap) {
		return *licExp
	}
	return cap
}

// ActivateOffline mints a signed d2c ticket for an air-gapped machine (§6.5).
// It runs the SAME enforcement path as online verify (verifyLicenseCore) plus a
// monotonic counter, so offline and online activation can never drift apart.
func (h *Handler) ActivateOffline(w http.ResponseWriter, r *http.Request) {
	var req models.OfflineActivateRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonError(w, http.StatusBadRequest, "Invalid request")
		return
	}
	if req.LicenseKey == "" || req.FPHash == "" {
		jsonError(w, http.StatusBadRequest, "license_key and fp_hash are required")
		return
	}

	now := time.Now()

	// Anti-replay (§6.12): stale timestamp or reused nonce is refused first.
	if req.TS == 0 || now.Unix()-req.TS > activationSkew || req.TS-now.Unix() > activationSkew {
		jsonResponse(w, http.StatusOK, models.OfflineActivateResponse{
			Status: "denied", Reason: "stale", Message: "Request timestamp is outside the allowed window.", ServerTime: now.Unix(),
		})
		return
	}
	if req.Nonce == "" || !h.nonces.Record("offline:"+req.LicenseKey+"\x00"+req.Nonce) {
		jsonResponse(w, http.StatusOK, models.OfflineActivateResponse{
			Status: "denied", Reason: "replay", Message: "Duplicate request (nonce already used).", ServerTime: now.Unix(),
		})
		return
	}

	// Single enforcement path: signed anchor → status/expiry/email → machine lock.
	res, err := verifyLicenseCore(req.LicenseKey, "", req.FPHash, req.Email)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Offline activation failed")
		return
	}
	if res.status != "valid" {
		jsonResponse(w, http.StatusOK, models.OfflineActivateResponse{
			Status: res.status, Reason: res.reason, Message: res.message, ServerTime: now.Unix(),
		})
		return
	}

	counter, err := nextOfflineCounter(res.licenseID)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to advance offline counter")
		return
	}

	seatID := "seat-" + uuid.New().String()[:8]
	exp := offlineExpiry(res.expiresAt, now)
	ticket := license.OfflineTicket{
		LicenseKey: req.LicenseKey,
		SeatID:     seatID,
		FPHash:     req.FPHash,
		Counter:    counter,
		IssuedAt:   now,
		ExpiresAt:  exp,
	}
	sig, err := license.SignOfflineTicket(ticket)
	if err != nil {
		jsonError(w, http.StatusInternalServerError, "Failed to sign offline ticket")
		return
	}

	logAudit(res.orgID, "offline-client", "license.offline_activate", "license", res.licenseID, seatID)

	jsonResponse(w, http.StatusOK, models.OfflineActivateResponse{
		Status:     "valid",
		SeatID:     seatID,
		FPHash:     req.FPHash,
		Counter:    counter,
		IssuedAt:   now.Unix(),
		ExpiresAt:  &exp,
		Signature:  sig,
		ServerTime: now.Unix(),
	})
}
