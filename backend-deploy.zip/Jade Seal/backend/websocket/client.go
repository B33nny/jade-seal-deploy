package websocket

import (
	"encoding/json"
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/gorilla/websocket"

	appMiddleware "github.com/jadeseal/platform/middleware"
)

// Client is a single WebSocket connection.
type Client struct {
	ID       string
	hub      *Hub
	conn     *websocket.Conn
	send     chan *OutboundMessage
	UserID   string
	OrgID    string
	AuthMode string // "user", "benai", "guest"
}

// CommandHandler is the function signature for processing inbound commands.
// Returning a non-nil OutboundMessage sends a "result" reply to the caller.
type CommandHandler func(c *Client, msg *InboundMessage) *OutboundMessage

// DefaultCommandHandler is set by main.go after construction.
// It bridges WS commands to the same handler chain that REST uses.
var DefaultCommandHandler CommandHandler

// ServeWS is the HTTP handler that upgrades a connection to a WebSocket.
//
// Authentication:
//   • `?token=<jwt>` for human users (Authorization equivalent)
//   • `?api_key=<key>` for Ben AI
//   • Otherwise: guest (read-only)
func ServeWS(w http.ResponseWriter, r *http.Request) {
	conn, err := Upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("[ws] upgrade error: %v", err)
		return
	}

	client := &Client{
		ID:    uuid.New().String(),
		hub:   DefaultHub,
		conn:  conn,
		send:  make(chan *OutboundMessage, 64),
	}

	// ── auth ─────────────────────────────────────────
	if tok := r.URL.Query().Get("token"); tok != "" {
		// Reuse the same JWT validation used for REST.
		parts := strings.SplitN(tok, " ", 2)
		tokenStr := tok
		if len(parts) == 2 && parts[0] == "Bearer" {
			tokenStr = parts[1]
		}
		claims, err := appMiddleware.ValidateAccessToken(tokenStr)
		if err == nil && claims != nil {
			client.UserID = claims.UserID
			client.OrgID = claims.OrgID
			client.AuthMode = "user"
		}
	} else if key := r.URL.Query().Get("api_key"); key != "" {
		if appMiddleware.BenAIAPIKey != "" && key == appMiddleware.BenAIAPIKey {
			client.AuthMode = "benai"
		}
	} else {
		client.AuthMode = "guest"
	}

	if client.AuthMode == "guest" {
		// Still allow connection but in read-only mode.
		log.Printf("[ws] guest connection from %s", r.RemoteAddr)
	}

	// Send hello.
	client.send <- &OutboundMessage{
		Type: "hello",
		Result: map[string]interface{}{
			"client_id":  client.ID,
			"auth_mode":  client.AuthMode,
			"user_id":    client.UserID,
			"org_id":     client.OrgID,
			"server":     "jade-seal",
			"version":    "2.1.0",
			"capabilities": []string{
				"command.send", "intent.parse",
				"event.subscribe", "broadcast",
			},
		},
		Timestamp: time.Now(),
	}

	DefaultHub.Register(client)
	go client.writePump()
	go client.readPump()
}

// ─── I/O pumps ──────────────────────────────────────────

func (c *Client) readPump() {
	defer func() {
		c.hub.unregister <- c
		c.conn.Close()
	}()
	c.conn.SetReadLimit(maxMessageSize)
	_ = c.conn.SetReadDeadline(time.Now().Add(pongWait))
	c.conn.SetPongHandler(func(string) error {
		_ = c.conn.SetReadDeadline(time.Now().Add(pongWait))
		return nil
	})

	for {
		_, raw, err := c.conn.ReadMessage()
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				log.Printf("[ws] read error: %v", err)
			}
			return
		}
		var msg InboundMessage
		if err := json.Unmarshal(raw, &msg); err != nil {
			c.send <- &OutboundMessage{
				ID:    msg.ID,
				Type:  "error",
				Error: "invalid JSON: " + err.Error(),
			}
			continue
		}

		switch msg.Type {
		case "ping":
			c.send <- &OutboundMessage{ID: msg.ID, Type: "pong", Timestamp: time.Now()}
		case "subscribe":
			c.hub.Subscribe(c, msg.Topics)
			c.send <- &OutboundMessage{
				ID:   msg.ID,
				Type: "ack",
				Result: map[string]interface{}{
					"subscribed": msg.Topics,
				},
			}
		case "command", "intent":
			// Acknowledge first
			c.send <- &OutboundMessage{ID: msg.ID, Type: "ack"}
			if DefaultCommandHandler != nil {
				go func(m InboundMessage) {
					resp := DefaultCommandHandler(c, &m)
					if resp == nil {
						return
					}
					if resp.ID == "" {
						resp.ID = m.ID
					}
					resp.Timestamp = time.Now()
					c.send <- resp
				}(msg)
			} else {
				c.send <- &OutboundMessage{
					ID:    msg.ID,
					Type:  "result",
					Error: "no command handler registered",
				}
			}
		default:
			c.send <- &OutboundMessage{
				ID:    msg.ID,
				Type:  "error",
				Error: "unknown message type: " + msg.Type,
			}
		}
	}
}

func (c *Client) writePump() {
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		c.conn.Close()
	}()
	for {
		select {
		case msg, ok := <-c.send:
			_ = c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if !ok {
				_ = c.conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}
			data, err := json.Marshal(msg)
			if err != nil {
				continue
			}
			if err := c.conn.WriteMessage(websocket.TextMessage, data); err != nil {
				return
			}
		case <-ticker.C:
			_ = c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}
