// Bridge file: lets handlers broadcast events without importing the
// websocket package's internals (avoids an import cycle with main.go).
package websocket

import "log"

// Broadcast publishes an event to the default hub. Called from handlers
// (e.g., when a sandbox is launched, a license is issued, a protection job
// completes). Failures are non-fatal.
func Broadcast(eventType string, data map[string]interface{}) {
	if DefaultHub == nil {
		return
	}
	DefaultHub.Broadcast(eventType, data)
	log.Printf("[ws] broadcast: %s", eventType)
}
