// Package websocket provides a real-time bidirectional channel
// between the Jade Seal platform and external AI agents (Ben AI, etc.).
//
// Protocol (JSON over WebSocket):
//   Client → Server:
//     { "type": "command",       "id": "<uuid>", "command": "launch a sandbox", "session_id": "..." }
//     { "type": "intent",        "id": "<uuid>", "command": "..." }
//     { "type": "subscribe",     "topics": ["sandbox.status", "license.issued"] }
//     { "type": "ping" }
//   Server → Client:
//     { "type": "event",         "event": { id, type, data, timestamp } }
//     { "type": "result",        "id": "<echo>", "intent": "...", "action": "...", "confidence": 0.9, "result": {...}, "error": "..." }
//     { "type": "ack",           "id": "<echo>" }
//     { "type": "pong" }
package websocket

import (
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/gorilla/websocket"
)

const (
	writeWait      = 10 * time.Second
	pongWait       = 60 * time.Second
	pingPeriod     = (pongWait * 9) / 10
	maxMessageSize = 1 << 20 // 1 MB
)

// Upgrader is shared by all WS handlers.
var Upgrader = websocket.Upgrader{
	ReadBufferSize:  4096,
	WriteBufferSize: 4096,
	// In dev, allow any origin. In production, replace with the dashboard origin.
	CheckOrigin: func(r *http.Request) bool { return true },
}

// ─── Inbound message shapes ──────────────────────────────

type InboundMessage struct {
	ID        string                 `json:"id,omitempty"`
	Type      string                 `json:"type"`
	Command   string                 `json:"command,omitempty"`
	SessionID string                 `json:"session_id,omitempty"`
	Topics    []string               `json:"topics,omitempty"`
	Context   string                 `json:"context,omitempty"`
	Extra     map[string]interface{} `json:"-"`
}

// ─── Outbound message shapes ─────────────────────────────

type OutboundMessage struct {
	ID         string                 `json:"id,omitempty"`
	Type       string                 `json:"type"`
	Event      *Event                 `json:"event,omitempty"`
	Intent     string                 `json:"intent,omitempty"`
	Action     string                 `json:"action,omitempty"`
	Confidence float64                `json:"confidence,omitempty"`
	Result     map[string]interface{} `json:"result,omitempty"`
	Reasoning  string                 `json:"reasoning,omitempty"`
	Error      string                 `json:"error,omitempty"`
	Timestamp  time.Time              `json:"timestamp,omitempty"`
}

// Event is a broadcast payload.
type Event struct {
	ID        string                 `json:"id"`
	Type      string                 `json:"type"`
	Data      map[string]interface{} `json:"data"`
	Timestamp time.Time              `json:"timestamp"`
}

// ─── Hub ─────────────────────────────────────────────────

// Hub maintains the set of active clients and broadcasts events to them.
type Hub struct {
	clients    map[*Client]bool
	register   chan *Client
	unregister chan *Client
	broadcast  chan *OutboundMessage
	topics     map[string]map[*Client]bool // topic -> clients
	mu         sync.RWMutex
}

var DefaultHub = NewHub()

func NewHub() *Hub {
	h := &Hub{
		clients:    make(map[*Client]bool),
		register:   make(chan *Client, 64),
		unregister: make(chan *Client, 64),
		broadcast:  make(chan *OutboundMessage, 256),
		topics:     make(map[string]map[*Client]bool),
	}
	go h.run()
	return h
}

func (h *Hub) run() {
	for {
		select {
		case c := <-h.register:
			h.mu.Lock()
			h.clients[c] = true
			h.mu.Unlock()
			log.Printf("[ws] client connected (%s) — %d active", c.ID, len(h.clients))
		case c := <-h.unregister:
			h.mu.Lock()
			if _, ok := h.clients[c]; ok {
				delete(h.clients, c)
				close(c.send)
				for _, subs := range h.topics {
					delete(subs, c)
				}
			}
			h.mu.Unlock()
			log.Printf("[ws] client disconnected (%s) — %d active", c.ID, len(h.clients))
		case msg := <-h.broadcast:
			h.dispatch(msg)
		}
	}
}

func (h *Hub) dispatch(msg *OutboundMessage) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	if msg.Event != nil {
		// Topic-scoped broadcast: if event.Type matches a topic, only those clients get it.
		if subs, ok := h.topics[msg.Event.Type]; ok {
			for c := range subs {
				h.enqueue(c, msg)
			}
			return
		}
	}
	// Otherwise broadcast to everyone.
	for c := range h.clients {
		h.enqueue(c, msg)
	}
}

func (h *Hub) enqueue(c *Client, msg *OutboundMessage) {
	select {
	case c.send <- msg:
	default:
		// Slow client; drop and let the read loop kill it.
		go func(cl *Client) { h.unregister <- cl }(c)
	}
}

// Register adds a client.
func (h *Hub) Register(c *Client) { h.register <- c }

// Subscribe adds the client to a topic list.
func (h *Hub) Subscribe(c *Client, topics []string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	for _, t := range topics {
		if _, ok := h.topics[t]; !ok {
			h.topics[t] = make(map[*Client]bool)
		}
		h.topics[t][c] = true
	}
}

// Broadcast publishes an event to subscribers (or to all clients if no subscribers).
func (h *Hub) Broadcast(eventType string, data map[string]interface{}) {
	ev := &OutboundMessage{
		Type: "event",
		Event: &Event{
			ID:        uuid.New().String(),
			Type:      eventType,
			Data:      data,
			Timestamp: time.Now(),
		},
	}
	select {
	case h.broadcast <- ev:
	default:
		log.Printf("[ws] broadcast queue full, dropped event %s", eventType)
	}
}

// Stats returns a snapshot of hub state.
func (h *Hub) Stats() map[string]interface{} {
	h.mu.RLock()
	defer h.mu.RUnlock()
	topicCounts := make(map[string]int, len(h.topics))
	for t, subs := range h.topics {
		topicCounts[t] = len(subs)
	}
	return map[string]interface{}{
		"clients":         len(h.clients),
		"topics":          topicCounts,
		"topic_count":     len(h.topics),
	}
}
